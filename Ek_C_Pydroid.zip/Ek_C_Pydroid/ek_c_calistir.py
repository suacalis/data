# -*- coding: utf-8 -*-
"""
EK C — PYTHON KOD ÖRNEKLERİ (Pydroid 3 / Android sürümü)
İK Profesyonelleri için Metrik El Kitabı

NASIL ÇALIŞTIRILIR (Pydroid 3)
  1. Pydroid 3 ▸ menü ▸ Pip ▸ şu paketleri kurun:  numpy  pandas  matplotlib
  2. Bu klasörü (Ek_C_Pydroid) telefonda bir yere çıkarın; içinde "modules" ve "veri" klasörleri bulunmalı.
  3. Pydroid 3'te bu dosyayı açın (▸ Klasör ▸ Ek_C_Pydroid ▸ ek_c_calistir.py) ve ▶ düğmesine basın.
  4. Çıktı uzundur; yukarı kaydırarak okuyun. Sonuçlar "cikti" klasörüne kaydedilir.

SADECE BELİRLİ BÖLÜMLERİ ÇALIŞTIRMAK İÇİN: aşağıdaki SECILI listesine bölüm numaralarını yazın.
  Örnek: SECILI = [5, 6]  -> yalnızca C.5 ve C.6 (C.1, C.2, C.4, C.5, C.7, C.9 hazırlık bölümleri otomatik çalışır).
  Boş liste ([]) = tüm bölümler.
"""
SECILI = []          # örn. [5, 6]  (boş = hepsi)
MATPLOTLIB_GOSTER = True   # False yaparsanız grafik yalnızca dosyaya kaydedilir

# ----------------------------------------------------------------------------------------
# 0) PAKETİ BULMA VE ORTAM AYARLARI  (Pydroid'de dosyanın nereden çalıştırıldığı değişebilir)
# ----------------------------------------------------------------------------------------
import sys, os, pathlib, importlib, inspect

def _paketi_bul():
    adaylar = []
    try:
        adaylar.append(pathlib.Path(__file__).resolve().parent)
    except NameError:
        pass
    adaylar.append(pathlib.Path.cwd())
    for taban in ["/storage/emulated/0", "/sdcard", os.path.expanduser("~")]:
        for ad in ["Ek_C_Pydroid", "Ek_C_Paket", "Download/Ek_C_Pydroid", "Download/Ek_C_Paket",
                   "Documents/Ek_C_Pydroid", "Documents/Ek_C_Paket"]:
            adaylar.append(pathlib.Path(taban) / ad)
    for a in adaylar:
        if (a / "modules").is_dir() and (a / "veri").is_dir():
            return a
    return None

KOK = _paketi_bul()
if KOK is None:
    print("HATA: 'modules' ve 'veri' klasörleri bulunamadı.")
    print("Bu dosyayı, Ek_C_Pydroid klasörünün İÇİNDEN açıp çalıştırın")
    print("(ya da klasörü /storage/emulated/0/Ek_C_Pydroid yoluna kopyalayın).")
    raise SystemExit(1)

CIKTI = KOK / "cikti"
try:
    CIKTI.mkdir(exist_ok=True)
except OSError:
    import tempfile
    CIKTI = pathlib.Path(tempfile.gettempdir())
print("Paket klasörü:", KOK)
print("Çıktı klasörü:", CIKTI)

_HAZIRLIK = {1, 2, 4, 5, 7, 9}      # her zaman çalışan bölümler (veri okuma, yardımcı fonksiyonlar)
def _sec(n):
    return (not SECILI) or (n in SECILI) or (n in _HAZIRLIK)

def _g(x):
    """Defterdeki 'son satırın değerini göster' davranışının karşılığı (Pydroid'de print gerekir)."""
    try:
        import pandas as _pd
        if isinstance(x, (_pd.DataFrame, _pd.Series)):
            n = len(x)
            print(x.head(40).to_string())
            if n > 40:
                print(f"... ({n} satırın ilk 40'ı gösterildi)")
            return
    except ImportError:
        pass
    if x is not None:
        print(x)

def _baslik(metin):
    print()
    print("=" * 64)
    print(metin)
    print("=" * 64)


# ----------------------------------------------------------------------------------------
# C.1 Kurulum: modülleri içe aktarma
# ----------------------------------------------------------------------------------------
if _sec(1):
    _baslik('C.1 Kurulum: modülleri içe aktarma')
    import sys, pathlib, importlib
    import numpy as np
    import pandas as pd

    sys.path.insert(0, str(KOK / "modules"))  # modüllerin bulunduğu klasör
    VERI = KOK / "veri"

    pd.options.display.float_format = "{:,.2f}".format
    pd.options.display.max_columns = 30
    pd.options.display.width = 100          # telefon ekranı için

    # Modülleri adlarıyla içe aktarıyoruz. Her modülün ortak bir arayüzü vardır:
    #   METRIK_LISTESI : desteklenen metrik kimlikleri
    #   hesapla(kimlik, **girdiler) : sonuç sözlüğü döndürür
    #   ayrıca her metrik için ayrı fonksiyon (ör. aylik_devir, fte, kapsama_orani ...)
    def modul(ad):
        return importlib.import_module(ad)

    iso30435 = modul("iso30435_metrikler")   # İşgücü veri kalitesi
    iso30425 = modul("iso30425_metrikler")   # İşgücü bulunabilirliği (FTE, devamsızlık)
    iso30421 = modul("iso30421_metrikler")   # Devir ve elde tutma
    iso30430 = modul("iso30430_metrikler")   # İşe alım metrikleri
    iso30407 = modul("iso30407_metrikler")   # İşe alım başına maliyet
    iso30433 = modul("iso30433_metrikler")   # Yedekleme planlaması
    iso30422 = modul("iso30422_metrikler")   # Öğrenme ve gelişim
    iso30437 = modul("iso30437_metrikler")   # Öğrenme ve gelişim (etkililik)
    iso24179 = modul("iso24179_metrikler")   # İş sağlığı ve güvenliği
    iso23326 = modul("iso23326_metrikler")   # Çalışan bağlılığı
    iso30427 = modul("iso30427_metrikler")   # Maliyet
    iso30432 = modul("iso30432_metrikler")   # Üretkenlik
    iso30415 = modul("iso30415_metrikler")   # Çeşitlilik ve kapsayıcılık

    print("Hazır. Örnek: ISO/TS 30421 metrikleri ->", iso30421.METRIK_LISTESI[:5], "...")
    # Sonuç sözlüğü. hesapla() her zaman bir sözlük döndürür: deger (sayı), ondalik, birim, ifade (formülün yerine konmuş hâli) ve ayrinti (etiket–değer çiftleri). Aşağıdaki yardımcı işlevler bu sözlüğü okunur biçimde yazdırır ve sonuçları sonda toplayacağımız bir listeye ekler.
    SONUCLAR = []   # (rehber, metrik, değer, birim) satırları; C.13'te tabloya çevrilir

    def goster(s, baslik, rehber=None):
        """Sonuç sözlüğünü yazdırır ve özet listeye ekler."""
        o = s.get("ondalik", 2)
        print(f"{baslik}: {s['deger']:,.{o}f} {s.get('birim', '')}")
        print("   formül :", s.get("ifade", ""))
        for e, v in s.get("ayrinti", []):
            print(f"   · {e}: {v:,.2f}" if isinstance(v, (int, float)) else f"   · {e}: {v}")
        if rehber:
            SONUCLAR.append({"Rehber": rehber, "Metrik": baslik,
                             "Değer": round(s["deger"], o), "Birim": s.get("birim", "")})
        return s


# ----------------------------------------------------------------------------------------
# C.2 Veriyi okuma ve hazırlama
# ----------------------------------------------------------------------------------------
if _sec(2):
    _baslik('C.2 Veriyi okuma ve hazırlama')
    # Gerçek İK verisi nadiren “hazır”dır: yinelenen kayıtlar, boş alanlar, mantıksız tarihler… Bu bölümde yapay verideki bilinçli olarak eklenmiş sorunları bulup düzeltiyoruz. İlke şudur: önce kontrol et, sonra düzelt, yaptığın her düzeltmeyi kaydet.
    cal = pd.read_csv(VERI / "calisanlar.csv",
                      parse_dates=["ise_baslama_tarihi", "ayrilma_tarihi"])
    ise = pd.read_csv(VERI / "isealim_talepleri.csv",
                      parse_dates=["boslugun_bilindigi", "talep_onay_tarihi",
                                   "teklif_kabul_tarihi", "baslama_tarihi"])
    egt = pd.read_csv(VERI / "egitimler.csv", parse_dates=["tarih"])
    anket = pd.read_csv(VERI / "baglilik_anketi.csv")
    isg = pd.read_csv(VERI / "isg_aylik.csv")
    yed = pd.read_csv(VERI / "yedekleme_havuzu.csv")
    fin = pd.read_csv(VERI / "finans_aylik.csv")

    for ad, t in [("çalışanlar", cal), ("işe alım", ise), ("eğitim", egt), ("anket", anket),
                  ("İSG", isg), ("yedekleme", yed), ("finans", fin)]:
        print(f"{ad:<12} {t.shape[0]:>5} satır × {t.shape[1]:>2} sütun")
    _g(cal.head())
    # Adım 1 — Kalite kontrolü (düzeltmeden önce yalnızca ölç):
    YIL = 2025
    YIL_BASI, YIL_SONU = pd.Timestamp(YIL, 1, 1), pd.Timestamp(YIL, 12, 31)

    kontrol = {
        "Yinelenen sicil numarası":        int(cal.sicil_no.duplicated().sum()),
        "Eksik cinsiyet":                  int(cal.cinsiyet.isna().sum()),
        "Eksik performans puanı":          int(cal.performans_puani.isna().sum()),
        "Ayrılma tarihi < başlama tarihi": int((cal.ayrilma_tarihi < cal.ise_baslama_tarihi).sum()),
        "Ayrılma türü eksik (tarih var)":  int((cal.ayrilma_tarihi.notna() & cal.ayrilma_turu.isna()).sum()),
    }
    _g(pd.Series(kontrol, name="Sorunlu kayıt"))
    # Adım 2 — Düzeltme ve kayıt altına alma. Yinelenenleri atıyoruz; mantıksız tarihli kayıtları ise sessizce düzeltmek yerine ayrı bir tabloya alıp analizden çıkarıyoruz (gerçek hayatta kaynağa dönüp doğru değeri bulun).
    n0 = len(cal)
    cal = cal.drop_duplicates("sicil_no", keep="first").copy()
    print("Yinelenen kayıt atıldı:", n0 - len(cal))

    tarih_hatali = cal.ayrilma_tarihi < cal.ise_baslama_tarihi
    sorunlu = cal[tarih_hatali].copy()           # incelenmek üzere ayrı tutulur
    cal = cal[~tarih_hatali].copy()
    print("Tarih hatası nedeniyle analiz dışı bırakılan:", len(sorunlu))
    print(sorunlu[["sicil_no", "birim", "ise_baslama_tarihi", "ayrilma_tarihi"]].to_string(index=False))

    # Türetilmiş alanlar (sonraki bölümlerde kullanılacak)
    cal["kidem_ay"] = ((cal.ayrilma_tarihi.fillna(YIL_SONU) - cal.ise_baslama_tarihi).dt.days / 30.4375)
    print("\nHazır çalışan tablosu:", cal.shape)
    # Adım 3 — Zaman noktasındaki mevcut sayısı. Devir, FTE ve kıdem hesaplarının neredeyse hepsi “belirli bir günde kaç kişi çalışıyordu?” sorusuna dayanır. Bunu tek bir işlevde toplamak hataları azaltır.
    def mevcut(tarih, tablo=None):
        """Verilen günün sonunda işte olan çalışanlar (başlamış ve henüz ayrılmamış)."""
        t = cal if tablo is None else tablo
        tarih = pd.Timestamp(tarih)
        return t[(t.ise_baslama_tarihi <= tarih) &
                 (t.ayrilma_tarihi.isna() | (t.ayrilma_tarihi > tarih))]

    onceki_gun = YIL_BASI - pd.Timedelta(days=1)
    print("Yıl başı mevcut :", len(mevcut(onceki_gun)))
    print("Yıl sonu mevcut :", len(mevcut(YIL_SONU)))


# ----------------------------------------------------------------------------------------
# C.3 Veri kalitesi skor kartı — ISO 30435
# ----------------------------------------------------------------------------------------
if _sec(3):
    _baslik('C.3 Veri kalitesi skor kartı — ISO 30435')
    # Metrik hesaplamadan önce verinin ne kadar güvenilir olduğunu ölçün. Modülün skor_karti metriği beş boyutun en zayıfını (en zayıf halka) bulur.
    ham = pd.read_csv(VERI / "calisanlar.csv")        # temizlenmemiş hâl
    zorunlu = ["birim", "cinsiyet", "performans_puani", "ise_baslama_tarihi"]

    dolu = int(ham[zorunlu].notna().sum().sum())
    beklenen = len(ham) * len(zorunlu)
    tamlik = iso30435.hesapla("tamlik", dolu=dolu, beklenen=beklenen, esik=98)

    tutarsiz = int(kontrol["Yinelenen sicil numarası"] + kontrol["Ayrılma tarihi < başlama tarihi"])
    tutarlilik = iso30435.hesapla("tutarlilik", karsilastirilan=len(ham), tutarsiz=tutarsiz)

    # Doğruluk: 100 kayıtlık rastgele örneği elle doğruladığınızı varsayalım (3 hatalı bulundu)
    dogruluk = iso30435.hesapla("dogruluk", ornek=100, hatali=3, esik=95)

    goster(tamlik, "Zorunlu alan tamlığı", "ISO 30435")
    goster(tutarlilik, "Tutarlılık", "ISO 30435")
    goster(dogruluk, "Doğruluk (örneklem)", "ISO 30435")

    skor = iso30435.hesapla("skor_karti", dogruluk=dogruluk["deger"], guncellik=96.0,   # güncellik ve uygunluk burada varsayımdır; kendi sistem kayıtlarınızdan hesaplayın
                        
                            tamlik=tamlik["deger"], tutarlilik=tutarlilik["deger"], uygunluk=100.0)
    goster(skor, "Veri kalitesi — en zayıf halka", "ISO 30435")


# ----------------------------------------------------------------------------------------
# C.4 Kapasite: çalışan sayısı ve FTE — ISO/TS 30425
# ----------------------------------------------------------------------------------------
if _sec(4):
    _baslik('C.4 Kapasite: çalışan sayısı ve FTE — ISO/TS 30425')
    # fte metriği, tam zamanlı çalışan sayısına yarı zamanlıların haftalık saat toplamının tam zamanlı haftalık saate oranını ekler (FTE = A + B ÷ C).
    yil_sonu = mevcut(YIL_SONU)
    tam = yil_sonu[yil_sonu.istihdam_turu != "Yarı zamanlı"]
    yari = yil_sonu[yil_sonu.istihdam_turu == "Yarı zamanlı"]

    fte = iso30425.hesapla("fte",
                           tam_zamanli=len(tam),                 # A: tam zamanlı kişi
                           yari_saat=float(yari.haftalik_saat.sum()),   # B: yarı zamanlıların haftalık saati
                           haftalik_saat=45.0)                   # C: tam zamanlı haftalık saat
    goster(fte, "Yıl sonu FTE", "ISO/TS 30425")

    # Koşullu işgücü payı (geçici çalışanlar / toplam)
    kosullu = (yil_sonu.istihdam_turu == "Geçici").sum()
    print("\nGeçici çalışan payı: %.1f %%" % (100 * kosullu / len(yil_sonu)))


# ----------------------------------------------------------------------------------------
# C.5 Devir ve elde tutma — ISO/TS 30421
# ----------------------------------------------------------------------------------------
if _sec(5):
    _baslik('C.5 Devir ve elde tutma — ISO/TS 30421')
    # Önce 12 aylık devir tablosu hazırlıyoruz: her ay için ay başı mevcut, ay sonu mevcut, gönüllü ve gönülsüz ayrılan sayıları. Modülün DevirTablosu sınıfı tam bu yapıyı bekler.
    aylar = pd.period_range(f"{YIL}-01", f"{YIL}-12", freq="M")
    satirlar = []
    for p in aylar:
        bas_gun = p.start_time - pd.Timedelta(days=1)
        son_gun = p.end_time.normalize()
        ayr = cal[(cal.ayrilma_tarihi > bas_gun) & (cal.ayrilma_tarihi <= son_gun)]
        satirlar.append({"ay": str(p),
                         "basi": len(mevcut(bas_gun)), "sonu": len(mevcut(son_gun)),
                         "gonullu": int((ayr.ayrilma_turu == "Gönüllü").sum()),
                         "gonulsuz": int((ayr.ayrilma_turu == "Gönülsüz").sum())})
    aylik = pd.DataFrame(satirlar)
    aylik["ayrilan"] = aylik.gonullu + aylik.gonulsuz
    aylik["devir_%"] = aylik.apply(lambda r: iso30421.aylik_devir(r.ayrilan, r.basi, r.sonu), axis=1)
    _g(aylik)
    tablo = iso30421.DevirTablosu()
    for r in aylik.itertuples():
        tablo.ekle(r.ay, r.gonullu, r.gonulsuz, r.basi, r.sonu)

    ozet = tablo.ozet()
    print({k: v for k, v in ozet.items()})

    yillik = iso30421.hesapla("yillik_devir", oran_toplami=tablo.yillik_oran,
                              toplam_ayrilan=tablo.toplam_ayrilan,
                              ortalama_mevcut=tablo.ortalama_mevcut)
    goster(yillik, "Yıllık devir oranı", "ISO/TS 30421")

    gonullu = iso30421.hesapla("gonullu_gonulsuz", gonullu=int(aylik.gonullu.sum()),
                               gonulsuz=int(aylik.gonulsuz.sum()), ortalama_mevcut=tablo.ortalama_mevcut)
    goster(gonullu, "Gönüllü devir", "ISO/TS 30421")
    # Kritik pozisyon devri ve üzücü (regrettable) devir: ayrılanları kritik/üzücü olarak işaretleyen sütunlarımız olduğu için doğrudan filtreleyebiliriz.
    krit = cal[cal.kritik_pozisyon == 1]
    krit_ayr = int(krit.ayrilma_tarihi.notna().sum())
    # Not: modül birimi “% / ay” diye etiketler; burada ay yerine tüm yılı verdiğimiz için sonuç yıllıktır.
    kd = iso30421.hesapla("kritik_devir", kritik_ayrilan=krit_ayr,
                          kritik_basi=len(mevcut(onceki_gun, krit)), kritik_sonu=len(mevcut(YIL_SONU, krit)),
                          toplam_isgucu=len(yil_sonu))
    goster(kd, "Kritik pozisyon devri (yıllık)", "ISO/TS 30421")

    uz = iso30421.hesapla("uzucu_devir", uzucu=int(cal.uzucu_ayrilma.sum()),
                          toplam_ayrilan=int(cal.ayrilma_tarihi.notna().sum()),
                          ortalama_mevcut=tablo.ortalama_mevcut)
    goster(uz, "Üzücü (regrettable) devir", "ISO/TS 30421")
    # Elde tutma ve kıdem:
    bas = len(mevcut(onceki_gun))
    et = iso30421.hesapla("basit_elde_tutma", yillik_devir=yillik["deger"], donem_basi=bas)
    goster(et, "Basit elde tutma oranı", "ISO/TS 30421")

    kidem = iso30421.hesapla("ortalama_kidem", kumulatif_kidem_ay=float(yil_sonu.kidem_ay.sum()),
                             kisi_sayisi=len(yil_sonu))
    goster(kidem, "Ortalama kıdem", "ISO/TS 30421")

    # İstikrar oranı: 1 yıldan kıdemli çalışanlar / bir yıl önceki mevcut
    bir_yil_once = len(mevcut(YIL_SONU - pd.DateOffset(years=1)))
    kidemli = int((yil_sonu.kidem_ay >= 12).sum())
    ist = iso30421.hesapla("istikrar_orani", bir_yildan_kidemli=kidemli,
                           bir_yil_once_mevcut=bir_yil_once, bugunku_mevcut=len(yil_sonu))
    goster(ist, "İstikrar oranı (1+ yıl)", "ISO/TS 30421")


# ----------------------------------------------------------------------------------------
# C.6 İşe alım — ISO/TS 30430 ve ISO/TS 30407
# ----------------------------------------------------------------------------------------
if _sec(6):
    _baslik('C.6 İşe alım — ISO/TS 30430 ve ISO/TS 30407')
    dold = ise[ise.durum == "Dolduruldu"].copy()
    dold["doldurma_gun"] = (dold.teklif_kabul_tarihi - dold.talep_onay_tarihi).dt.days   # onaydan teklif kabulüne

    aqc = iso30430.hesapla("aqc", nitelikli=int(ise.nitelikli_aday.sum()),
                           pozisyon=len(ise), toplam_aday=int(ise.aday_sayisi.sum()))
    goster(aqc, "Pozisyon başına nitelikli aday (AQC)", "ISO/TS 30430")

    ttf = iso30430.hesapla("time_to_fill", toplam_gun=int(dold.doldurma_gun.sum()), pozisyon=len(dold),
                           doldurulamayan=int((ise.durum == "Açık").sum()))
    goster(ttf, "Ortalama doldurma süresi", "ISO/TS 30430")

    k = dold[dold.kritik_pozisyon == 1]
    ktf = iso30430.hesapla("kritik_time_to_fill",
                           genel_gun=int(dold.doldurma_gun.sum()), genel_pozisyon=len(dold),
                           kritik_gun=int(k.doldurma_gun.sum()), kritik_pozisyon=len(k))
    goster(ktf, "Kritik pozisyonlarda doldurma süresi", "ISO/TS 30430")
    cph = iso30407.hesapla("cphi", dis=int(dold.dis_maliyet_try.sum()), ic=int(dold.ic_maliyet_try.sum()),
                           isealim=len(dold))
    goster(cph, "İşe alım başına maliyet (CPHI, TL)", "ISO/TS 30407")

    # Kaynağa göre kırılım: pandas ile gruplayıp aynı fonksiyonu her gruba uygulayın
    kay = dold.groupby("kaynak").agg(isealim=("talep_id", "count"), dis=("dis_maliyet_try", "sum"),
                                     ic=("ic_maliyet_try", "sum"), gun=("doldurma_gun", "mean"))
    kay["CPH (TL)"] = [iso30407.hesapla("cphi", dis=r.dis, ic=r.ic, isealim=r.isealim)["deger"] for r in kay.itertuples()]
    _g(kay.round(1).sort_values("CPH (TL)"))


# ----------------------------------------------------------------------------------------
# C.7 Yedekleme planlaması — ISO/TS 30433
# ----------------------------------------------------------------------------------------
if _sec(7):
    _baslik('C.7 Yedekleme planlaması — ISO/TS 30433')
    # Yedekleme havuzu tablosunda her kritik pozisyon için kaç yedek adayın şimdi, 1–3 yıl ve 4–5 yılda hazır olduğu yer alır. Modül pozisyon sayılarını ister: “şimdi hazır en az bir adayı olan kaç kritik pozisyon var?”
    poz = len(yed)
    simdi = int((yed.hazir_simdi > 0).sum())
    y13 = int((yed.hazir_1_3_yil > 0).sum())
    y45 = int((yed.hazir_4_5_yil > 0).sum())

    hz = iso30433.hesapla("hazirlik", hazir_simdi=simdi, hazir_1_3=y13, hazir_4_5=y45, kritik_pozisyon=poz)
    goster(hz, "Şimdi hazır yedeği olan kritik pozisyon", "ISO/TS 30433")

    yok = int(((yed.hazir_simdi + yed.hazir_1_3_yil + yed.hazir_4_5_yil) == 0).sum())
    hy = iso30433.hesapla("hazir_adayi_yok", pozisyon_sayisi=yok, toplam_pozisyon=poz,
                          onceki_oran=30.0)   # önceki dönem oranı (kendi kayıtlarınızdan; burada varsayım)
    goster(hy, "Hiç yedeği olmayan kritik pozisyon", "ISO/TS 30433")

    derin = iso30433.hesapla("derinlik", hazir_aday=int(yed.hazir_simdi.sum()), kritik_pozisyon=poz, hedef_derinlik=2)
    goster(derin, "Pozisyon başına şimdi hazır aday", "ISO/TS 30433")

    # Birim bazında risk haritası
    bb = yed.groupby("birim").agg(poz=("pozisyon_sicil", "count"), simdi=("hazir_simdi", lambda s: (s > 0).sum()))
    bb["hazirlik_%"] = 100 * bb.simdi / bb.poz
    _g(bb.sort_values("hazirlik_%"))


# ----------------------------------------------------------------------------------------
# C.8 Öğrenme ve gelişim — ISO 30422 ve ISO/TS 30437
# ----------------------------------------------------------------------------------------
if _sec(8):
    _baslik('C.8 Öğrenme ve gelişim — ISO 30422 ve ISO/TS 30437')
    # “Erişim”: zorunlu eğitimler herkese verildiği için yalnızca isteğe bağlı öğrenmeye katılanlar sayılır
    tekil = egt[~egt.kategori.str.startswith("Zorunlu")].sicil_no.nunique()
    toplam_calisan = len(cal)                       # yıl içinde çalışmış herkes
    kat = iso30422.hesapla("katilim", katilan=tekil, toplam_calisan=toplam_calisan)
    goster(kat, "Öğrenmeye erişen çalışan oranı", "ISO 30422")

    saat = iso30422.hesapla("kisi_basi_saat", toplam_saat=int(egt[egt.tamamladi == 1].saat.sum()),
                            toplam_calisan=toplam_calisan, katilan=egt.sicil_no.nunique())
    goster(saat, "Çalışan başına eğitim saati", "ISO 30422")

    mal = iso30422.hesapla("toplam_maliyet", dis_saglayici=int(egt.maliyet_try.sum()), ic_kaynak=0,
                           teknoloji=0, zaman_maliyeti=0, diger=0)
    goster(mal, "Toplam öğrenme maliyeti (yalnızca doğrudan, TL)", "ISO 30422")
    sinav = egt[egt.sinava_girdi == 1]
    og = iso30437.hesapla("ogrenme", ilk_denemede_gecen=int(sinav.ilk_denemede_gecti.sum()),
                          sinava_giren=len(sinav), toplam_deneme=len(sinav))
    goster(og, "İlk denemede geçme oranı (düzey 2)", "ISO/TS 30437")

    yanit = egt.memnuniyet.dropna()
    tp = iso30437.hesapla("tepki", olumlu=int((yanit >= 4).sum()), yanitlayan=len(yanit))
    goster(tp, "Olumlu tepki (4–5 puan, düzey 1)", "ISO/TS 30437")

    # Kategori kırılımı
    _g(egt.groupby("kategori").agg(katilimci=("sicil_no", "nunique"), saat=("saat", "sum"),
                                maliyet=("maliyet_try", "sum")).round(0))


# ----------------------------------------------------------------------------------------
# C.9 İş sağlığı ve güvenliği — ISO/TS 24179
# ----------------------------------------------------------------------------------------
if _sec(9):
    _baslik('C.9 İş sağlığı ve güvenliği — ISO/TS 24179')
    saat_top = int(isg.calisilan_saat.sum())
    ort_kadro = float(np.mean([len(mevcut(p.end_time.normalize())) for p in aylar]))

    sik = iso24179.hesapla("siklik_orani", olay=int(isg.is_kazasi_sayisi.sum()),
                                        calisilan_saat=saat_top, ortalama_kadro=ort_kadro)
    goster(sik, "Sıklık oranı (1.000.000 saat başına)", "ISO/TS 24179")

    agr = iso24179.hesapla("agirlik_orani", kayip_gun=int(isg.kayip_gun.sum()),
                           calisilan_saat=saat_top, olay=int(isg.is_kazasi_sayisi.sum()))
    goster(agr, "Ağırlık oranı (1.000 saat başına)", "ISO/TS 24179")

    kz = iso24179.hesapla("kayip_zaman", kayip_saat=int(isg.kayip_saat.sum()),
                          planlanan_saat=int(isg.planlanan_saat.sum()), ortalama_kadro=ort_kadro)
    goster(kz, "Kayıp zaman oranı", "ISO/TS 24179")


# ----------------------------------------------------------------------------------------
# C.10 Çalışan bağlılığı — ISO 23326
# ----------------------------------------------------------------------------------------
if _sec(10):
    _baslik('C.10 Çalışan bağlılığı — ISO 23326')
    # Anket anonim olduğu için birey düzeyinde değil, grup ortalamasıyla çalışıyoruz. Küçük gruplarda kimliğin ortaya çıkmaması için raporlanabilir asgari grup büyüklüğü denetimi yapılır (anonim metriği).
    madde = ["d1", "d2", "d3", "a1", "a2", "a3", "y1", "y2", "y3"]
    ort = anket[madde].mean()
    uw = iso23326.hesapla("uwes", **{k: float(v) for k, v in ort.items()})
    goster(uw, "Bağlılık puanı (UWES benzeri, 0–6)", "ISO 23326")

    # Yanıt oranı: anketin davet edildiği kişi sayısı = yıl sonu mevcut
    kt = iso23326.hesapla("katilim", davet=len(yil_sonu), yanit=len(anket))
    goster(kt, "Anket katılım oranı", "ISO 23326")

    # Anonimlik denetimi: birim bazında raporlama (asgari grup = 10)
    bg = anket.groupby("birim").size().rename("yanit").to_frame()
    bg["marj"] = [iso23326.hesapla("anonim", grup=int(g), esik=10)["deger"] for g in bg.yanit]
    bg["raporlanabilir"] = bg.marj >= 0
    bg

    # eNPS (ISO 30414 gösterimi): destekçi 9–10, karşıt 0–6
    en = anket.enps
    enps = 100 * ((en >= 9).sum() - (en <= 6).sum()) / len(en)
    print(f"\neNPS = {enps:.1f}")


# ----------------------------------------------------------------------------------------
# C.11 Maliyet ve üretkenlik — ISO/TS 30427 ve ISO/TS 30432
# ----------------------------------------------------------------------------------------
if _sec(11):
    _baslik('C.11 Maliyet ve üretkenlik — ISO/TS 30427 ve ISO/TS 30432')
    # Önceki yılın toplamları (kendi arşivinizden alın; burada yapay varsayım)
    ONCEKI_ISTIHDAM, ONCEKI_DIS = 285_000_000, 55_000_000

    top = fin[["maas", "ikramiye", "yan_hak", "diger_istihdam"]].sum()
    ist_m = iso30427.hesapla("istihdam", maas=int(top.maas), ikramiye=int(top.ikramiye),
                             yan_hak=int(top.yan_hak), diger=int(top.diger_istihdam),
                             onceki_toplam=ONCEKI_ISTIHDAM)
    dis_m = iso30427.hesapla("dis", bagimsiz=int(fin.bagimsiz_yuklenici.sum()), gecici=int(fin.gecici_isci.sum()),
                             kosullu=int(fin.kosullu_isci.sum()), fason=int(fin.fason.sum()),
                             onceki_toplam=ONCEKI_DIS)
    tm = iso30427.hesapla("toplam", istihdam=ist_m["deger"], dis=dis_m["deger"],
                          onceki_istihdam=ONCEKI_ISTIHDAM, onceki_dis=ONCEKI_DIS)
    goster(tm, "Toplam işgücü maliyeti (TL)", "ISO/TS 30427")

    gelir, gider = int(fin.net_gelir.sum()), int(fin.toplam_gider.sum())
    oran = iso30427.hesapla("oran", maliyet=tm["deger"], gelir=gelir)
    goster(oran, "İşgücü maliyeti / gelir", "ISO/TS 30427")

    fb = iso30427.hesapla("fte_basi", maliyet=tm["deger"], fte=fte["deger"])
    goster(fb, "FTE başına işgücü maliyeti (TL)", "ISO/TS 30427")
    roi = iso30432.hesapla("hc_roi", gelir=gelir, toplam_gider=gider, isgucu_maliyeti=tm["deger"])
    goster(roi, "İnsan sermayesi yatırım getirisi (HC RoI)", "ISO/TS 30432")

    gc = iso30432.hesapla("gelir_calisan", net_gelir=gelir, ortalama_calisan=ort_kadro,
                          isgucu_maliyeti=tm["deger"])
    goster(gc, "Çalışan başına gelir (TL)", "ISO/TS 30432")


# ----------------------------------------------------------------------------------------
# C.12 Çeşitlilik ve ücret eşitliği — ISO 30415
# ----------------------------------------------------------------------------------------
if _sec(12):
    _baslik('C.12 Çeşitlilik ve ücret eşitliği — ISO 30415')
    # ISO 30415 standart formül ya da eşik vermez; aşağıdaki hesaplar modülün uygulama örnekleridir. Ücret karşılaştırmasında bileşim etkisini azaltmak için aynı unvan grubu içinde karşılaştırın.
    kadin = (yil_sonu.cinsiyet == "K").sum()
    temsil = iso30415.hesapla("temsil", grup=int(kadin), toplam=int(yil_sonu.cinsiyet.notna().sum()), ref_pay=48.0)
    goster(temsil, "Kadın çalışan temsil endeksi (referans payı %48 varsayımı)", "ISO 30415")

    sonuc = []
    for u, g in yil_sonu.dropna(subset=["cinsiyet"]).groupby("unvan_grubu"):
        k, e = g[g.cinsiyet == "K"].aylik_brut_ucret, g[g.cinsiyet == "E"].aylik_brut_ucret
        if len(k) >= 5 and len(e) >= 5:          # küçük gruplarda raporlamayın
            f = iso30415.hesapla("ucret", grup_ort=float(k.mean()), ref_ort=float(e.mean()))
            sonuc.append({"unvan_grubu": u, "kadın n": len(k), "erkek n": len(e), "ücret farkı %": f["deger"]})
    _g(pd.DataFrame(sonuc))


# ----------------------------------------------------------------------------------------
# C.13 Sonuçların tek tabloda toplanması
# ----------------------------------------------------------------------------------------
if _sec(13):
    _baslik('C.13 Sonuçların tek tabloda toplanması')
    ozet_tablo = pd.DataFrame(SONUCLAR)
    _g(ozet_tablo)
    ozet_tablo.to_csv(CIKTI / "ozet_metrikler.csv", index=False, encoding="utf-8-sig")  # Excel'de Türkçe karakter için BOM
    print("Kaydedildi: cikti/ozet_metrikler.csv")

    # İsteğe bağlı grafik
    try:
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(11, 3.6))
        aylik.plot(x="ay", y="devir_%", kind="bar", ax=ax[0], legend=False, color="#0b5c8a")
        ax[0].set_title("Aylık devir oranı (%)"); ax[0].set_xlabel("")
        bb["hazirlik_%"].sort_values().plot(kind="barh", ax=ax[1], color="#14615c")
        ax[1].set_title("Yedek hazırlık oranı (%) — birim"); ax[1].set_ylabel("")
        plt.tight_layout()
        plt.savefig(CIKTI / "ozet_grafik.png", dpi=120)
        print("Grafik kaydedildi: ozet_grafik.png")
        if MATPLOTLIB_GOSTER:
            plt.show()
    except ImportError:
        print("matplotlib kurulu değil; grafik atlandı (pip install matplotlib).")


# ----------------------------------------------------------------------------------------
# C.14 Kendi verinizle kullanım
# ----------------------------------------------------------------------------------------
if _sec(14):
    _baslik('C.14 Kendi verinizle kullanım')
    # ### 1) Sütun eşleme
    #
    # Kendi İK sisteminizin dışa aktarımı büyük olasılıkla farklı sütun adları kullanır. Aşağıdaki sözlük, sizin sütunlarınızı bu defterin beklediği adlara çevirir; geri kalan kodu değiştirmeniz gerekmez.
    # SOL: sizin dosyanızdaki ad   SAĞ: bu defterin beklediği ad
    SUTUN_ESLEME = {
        "Personel No":        "sicil_no",
        "Departman":          "birim",
        "Kadro Grubu":        "unvan_grubu",
        "Cinsiyet":           "cinsiyet",
        "Çalışma Şekli":      "istihdam_turu",
        "Haftalık Saat":      "haftalik_saat",
        "İşe Giriş Tarihi":   "ise_baslama_tarihi",
        "İşten Çıkış Tarihi": "ayrilma_tarihi",
        "Çıkış Nedeni":       "ayrilma_turu",
    }
    DEGER_ESLEME = {            # kod listelerini defterin değerlerine çevirin
        "istihdam_turu": {"Full Time": "Tam zamanlı", "Part Time": "Yarı zamanlı", "Temp": "Geçici"},
        "ayrilma_turu":  {"İstifa": "Gönüllü", "İşveren Feshi": "Gönülsüz", "Emeklilik": "Gönüllü"},
    }

    def calisan_tablosunu_hazirla(yol, sep=";", encoding="utf-8-sig"):
        """Kendi dışa aktarımınızı okur ve bu defterin beklediği yapıya getirir."""
        t = pd.read_csv(yol, sep=sep, encoding=encoding, dayfirst=True)
        t = t.rename(columns=SUTUN_ESLEME)
        for s, harita in DEGER_ESLEME.items():
            if s in t:
                t[s] = t[s].replace(harita)
        for s in ["ise_baslama_tarihi", "ayrilma_tarihi"]:
            t[s] = pd.to_datetime(t[s], dayfirst=True, errors="coerce")
        eksik = {"sicil_no", "birim", "ise_baslama_tarihi"} - set(t.columns)
        assert not eksik, f"Zorunlu sütun eksik: {eksik}"
        return t.drop_duplicates("sicil_no")

    # Kullanım:
    #   cal = calisan_tablosunu_hazirla("benim_dosyam.csv")
    #   ... C.2'deki kalite kontrollerini yeniden çalıştırın, sonra C.4'ten itibaren devam edin.
    # ### 2) Hangi modülde hangi metrik var?
    #
    # Her modülün METRIK_LISTESI değişkeni, hesapla() işlevinin kabul ettiği kimlikleri verir. Bir kimliğin hangi girdileri istediğini görmek için ilgili rehber sayfasındaki hesaplayıcı alanlarına ya da fonksiyonun yardım metnine bakın.
    import glob, os
    print(f"{'Modül':<28}{'Metrik sayısı':>14}   İlk üç metrik")
    for yol in sorted(glob.glob(str(KOK / "modules" / "*.py"))):
        ad = os.path.basename(yol)[:-3]
        m = modul(ad)
        print(f"{ad:<28}{len(m.METRIK_LISTESI):>14}   {', '.join(map(str, m.METRIK_LISTESI[:3]))}")

    # Bir fonksiyonun girdilerini görmek:
    print(iso30421.aylik_devir.__name__, inspect.signature(iso30421.aylik_devir))
    print(inspect.getdoc(iso30421.aylik_devir))
    # Hata yakalama: eksik girdi KeyError, mantıksız girdi ValueError verir
    try:
        iso30421.hesapla("aylik_devir", ayrilan=3, ay_basi=0, ay_sonu=0)
    except (KeyError, ValueError, ZeroDivisionError) as e:
        print("Hesaplama reddedildi:", type(e).__name__, "-", e)
    # ### 3) Kontrol listesi: kendi verinizle çalışmadan önce
    #
    # - [ ] Gizlilik: Kişisel veriyi (ad, TCKN, iletişim) dosyadan çıkarın; sicil numarasını yerine takma kod kullanın. Veri işleme izninizi (KVKK) doğrulayın.
    # - [ ] Tanım: “Çalışan”ın kimleri kapsadığını yazın (stajyer, geçici, yüklenici?). FTE ve headcount ayrımını netleştirin.
    # - [ ] Dönem: Rapor dönemini, ay başı/sonu tanımını ve tarih biçimini (GG.AA.YYYY mi?) sabitleyin.
    # - [ ] Kalite: C.2 kontrollerini kendi verinize uygulayın; sorunlu kayıtları düzeltmeden analiz etmeyin ve düzeltmeleri kayıt altına alın.
    # - [ ] Küçük gruplar: Beş-on kişiden küçük gruplarda oran raporlamayın ya da birleştirin (anonimlik).
    # - [ ] Çapraz kontrol: İlk sonuçları eldeki bir bordro ya da yönetim raporuyla karşılaştırın.
    # - [ ] Belgeleyin: Hangi tanımı, hangi formülü ve hangi modül sürümünü kullandığınızı rapora yazın (Ek A.4: aynı adı taşıyan metrikler).
    # - [ ] Yorum: Eşik değerleri kendi geçmişinize ve sektörünüze göre kalibre edin; ISO standartları hedef vermez.
    #
    # ### 4) Sık karşılaşılan hatalar
    #
    # | Belirti | Olası neden | Çözüm |
    # |---|---|---|
    # | KeyError: 'ay_basi' | Gerekli girdi verilmedi | İlgili metriğin girdi adlarını rehber sayfasından kontrol edin |
    # | Devir oranı %100'ü aşıyor | Ay başı mevcut yanlış hesaplandı | mevcut() işlevinde tarih sınırını (>, >=) kontrol edin |
    # | FTE tam zamanlı sayısından küçük | Haftalık saat birimi karışık (aylık / günlük) | Tüm saatleri haftalığa çevirin |
    # | Tarihler NaT çıkıyor | Gün-ay sırası ters (03.04.2025) | dayfirst=True kullanın |
    # | Sonuç Excel'de bozuk karakter | UTF-8 BOM yok | encoding="utf-8-sig" ile kaydedin |
    # | Pyodide'de çalışan kod burada çalışmıyor | Farklı Python sürümü | Modüller yalnızca standart kütüphane kullanır; Python 3.9+ yeterlidir |
    #
    # ---
    # Bu defter ve içindeki veriler öğretim amaçlıdır; ISO/TS standartlarının resmî metni yerine geçmez.


print("\nBitti. Sonuç dosyaları:", CIKTI)
