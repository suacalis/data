# Ek C — Pydroid 3 (Android) paketi

İK Profesyonelleri için Metrik El Kitabı · Ek C. Jupyter defterindeki kodların, **Pydroid 3** uygulamasında doğrudan çalışan düz `.py` sürümü.

## Klasör yapısı
```
Ek_C_Pydroid/
  ek_c_calistir.py        ana betik (C.1–C.14 bölümlerini sırayla çalıştırır)
  moduller_dogrula.py     25 modülün doğrulama çıktılarını çalıştırıp özetler
  kendi_verinle.py        kendi CSV dosyanızla aylık/yıllık devir örneği
  modules/                rehber sayfalarındaki Python modülleri (yalnızca standart kütüphane)
  veri/                   yapay (sentetik) CSV dosyaları
  cikti/                  çalıştırınca oluşur (ozet_metrikler.csv, ozet_grafik.png)
```

## Kurulum (bir kez)
1. Telefonunuza **Pydroid 3** kurun (Play Store).
2. Pydroid 3 ▸ ☰ menü ▸ **Pip** ▸ şu paketleri kurun: `numpy`, `pandas`, `matplotlib`
   (Pydroid'in kendi deposundan kurulur; derleme gerektirmez).
3. ZIP dosyasını bir dosya yöneticisiyle açın ve **Ek_C_Pydroid** klasörünü telefonda kolay bir yere koyun
   (ör. `Dahili depolama/Ek_C_Pydroid`).

## Çalıştırma
1. Pydroid 3 ▸ ☰ ▸ **Open** ▸ `Ek_C_Pydroid/ek_c_calistir.py`
2. Sağ alttaki **▶** düğmesine basın.
3. Çıktı uzundur: yukarı kaydırarak okuyun. Betik, `modules` ve `veri` klasörlerini kendisi bulur.

### Yalnızca bir bölümü çalıştırmak
`ek_c_calistir.py` dosyasının başında `SECILI = []` satırı vardır. Örneğin yalnızca işe alım ve yedekleme bölümleri için:
```python
SECILI = [6, 7]
```
C.1, C.2, C.4, C.5, C.7 ve C.9 hazırlık bölümleri her durumda çalışır (diğer bölümler onlara bağlıdır).

### Grafik
C.13 sonunda bir grafik çizilir ve `cikti/ozet_grafik.png` olarak kaydedilir. Grafiği ekranda görmek istemezseniz `MATPLOTLIB_GOSTER = False` yapın.

## Sorun giderme
| Belirti | Çözüm |
|---|---|
| `HATA: 'modules' ve 'veri' klasörleri bulunamadı` | Dosyayı `Ek_C_Pydroid` klasörünün içinden açın; Pydroid'de ▸ Open ile klasöre girin. |
| `ModuleNotFoundError: pandas` | Pydroid ▸ Pip ▸ `pandas` kurun (numpy ve matplotlib için de aynı). |
| Türkçe karakterler bozuk | Çıktı ekranında yazı tipini değiştirmeyin; dosyalar UTF-8'dir. |
| Çıktı klasörüne yazılamıyor | Betik otomatik olarak geçici klasöre yazar; yolu ekranda gösterir. |

## Kendi verinizle
`kendi_verinle.py` dosyasını açın; `DOSYA`, `AYRAC` ve `SUTUN_ESLEME` değerlerini kendi dosyanıza göre düzenleyin. Kişisel veriyi (ad, TCKN, iletişim) dosyadan çıkarın ve KVKK yükümlülüklerinizi kontrol edin.

## Notlar
- Veriler "Örnek Anonim Sanayi A.Ş." adlı kurgusal kurumun 2025 yılını temsil edecek biçimde **rastgele üretilmiştir**; sonuçlar yöntemi göstermek içindir.
- Modüller, ISO/TS standartlarının öğretim amaçlı Türkçe yorumlarıdır; resmî metin yerine geçmez.
- Python 3.9+ gerekir (Pydroid 3 güncel sürümleri uygundur).
