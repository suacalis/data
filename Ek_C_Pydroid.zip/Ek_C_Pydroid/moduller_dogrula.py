# -*- coding: utf-8 -*-
"""
25 modülün kendi doğrulama çıktısını sırayla çalıştırır ve özet verir (Pydroid 3 için).
Her modül doğrudan çalıştırıldığında örnek değerlerle bir doğrulama çıktısı üretir.
"""
import sys, os, pathlib, runpy, io, contextlib, glob

def paketi_bul():
    adaylar = []
    try: adaylar.append(pathlib.Path(__file__).resolve().parent)
    except NameError: pass
    adaylar.append(pathlib.Path.cwd())
    for t in ["/storage/emulated/0", "/sdcard", os.path.expanduser("~")]:
        for a in ["Ek_C_Pydroid", "Ek_C_Paket"]: adaylar.append(pathlib.Path(t) / a)
    for a in adaylar:
        if (a / "modules").is_dir(): return a
KOK = paketi_bul()
if KOK is None:
    print("'modules' klasörü bulunamadı; bu dosyayı Ek_C_Pydroid klasörünün içinden açın."); raise SystemExit(1)
sys.path.insert(0, str(KOK / "modules"))
tamam, hata = 0, []
for yol in sorted(glob.glob(str(KOK / "modules" / "*.py"))):
    ad = os.path.basename(yol)
    tampon = io.StringIO()
    try:
        with contextlib.redirect_stdout(tampon):
            runpy.run_path(yol, run_name="__main__")
        tamam += 1
        print(f"[OK]   {ad:<32} {len(tampon.getvalue().splitlines()):>3} satır çıktı")
    except SystemExit as e:
        if e.code in (None, 0): tamam += 1; print(f"[OK]   {ad}")
        else: hata.append(ad); print(f"[HATA] {ad}: çıkış kodu {e.code}")
    except Exception as e:
        hata.append(ad); print(f"[HATA] {ad}: {type(e).__name__}: {e}")
print()
print(f"Sonuç: {tamam} modül çalıştı, {len(hata)} hata.")
