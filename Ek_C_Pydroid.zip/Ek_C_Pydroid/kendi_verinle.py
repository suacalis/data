# -*- coding: utf-8 -*-
"""
KENDİ VERİNİZLE KULLANIM (Pydroid 3) — Ek C.14
Kendi çalışan listenizi (CSV) okur, sütun adlarını eşler ve birkaç temel metriği hesaplar.

KULLANIM
  1. CSV dosyanızı bu klasöre koyun (ör. benim_dosyam.csv) ve DOSYA adını aşağıda değiştirin.
  2. SUTUN_ESLEME içinde SOL tarafa kendi sütun adlarınızı yazın.
  3. ▶ ile çalıştırın. Kişisel veri (ad, TCKN) dosyada bulunmamalıdır.
"""
import sys, os, pathlib, warnings
import pandas as pd
warnings.filterwarnings("ignore")   # tarih biçimi uyarılarını gizler

DOSYA = "veri/calisanlar.csv"      # kendi dosyanızla değiştirin, ör. "benim_dosyam.csv"
AYRAC = ","                        # Excel'den gelen dosyalarda genelde ";"
KODLAMA = "utf-8-sig"
YIL = 2025

SUTUN_ESLEME = {                   # SOL: sizin sütun adınız   SAĞ: beklenen ad
    # "Personel No": "sicil_no", "Departman": "birim", "İşe Giriş Tarihi": "ise_baslama_tarihi",
    # "İşten Çıkış Tarihi": "ayrilma_tarihi", "Cinsiyet": "cinsiyet",
}

try: KOK = pathlib.Path(__file__).resolve().parent
except NameError: KOK = pathlib.Path.cwd()
sys.path.insert(0, str(KOK / "modules"))
import iso30421_metrikler as devir

t = pd.read_csv(KOK / DOSYA, sep=AYRAC, encoding=KODLAMA)
t = t.rename(columns=SUTUN_ESLEME)
eksik = {"sicil_no", "ise_baslama_tarihi", "ayrilma_tarihi"} - set(t.columns)
if eksik:
    print("Eksik sütun:", eksik); print("Mevcut sütunlar:", list(t.columns)); raise SystemExit(1)
for s in ["ise_baslama_tarihi", "ayrilma_tarihi"]:
    t[s] = pd.to_datetime(t[s], dayfirst=True, errors="coerce")
t = t.drop_duplicates("sicil_no")

def mevcut(gun):
    return t[(t.ise_baslama_tarihi <= gun) & (t.ayrilma_tarihi.isna() | (t.ayrilma_tarihi > gun))]

oranlar = []
for ay in pd.period_range(f"{YIL}-01", f"{YIL}-12", freq="M"):
    bas = len(mevcut(ay.start_time - pd.Timedelta(days=1)))
    son = len(mevcut(ay.end_time.normalize()))
    ayr = int(((t.ayrilma_tarihi >= ay.start_time) & (t.ayrilma_tarihi <= ay.end_time)).sum())
    if (bas + son) > 0:
        oranlar.append(devir.hesapla("aylik_devir", ayrilan=ayr, ay_basi=bas, ay_sonu=son)["deger"])
print("Aylık devir oranları (%):", [round(x, 2) for x in oranlar])
print(f"Yıllık devir (aylıkların toplamı): {sum(oranlar):.2f} %")
print("Kayıt sayısı:", len(t), "| Yıl sonu çalışan:", len(mevcut(pd.Timestamp(YIL, 12, 31))))
