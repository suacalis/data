EK E — RAPORLAMA ŞABLONLARI
İç ve dış insan sermayesi raporu için kontrol listeleri
(İK Profesyonelleri için Metrik El Kitabı · ISO 30414:2025 tabanlı)

DOSYALAR
E1_Ic_Rapor/
  Ic_Insan_Sermayesi_Raporu_Kontrol_Listesi.xltx   Excel şablonu (70 metrik, hazırlık ve TCFD listeleri, otomatik özet)
  Ic_Insan_Sermayesi_Raporu_Sablonu.dotx           Word rapor şablonu
E2_Dis_Rapor/
  Dis_Insan_Sermayesi_Raporu_Kontrol_Listesi.xltx  Excel şablonu (38 metrik, çerçeve uyumu, otomatik özet)
  Dis_Insan_Sermayesi_Raporu_Sablonu.dotx          Word rapor şablonu

KULLANIM
- .xltx / .dotx dosyalarına çift tıklayınca Excel/Word şablondan YENİ bir belge oluşturur; şablonun kendisi değişmez.
- Excel: Okuyunuz → Künye → Hazırlık_Listesi → TCFD_Açıklama → Metrik_Kontrol sırasıyla doldurun. Sarı hücreler girişe açıktır; Özet sayfası otomatik hesaplanır.
- Word: gri, köşeli parantezli metinleri doldurun; ☐ maddeleri tamamlandıkça ☒ yapın. Kapaktaki kullanım notunu yayından önce silin.

KAPSAM
- 70 kalemlik metrik matrisi ISO 30414:2025 rehber sayfasındaki matristen alınmıştır: 14 zorunlu (Tablo 3), 55 önerilen (Tablo 4), 1 kuruma özgü.
- İç şablon 70 kalemin tamamını içerir (KOBİ sütunu 45 kalemi işaretler). Dış şablon büyük kurum dış raporlaması için işaretlenen 38 kalemi içerir.
- Hazırlık maddeleri ve ‘Çerçeve_Uyumu’ listesi genel iyi uygulama niteliğindedir; kurum politikanıza göre uyarlayın.

NOT
Bu şablonlar ISO standartlarının öğretim amaçlı Türkçe yorumuna dayanır; standart metninin yerine geçmez. Resmî metin için ilgili ISO/TSE yayınına başvurunuz.
