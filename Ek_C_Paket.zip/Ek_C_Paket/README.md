# Ek C — Python Kod Örnekleri ve Veri Hazırlama

İK Profesyonelleri için Metrik El Kitabı'nın Ek C paketi.

## İçerik
- `Ek_C_Python_Kod_Ornekleri.ipynb` — ana defter (çıktılarıyla birlikte)
- `modules/` — rehber sayfalarındaki gömülü Python modülleri (`isoXXXXX_metrikler.py`, 25 adet; ISO 30405 için `iso30405_isealim.py`)
- `veri/` — yapay (sentetik) CSV dosyaları ve `veri_sozlugu.csv`

## Başlangıç
```bash
pip install -r requirements.txt
jupyter notebook Ek_C_Python_Kod_Ornekleri.ipynb   # defteri bu klasörde açın
```
Defter, `modules/` ve `veri/` klasörlerini çalışma dizininden okur; bu yüzden paket klasörünün içinde başlatın.

## Veriler hakkında
Tüm veriler "Örnek Anonim Sanayi A.Ş." adlı kurgusal kurumun 2025 yılını temsil edecek biçimde **rastgele üretilmiştir** (sabit tohum: 30414). Gerçek kişi ya da kuruma ait değildir. Veri hazırlama alıştırması için bilinçli olarak şu sorunlar eklenmiştir: 3 yinelenen sicil, 2 mantıksız tarih, 6 boş cinsiyet, 14 boş performans puanı.

Sonuçlar yöntemi göstermek içindir; yorum ya da kıyas amacıyla kullanılmamalıdır.

## Modüller
Modüller yalnızca Python standart kütüphanesini kullanır (3.9+). Her biri `hesapla(kimlik, **girdiler)` işlevi, `METRIK_LISTESI` ve metrik başına fonksiyonlar sunar; doğrudan çalıştırıldığında (`python modules/iso30421_metrikler.py`) örnek verilerle doğrulama çıktısı verir.
Modüller ISO/TS standartlarının öğretim amaçlı Türkçe yorumlarıdır; resmî metin yerine geçmez.
