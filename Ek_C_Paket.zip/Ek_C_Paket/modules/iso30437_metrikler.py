#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30437_metrikler.py
=====================
ISO/TS 30437:2023 (Human resource management — Learning and development metrics)
çerçevesindeki hesaplanabilir öğrenme ve gelişim (Ö&G) metriklerinin Python karşılığı.

Metrikler standardın sınıflandırmasına göre üç bölümde toplanmıştır:

    1) Verimlilik  (efficiency) — nicelik: kaç kişi, kaç kurs, ne maliyet
    2) Etkililik   (effectiveness) — nitelik: Kirkpatrick/Phillips düzey 1, 2, 3, 5
    3) Sonuç       (outcome) — düzey 4: kurumsal göstergedeki değişimin öğrenmeye düşen payı

Kullanım:
    from iso30437_metrikler import tamamlanma_orani, yatirim_getirisi
    tamamlanma_orani(1100, 1200)   ->  91.67

Doğrudan çalıştırıldığında (python3 iso30437_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30437:2023'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from statistics import mean
from typing import Iterable, Sequence

__all__ = [
    # verimlilik
    "tamamlanma_orani", "erisim", "ortalama_bicimsel_saat", "tze",
    "kullanim_orani", "toplam_maliyet", "maliyet_per_ogrenen",
    "zamaninda_yuzdesi", "kategori_dagilimi", "bgp_yuzdesi",
    # etkililik
    "olumlu_yuzde", "ortalama_likert", "ilk_denemede_gecme",
    "ortalama_deneme", "uygulama_orani", "yatirim_getirisi",
    "fayda_maliyet_orani",
    # sonuç
    "izole_etki", "katilimci_tahmini", "isgucu_yetkinlik_orani",
    # yardımcı
    "Program", "denge_denetimi", "hesapla", "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# Yardımcı
# ---------------------------------------------------------------------------

def _oran(pay: float, payda: float, yuzde: bool = True) -> float:
    """Sıfıra bölmeyi anlamlı bir hatayla karşılar."""
    if payda == 0:
        raise ValueError("Payda sıfır olamaz — metrik tanımsız.")
    return (100.0 * pay / payda) if yuzde else (pay / payda)


# ===========================================================================
# 1) VERİMLİLİK METRİKLERİ
# ===========================================================================

def tamamlanma_orani(tamamlayan: int, payda: int) -> float:
    """Tamamlanma oranı (%).

    Payda olarak hedef kitle ya da kayıtlı sayısı kullanılabilir; hangisinin
    kullanıldığı raporda belirtilmeli ve dönemler arasında değiştirilmemelidir.

    >>> round(tamamlanma_orani(81, 100), 1)
    81.0
    >>> round(tamamlanma_orani(81, 90), 1)
    90.0
    """
    return _oran(tamamlayan, payda)


def erisim(tekil_katilimci: int, toplam_calisan: int) -> float:
    """Erişim / reach (%): öğrenmeye erişen çalışan yüzdesi.

    Tekil katılımcı kullanılır (aynı kişi kaç kursa girerse girsin bir kez sayılır).
    Biçimsel ve izlenebilen biçimsel olmayan öğrenme için ayrı ayrı hesaplanabilir.
    """
    return _oran(tekil_katilimci, toplam_calisan)


def ortalama_bicimsel_saat(toplam_saat: float, calisan_sayisi: int) -> float:
    """Ortalama biçimsel öğrenme saati (saat/çalışan). ISO 30414 önerisi.

    Eşitliği görünür kılmak için kategori, cinsiyet ve kıdem kırılımıyla birlikte
    raporlanması önerilir.
    """
    return _oran(toplam_saat, calisan_sayisi, yuzde=False)


def tze(tam_zamanli: int, kismi_zamanli_oranlari: Sequence[float]) -> float:
    """Ö&G biriminde tam zaman eşdeğeri personel (TZE).

    Yarı zamanlı iki çalışan bir TZE'ye karşılık gelir.

    >>> tze(22, [0.5] * 8)
    26.0
    """
    return tam_zamanli + float(sum(kismi_zamanli_oranlari))


def kullanim_orani(kullanilan: float, mevcut: float) -> float:
    """Kullanım oranı (%). Kurs, tekil saat, doküman, performans destek aracı,
    eğitmen ve derslik için aynı formül geçerlidir.

    Düşük oran, varlığın yararını ya da duyurusunu sorgulamak için tetikleyicidir.
    """
    return _oran(kullanilan, mevcut)


def toplam_maliyet(merkezi: float, is_birimleri: Iterable[float] | float = 0.0,
                   ogrenim_geri_odemesi: float = 0.0) -> float:
    """Kurumun toplam öğrenme maliyeti.

    Katılımcı zamanının fırsat maliyetini ve katılımcı seyahatini içermez;
    eğitmen seyahatini içerir.
    """
    if isinstance(is_birimleri, (int, float)):
        birim_toplam = float(is_birimleri)
    else:
        birim_toplam = float(sum(is_birimleri))
    return float(merkezi) + birim_toplam + float(ogrenim_geri_odemesi)


def maliyet_per_ogrenen(toplam: float, tekil_katilimci: int) -> float:
    """Öğrenen başına maliyet. Toplam maliyet tek başına yorumlanmaz."""
    return _oran(toplam, tekil_katilimci, yuzde=False)


def zamaninda_yuzdesi(zamaninda: int, toplam: int) -> float:
    """Zamanında geliştirilen/sunulan kurs yüzdesi (%). Ö&G birimi disiplin ölçüsü."""
    return _oran(zamaninda, toplam)


def kategori_dagilimi(kurslar: dict[str, float]) -> dict[str, float]:
    """Öğrenme türüne göre dağılım (%).

    kurslar: {'sınıf içi': 25, 'sanal': 51, 'e-öğrenme': 98, 'mobil': 10, 'karma': 24}
    Kurs sayısı yerine saat de verilebilir; iki bakış farklı sonuç üretir.
    """
    toplam = sum(kurslar.values())
    if toplam == 0:
        raise ValueError("Toplam sıfır — dağılım hesaplanamaz.")
    return {k: 100.0 * v / toplam for k, v in kurslar.items()}


def bgp_yuzdesi(plani_olan: int, toplam_calisan: int) -> float:
    """Bireysel gelişim planı olan çalışan yüzdesi (%)."""
    return _oran(plani_olan, toplam_calisan)


# ===========================================================================
# 2) ETKİLİLİK METRİKLERİ (Kirkpatrick / Phillips düzey 1, 2, 3, 5)
# ===========================================================================

def olumlu_yuzde(yanitlar: Sequence[float], esik: float = 4.0) -> float:
    """Düzey 1 — olumlu yüzde (%).

    Beşli ölçekte üst iki kutu (4 ve 5) olumlu sayılır. Yedili ölçekte esik=6.
    Katılımcı tepkisi, amaç sahibi memnuniyeti ve biçimsel olmayan öğrenme
    memnuniyeti aynı biçimde raporlanır.
    """
    if not yanitlar:
        raise ValueError("Yanıt listesi boş.")
    return 100.0 * sum(1 for y in yanitlar if y >= esik) / len(yanitlar)


def ortalama_likert(yanitlar: Sequence[float]) -> float:
    """Düzey 1 — ham ortalama Likert puanı (ör. 4,3 / 5)."""
    if not yanitlar:
        raise ValueError("Yanıt listesi boş.")
    return mean(yanitlar)


def ilk_denemede_gecme(ilk_denemede_gecen: int, sinava_giren: int) -> float:
    """Düzey 2 — ilk denemede geçme oranı (%)."""
    return _oran(ilk_denemede_gecen, sinava_giren)


def ortalama_deneme(toplam_deneme: int, gecen_kisi: int) -> float:
    """Düzey 2 — geçmek için ortalama deneme sayısı.

    1'e yakın değer beklenir; yükseliyorsa sınav ya da materyal sorgulanır.
    """
    return _oran(toplam_deneme, gecen_kisi, yuzde=False)


def uygulama_orani(uygulanan_yuzdeler: Sequence[float]) -> float:
    """Düzey 3 — uygulama oranı (%).

    Katılımcı başına 'uygulayabildiğim içerik yüzdesi' yanıtlarının ortalaması.
    Kurs sonunda ölçülen 'uygulama niyeti' ile 2–3 ay sonraki 'gerçek uygulama'
    ayrı ayrı hesaplanır; aradaki fark aktarım kaybını gösterir.
    """
    if not uygulanan_yuzdeler:
        raise ValueError("Uygulama listesi boş.")
    return mean(uygulanan_yuzdeler)


def yatirim_getirisi(brut_fayda: float, program_maliyeti: float,
                     firsat_maliyeti: float = 0.0) -> float:
    """Düzey 5 — yatırım getirisi, YG (%).

    YG = (net fayda / toplam maliyet) x 100
    Toplam maliyet: geliştirme + sunum + yönetim + katılımcı zamanının fırsat maliyeti.
    %0, yatırımın tam olarak kendini karşıladığı noktadır.

    >>> round(yatirim_getirisi(100_000, 25_000, 30_000))
    82
    """
    toplam = program_maliyeti + firsat_maliyeti
    if toplam == 0:
        raise ValueError("Toplam maliyet sıfır olamaz.")
    return 100.0 * (brut_fayda - toplam) / toplam


def fayda_maliyet_orani(brut_fayda: float, program_maliyeti: float,
                        firsat_maliyeti: float = 0.0) -> float:
    """Fayda–maliyet oranı. YG'nin 1 eklenmiş hâlidir (1,82 <-> %82)."""
    toplam = program_maliyeti + firsat_maliyeti
    return _oran(brut_fayda, toplam, yuzde=False)


# ===========================================================================
# 3) SONUÇ METRİKLERİ (düzey 4)
# ===========================================================================

def izole_etki(kurumsal_degisim: float, katki_yuzdesi: float) -> float:
    """Düzey 4 (Phillips) — öğrenmenin izole etkisi.

    Kurumsal göstergedeki değişim ile öğrenmenin katkı yüzdesinin çarpımıdır.
    Örnek: satış %6 arttı, öğrenmenin katkısı %30 -> öğrenmeye düşen artış %1,8.

    >>> round(izole_etki(6, 30), 1)
    1.8
    """
    return kurumsal_degisim * katki_yuzdesi / 100.0


def katilimci_tahmini(kayitlar: Sequence[tuple[float, float]]) -> float:
    """Katılımcı tahmini yöntemiyle güven düzeltilmiş izole etki (%).

    kayitlar: [(etki_tahmini_%, guven_%), ...]
    Her katılımcının etki tahmini kendi güven düzeyiyle çarpılır, ortalaması alınır.
    Örneklem en az 30 olmalıdır (katılımcı sayısı 30'un altındaysa herkes).

    >>> round(katilimci_tahmini([(70,50),(50,40),(90,80),(70,90),(80,80),(0,0)]), 1)
    42.3
    """
    if not kayitlar:
        raise ValueError("Kayıt listesi boş.")
    if len(kayitlar) < 30:
        import warnings
        warnings.warn("Örneklem 30'un altında; sonuç güvenilirliği sınırlıdır.",
                      stacklevel=2)
    return mean(e * g / 100.0 for e, g in kayitlar)


def isgucu_yetkinlik_orani(birimler: Sequence[tuple[int, float]]) -> float:
    """İşgücü yetkinlik oranı — birim büyüklüğüne göre ağırlıklı ortalama.

    birimler: [(calisan_sayisi, yetkinlik_puani), ...]
    Ayrıntılı hesap kuralları ISO/TS 30428'de tanımlanır.

    >>> round(isgucu_yetkinlik_orani([(1000, 4.4), (600, 4.6), (400, 4.1)]), 2)
    4.4
    """
    toplam = sum(n for n, _ in birimler)
    if toplam == 0:
        raise ValueError("Toplam çalışan sıfır olamaz.")
    return sum(n * p for n, p in birimler) / toplam


# ===========================================================================
# 4) DENGE DENETİMİ — standardın "dengeli metrik kümesi" ilkesi
# ===========================================================================

@dataclass
class Program:
    """Bir programın ölçüm kümesi. Hangi tür metriklerin seçildiğini tutar."""
    ad: str
    kurumsal_amaca_bagli: bool = False
    verimlilik: list[str] = field(default_factory=list)
    etkililik: list[str] = field(default_factory=list)
    sonuc: list[str] = field(default_factory=list)


def denge_denetimi(p: Program) -> list[str]:
    """Standardın dengeli küme ilkesine göre uyarı listesi döndürür.

    - En az bir verimlilik ve bir etkililik metriği bulunmalıdır.
    - Program bir kurumsal amacı destekliyorsa bir sonuç metriği eklenmelidir.
    """
    uyarilar = []
    if not p.verimlilik:
        uyarilar.append("Verimlilik metriği yok: nicelik (katılım, maliyet, kullanım) ölçülmüyor.")
    if not p.etkililik:
        uyarilar.append("Etkililik metriği yok: kalite ölçülmediği için hız kaliteyi bastırabilir.")
    if p.kurumsal_amaca_bagli and not p.sonuc:
        uyarilar.append("Program kurumsal bir amaca bağlı ancak sonuç (düzey 4) metriği tanımlanmamış.")
    if not p.kurumsal_amaca_bagli and p.sonuc:
        uyarilar.append("Kurumsal amaca bağlı olmayan programda sonuç metriği yerine "
                        "öğrenen düzeyinde sonuç (yetkinlik artışı) kullanılması yeterlidir.")
    return uyarilar


# ===========================================================================
# 5) DAĞITICI — HTML hesaplayıcısının Pyodide üzerinden çağırdığı arayüz
# ===========================================================================

METRIK_LISTESI = [
    "tamamlanma", "erisim", "ortsaat", "kullanim", "tze", "maliyet",
    "tepki", "ogrenme", "uygulama", "etki", "guven", "roi", "yetkinlik",
]


def _s(x) -> str:
    """Sayıyı Türkçe ondalık ayırıcıyla, gereksiz sıfır olmadan yazar."""
    if isinstance(x, float) and x == int(x):
        return str(int(x))
    if isinstance(x, float):
        return f"{x:g}".replace(".", ",")
    return str(x)


def _sonuc(deger: float, birim: str, ondalik: int, ifade: str,
           ayrinti: Sequence[tuple[str, object]] = ()) -> dict:
    return {
        "deger": float(deger),
        "birim": birim,
        "ondalik": ondalik,
        "ifade": ifade,
        "ayrinti": [[a, b] for a, b in ayrinti],
    }


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle tek bir hesaplama sonucu döndürür.

    Sözlük anahtarları: deger, birim, ondalik, ifade, ayrinti.
    HTML hesaplayıcısı bu fonksiyonu Pyodide üzerinden çağırır; aynı fonksiyon
    komut satırından da kullanılabilir:

    >>> hesapla("tamamlanma", tamamlayan=1100, payda=1200)["deger"]
    91.66666666666667
    """
    if metrik == "tamamlanma":
        d = tamamlanma_orani(g["tamamlayan"], g["payda"])
        return _sonuc(d, "%", 1, f"({_s(g['tamamlayan'])} ÷ {_s(g['payda'])}) × 100",
                      [("Tamamlamayan", g["payda"] - g["tamamlayan"])])

    if metrik == "erisim":
        d = erisim(g["tekil_katilimci"], g["toplam_calisan"])
        return _sonuc(d, "%", 1, f"({_s(g['tekil_katilimci'])} ÷ {_s(g['toplam_calisan'])}) × 100",
                      [("Hiç öğrenmeye katılmayan çalışan",
                        g["toplam_calisan"] - g["tekil_katilimci"])])

    if metrik == "ortsaat":
        d = ortalama_bicimsel_saat(g["toplam_saat"], g["calisan_sayisi"])
        return _sonuc(d, "saat/çalışan", 1, f"{_s(g['toplam_saat'])} ÷ {_s(g['calisan_sayisi'])}",
                      [("İş günü karşılığı (8 saat)", round(d / 8, 1))])

    if metrik == "kullanim":
        d = kullanim_orani(g["kullanilan"], g["mevcut"])
        return _sonuc(d, "%", 1, f"({_s(g['kullanilan'])} ÷ {_s(g['mevcut'])}) × 100",
                      [("Hiç kullanılmayan varlık", g["mevcut"] - g["kullanilan"])])

    if metrik == "tze":
        oranlar = [g["calisma_orani"]] * int(g["kismi_zamanli"])
        d = tze(g["tam_zamanli"], oranlar)
        return _sonuc(d, "TZE", 1,
                      f"{_s(g['tam_zamanli'])} + ({_s(g['kismi_zamanli'])} × {_s(g['calisma_orani'])})",
                      [("Toplam kişi sayısı", g["tam_zamanli"] + g["kismi_zamanli"])])

    if metrik == "maliyet":
        d = toplam_maliyet(g["merkezi"], g["is_birimi"], g["geri_odeme"])
        kisi = maliyet_per_ogrenen(d, g["tekil_katilimci"])
        return _sonuc(d, "bin TL", 0,
                      f"{_s(g['merkezi'])} + {_s(g['is_birimi'])} + {_s(g['geri_odeme'])}",
                      [("Öğrenen başına maliyet (bin TL)", round(kisi, 3)),
                       ("Öğrenen başına maliyet (TL)", round(kisi * 1000))])

    if metrik == "tepki":
        d = _oran(g["olumlu"], g["yanitlayan"])
        return _sonuc(d, "% olumlu", 1, f"({_s(g['olumlu'])} ÷ {_s(g['yanitlayan'])}) × 100",
                      [("Olumsuz veya nötr yanıt", g["yanitlayan"] - g["olumlu"])])

    if metrik == "ogrenme":
        d = ilk_denemede_gecme(g["ilk_denemede_gecen"], g["sinava_giren"])
        return _sonuc(d, "%", 1,
                      f"({_s(g['ilk_denemede_gecen'])} ÷ {_s(g['sinava_giren'])}) × 100",
                      [("Geçmek için ortalama deneme",
                        round(ortalama_deneme(g["toplam_deneme"], g["sinava_giren"]), 1))])

    if metrik == "uygulama":
        d = uygulama_orani([g["gercek"]])
        return _sonuc(d, "% içerik", 0, f"izleme anketi ortalaması = {_s(g['gercek'])}",
                      [("Niyet ile gerçek arasındaki fark (puan)",
                        round(g["niyet"] - g["gercek"], 1))])

    if metrik == "etki":
        d = izole_etki(g["kurumsal_degisim"], g["katki_yuzdesi"])
        return _sonuc(d, "% (izole)", 2,
                      f"%{_s(g['kurumsal_degisim'])} × %{_s(g['katki_yuzdesi'])}",
                      [("Öğrenme dışı etkenlere düşen değişim (%)",
                        round(g["kurumsal_degisim"] - d, 2))])

    if metrik == "guven":
        d = g["etki_tahmini"] * g["guven_duzeyi"] / 100.0
        return _sonuc(d, "% katkı", 1,
                      f"%{_s(g['etki_tahmini'])} × %{_s(g['guven_duzeyi'])}",
                      [("Örneklem yeterliliği",
                        "yeterli (≥30)" if g["yanitlayan"] >= 30 else "yetersiz (<30)"),
                       ("Güven düzeltmesiyle düşen puan", round(g["etki_tahmini"] - d, 1))])

    if metrik == "roi":
        d = yatirim_getirisi(g["brut_fayda"], g["program_maliyeti"], g["firsat_maliyeti"])
        toplam = g["program_maliyeti"] + g["firsat_maliyeti"]
        return _sonuc(d, "% YG", 1,
                      f"(({_s(g['brut_fayda'])} − {_s(toplam)}) ÷ {_s(toplam)}) × 100",
                      [("Toplam program maliyeti (bin TL)", toplam),
                       ("Net fayda (bin TL)", round(g["brut_fayda"] - toplam, 1)),
                       ("Fayda–maliyet oranı",
                        round(fayda_maliyet_orani(g["brut_fayda"], g["program_maliyeti"],
                                                  g["firsat_maliyeti"]), 2))])

    if metrik == "yetkinlik":
        birimler = [(g["a_calisan"], g["a_puan"]),
                    (g["b_calisan"], g["b_puan"]),
                    (g["c_calisan"], g["c_puan"])]
        d = isgucu_yetkinlik_orani(birimler)
        n = sum(x for x, _ in birimler)
        ifade = "(" + " + ".join(f"{_s(x)}×{_s(p)}" for x, p in birimler) + f") ÷ {_s(n)}"
        return _sonuc(d, "/ 5", 2, ifade,
                      [("Toplam çalışan", n)] +
                      [(f"{ad} ağırlığı", round(x / n, 2))
                       for ad, (x, _) in zip("ABC", birimler)])

    raise KeyError(f"Bilinmeyen metrik: {metrik!r}. Seçenekler: {', '.join(METRIK_LISTESI)}")


# ===========================================================================
# ÖRNEK ÇALIŞTIRMA
# ===========================================================================

def _satir(etiket: str, deger: str) -> None:
    print(f"{etiket:.<40} {deger:>12}")


def _demo() -> None:
    print("=" * 54)
    print("ISO/TS 30437 — Ö&G METRİKLERİ, ÖRNEK HESAPLAMALAR")
    print("=" * 54)

    print("\n[1] VERİMLİLİK")
    _satir("Tamamlanma oranı (1100 / 1200 hedef kitle)",
           f"%{tamamlanma_orani(1100, 1200):.1f}")
    _satir("Erişim (12.895 tekil / 13.000 çalışan)",
           f"%{erisim(12_895, 13_000):.1f}")
    _satir("Ortalama biçimsel saat (580.000 / 13.000)",
           f"{ortalama_bicimsel_saat(580_000, 13_000):.1f} sa")
    _satir("Ö&G TZE (22 tam + 8 yarı zamanlı)",
           f"{tze(22, [0.5] * 8):.1f}")
    _satir("Kurs kullanım oranı (291 / 301)",
           f"%{kullanim_orani(291, 301):.1f}")
    _satir("BGP kapsaması (10.400 / 13.000)",
           f"%{bgp_yuzdesi(10_400, 13_000):.1f}")
    _satir("Zamanında sunulan kurs (138 / 146)",
           f"%{zamaninda_yuzdesi(138, 146):.1f}")

    toplam = toplam_maliyet(1_300_000, [400_000, 300_000, 430_000], 800_000)
    _satir("Toplam öğrenme maliyeti", f"{toplam:,.0f} TL".replace(",", "."))
    _satir("Öğrenen başına maliyet (3.256 tekil)",
           f"{maliyet_per_ogrenen(toplam, 3_256):,.0f} TL".replace(",", "."))

    dagilim = kategori_dagilimi({"sınıf içi": 25, "sanal sınıf": 51,
                                 "e-öğrenme": 98, "mobil": 10, "karma": 24})
    print("\n    Öğrenme türüne göre kurs dağılımı:")
    for tur, pay in dagilim.items():
        print(f"      {tur:.<26} %{pay:.0f}")

    print("\n[2] ETKİLİLİK (Kirkpatrick / Phillips)")
    tepkiler = [5, 4, 4, 5, 3, 4, 5, 2, 4, 4]
    _satir("Düzey 1 — olumlu yüzde (5'li ölçek)",
           f"%{olumlu_yuzde(tepkiler):.0f}")
    _satir("Düzey 1 — ortalama Likert", f"{ortalama_likert(tepkiler):.1f} / 5")
    _satir("Düzey 2 — ilk denemede geçme (830 / 1000)",
           f"%{ilk_denemede_gecme(830, 1000):.0f}")
    _satir("Düzey 2 — geçmek için ortalama deneme",
           f"{ortalama_deneme(1700, 1000):.1f}")
    _satir("Düzey 3 — uygulama niyeti",
           f"%{uygulama_orani([75, 80, 85, 70, 90]):.0f}")
    _satir("Düzey 3 — gerçek uygulama (3 ay sonra)",
           f"%{uygulama_orani([60, 70, 75, 60, 75]):.0f}")
    _satir("Düzey 5 — YG (100.000 fayda; 25.000 + 30.000)",
           f"%{yatirim_getirisi(100_000, 25_000, 30_000):.1f}")
    _satir("Düzey 5 — fayda/maliyet oranı",
           f"{fayda_maliyet_orani(100_000, 25_000, 30_000):.2f}")

    print("\n[3] SONUÇ (düzey 4)")
    _satir("İzole etki (satış %12, katkı %25)",
           f"%{izole_etki(12, 25):.1f}")
    kayitlar = [(70, 50), (50, 40), (90, 80), (70, 90), (80, 80), (0, 0)]
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        guven = katilimci_tahmini(kayitlar)
    _satir("Güven düzeltilmiş katkı (6 yanıtlayan)", f"%{guven:.1f}")
    _satir("Bu katkıyla izole etki (satış %10)",
           f"%{izole_etki(10, guven):.2f}")
    _satir("İşgücü yetkinlik oranı (1000/600/400)",
           f"{isgucu_yetkinlik_orani([(1000, 4.4), (600, 4.6), (400, 4.1)]):.2f} / 5")

    print("\n[4] DENGE DENETİMİ")
    p = Program(
        ad="Danışmanlık satış becerileri",
        kurumsal_amaca_bagli=True,
        verimlilik=["tekil katılımcı", "tamamlanma oranı", "toplam maliyet"],
        etkililik=["katılımcı tepkisi", "öğrenme", "uygulama oranı"],
        sonuc=[],
    )
    print(f"    Program: {p.ad}")
    uyarilar = denge_denetimi(p)
    if uyarilar:
        for u in uyarilar:
            print(f"      ! {u}")
    else:
        print("      Metrik kümesi dengeli.")

    print("\n[5] DAĞITICI (HTML hesaplayıcısının çağırdığı arayüz)")
    r = hesapla("roi", brut_fayda=100, program_maliyeti=25, firsat_maliyeti=30)
    print(f"    hesapla('roi', ...) -> {r['deger']:.1f} {r['birim']}  |  {r['ifade']}")
    for etiket, deger in r["ayrinti"]:
        print(f"      {etiket:.<38} {deger}")

    print("\n" + "=" * 54)


if __name__ == "__main__":
    _demo()

