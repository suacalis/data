#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30408_metrikler.py
=====================
BS ISO 30408:2016 (Human resource management — Guidelines on human governance)
çerçevesindeki insan yönetişimi raporlama ve değerlendirme kavramlarının Python karşılığı.

Standart bir rehberdir: formül ya da eşik vermez. Hedef, ölçü, izleme takvimi, sonuç
ve "kabul edilebilir sonuç aralığı" (6.3.3 g) kavramlarını; Ek A'da hedef/sonuç ve
değer uyumu (ilkeyi güçlendirir, zayıflatır ya da nötr) şablonlarını verir. Bu modüldeki
tüm hesaplar bu kavramları sayıya dökmek için TÜRETİLMİŞTİR. Modül üç bölüme ayrılmıştır:

    1) Ölçüler  — hedef sapması, kabul edilebilir aralık, değer uyum puanı, oranlar, kapsama
    2) Yapılar  — öz değerlendirme tablosu, sonuç tablosu (A.2/A.3), değer uyumu (A.4), uygulama denetimi
    3) Dağıtıcı — hesaplayıcının kullandığı tek giriş noktası

Kullanım:
    from iso30408_metrikler import hedef_sapmasi, aralik_sapmasi
    hedef_sapmasi(100, 92)         ->  -8.0
    aralik_sapmasi(92, 95, 110)    ->  -3.0

Doğrudan çalıştırıldığında (python3 iso30408_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Kavramlar ISO 30408:2016'ya dayanır. Oranlar, sapma ve puanlama kuralları bu
modülde türetilmiştir. Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi
telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi", "ALANLAR", "UYGULAMA_ADIMLARI",
    "hedef_sapmasi", "aralik_sapmasi", "uyum_puani", "baglanti_orani", "algi_orani",
    "izleme_orani", "katilim_orani", "kapsama",
    "Alan", "OzDegerlendirme", "ornek_tablo", "SonucSatiri", "SonucTablosu", "ornek_sonuclar",
    "UyumMatrisi", "ornek_uyum", "uygulama_denetimi", "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, negatif değer, aralık ters vb."""


# Her madde için "kurum şunu yapmalı" ifadelerinin sayısı (6.3.4 için son analiz soruları)
ALANLAR = [
    ("5.2", "Yönetim kurulu", 4),
    ("5.3", "Üst yönetim", 7),
    ("5.4.1", "Operasyonel yönetim işlevleri", 3),
    ("5.4.2", "İnsan yönetişimi güvenceleri", 4),
    ("5.4.3", "Üst yönetimin nihai hesap verebilirliği", 3),
    ("6.1", "Yönetişimi ihtiyaçlara hizalama", 4),
    ("6.2", "İletişim", 4),
    ("6.3.3", "İşlev, uygulama ve süreçlerin belirlenmesi", 11),
    ("6.3.4", "Analiz soruları", 8),
    ("7", "Uygulama adımları", 9),
]

# Madde 7: kurulum için dokuz temel adım (a–i)
UYGULAMA_ADIMLARI = {
    "a": "İlkeleri tanımla ve kuruma uygunluğunu doğrula",
    "b": "İnsan yönetişimi çerçevesi geliştir",
    "c": "Hedefleri iş planıyla hizala",
    "d": "İlişkili proje ve girişimleri belirle ve hizala",
    "e": "İlkeleri tüm kurumsal iletişime entegre et",
    "f": "İK işlev, uygulama ve süreçlerini ilkelerle hizalamak için gözden geçir",
    "g": "Her düzeyde etkin katılımı teşvik et",
    "h": "İlkelerin uygulanmasını ve izlenmesini tanımlı ölçülerle sağla",
    "i": "İlkeleri performans, kültür ve faaliyetlere nasıl entegre edeceğini netleştir",
}


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


# ---------------------------------------------------------------------------
# 1) Ölçüler (madde 5.3, 6.3.3, 6.3.4, Ek A)
# ---------------------------------------------------------------------------

def hedef_sapmasi(hedef: float, sonuc: float) -> float:
    """Hedefe göre sapma (%): (sonuç − hedef) ÷ hedef × 100."""
    _negatif_yok(sonuc=sonuc)
    return 100 * _bol(sonuc - hedef, hedef, "hedef")


def aralik_sapmasi(sonuc: float, alt: float, ust: float) -> float:
    """Sonucun kabul edilebilir aralığın dışına çıkma miktarı: içindeyse 0, altında negatif, üstünde pozitif."""
    if alt > ust:
        raise GecersizGirdi("alt sınır üst sınırdan büyük olamaz")
    _negatif_yok(sonuc=sonuc, alt=alt)
    if sonuc < alt:
        return sonuc - alt
    if sonuc > ust:
        return sonuc - ust
    return 0.0


def uyum_puani(guclendirir: float, notr: float, zayiflatir: float) -> float:
    """Değer uyum puanı (−100…+100): (güçlendiren − zayıflatan) ÷ toplam × 100."""
    _negatif_yok(guclendirir=guclendirir, notr=notr, zayiflatir=zayiflatir)
    return 100 * _bol(guclendirir - zayiflatir, guclendirir + notr + zayiflatir, "toplam değerlendirme")


def _oran(parca: float, butun: float, ad: str, ad_butun: str) -> float:
    _negatif_yok(**{ad: parca})
    if parca > butun:
        raise GecersizGirdi(f"{ad} {ad_butun} sayısını aşamaz")
    return 100 * _bol(parca, butun, ad_butun)


def baglanti_orani(bagli: float, toplam: float) -> float:
    """Kurumsal hedefe ya da KPI'ya bağlı hedef/ölçü oranı (%): bağlı ÷ toplam × 100."""
    return _oran(bagli, toplam, "bagli", "toplam")


def algi_orani(olumlu: float, yanit: float) -> float:
    """Çalışan ve müşterilerin ilkelerin hayata geçirildiğini düşünme oranı (%)."""
    return _oran(olumlu, yanit, "olumlu", "yanit")


def izleme_orani(tamamlanan: float, planlanan: float) -> float:
    """İzleme takvimine uyum (%): tamamlanan gözden geçirme ÷ planlanan × 100."""
    return _oran(tamamlanan, planlanan, "tamamlanan", "planlanan")


def katilim_orani(katilan: float, hedef_kitle: float) -> float:
    """Paydaş katılım oranı (%): katılan ÷ hedef kitle × 100."""
    return _oran(katilan, hedef_kitle, "katilan", "hedef_kitle")


def kapsama(toplam: float, uygulanan: float, kismen: float = 0) -> float:
    """İfadelerin uygulama kapsaması (%): (uygulanan + 0,5 × kısmen) ÷ toplam × 100."""
    _negatif_yok(uygulanan=uygulanan, kismen=kismen)
    if uygulanan + kismen > toplam:
        raise GecersizGirdi("uygulanan ve kısmen uygulanan toplamı ifade sayısını aşamaz")
    return 100 * _bol(uygulanan + 0.5 * kismen, toplam, "ifade sayısı")


# ---------------------------------------------------------------------------
# 2) Yapılar
# ---------------------------------------------------------------------------

@dataclass
class Alan:
    """Öz değerlendirme tablosunda bir madde."""
    kod: str
    ad: str
    toplam: int
    uygulanan: float = 0
    kismen: float = 0

    def kapsama(self) -> float:
        return kapsama(self.toplam, self.uygulanan, self.kismen)


@dataclass
class OzDegerlendirme:
    """Madde 5–7 öz değerlendirme tablosu. Hedef kapsama kurumca belirlenir (varsayılan %70)."""
    alanlar: list = field(default_factory=lambda: [Alan(k, a, n) for k, a, n in ALANLAR])
    hedef: float = 70.0

    def gir(self, kod: str, uygulanan: float, kismen: float = 0) -> "OzDegerlendirme":
        for a in self.alanlar:
            if a.kod == kod:
                a.uygulanan, a.kismen = uygulanan, kismen
                a.kapsama()  # doğrulama
                return self
        raise GecersizGirdi(f"bilinmeyen madde: {kod}")

    def ozet(self) -> dict:
        toplam = sum(a.toplam for a in self.alanlar)
        uyg = sum(a.uygulanan for a in self.alanlar)
        kis = sum(a.kismen for a in self.alanlar)
        oranlar = [(a.kapsama(), a.kod) for a in self.alanlar]
        en_zayif = oranlar[0]
        for o in oranlar[1:]:
            if o[0] < en_zayif[0]:
                en_zayif = o
        return {
            "alan_sayisi": len(self.alanlar),
            "toplam_ifade": toplam,
            "genel_kapsama": round(kapsama(toplam, uyg, kis), 1),
            "hedef_alti": [k for o, k in oranlar if o < self.hedef],
            "en_zayif": en_zayif[1],
        }


def ornek_tablo() -> OzDegerlendirme:
    """Örnek amaçlı doldurulmuş tablo (standart bu sayıları vermez)."""
    t = OzDegerlendirme()
    for kod, u, k in [("5.2", 3, 1), ("5.3", 4, 2), ("5.4.1", 2, 1), ("5.4.2", 2, 1), ("5.4.3", 2, 1),
                      ("6.1", 3, 1), ("6.2", 2, 1), ("6.3.3", 6, 3), ("6.3.4", 4, 2), ("7", 5, 2)]:
        t.gir(kod, u, k)
    return t


@dataclass
class SonucSatiri:
    """Ek A.2/A.3 şablonu: bir işlev ya da uygulama için hedef, kabul edilebilir aralık ve sonuç."""
    ad: str
    hedef: float
    alt: float
    ust: float
    sonuc: float

    def sapma(self) -> float:
        return hedef_sapmasi(self.hedef, self.sonuc)

    def durum(self) -> str:
        d = aralik_sapmasi(self.sonuc, self.alt, self.ust)
        return "aralık içinde" if d == 0 else ("aralığın altında" if d < 0 else "aralığın üstünde")


@dataclass
class SonucTablosu:
    satirlar: list = field(default_factory=list)

    def ekle(self, ad, hedef, alt, ust, sonuc) -> "SonucTablosu":
        self.satirlar.append(SonucSatiri(ad, hedef, alt, ust, sonuc))
        return self

    def ozet(self) -> dict:
        durumlar = {s.ad: s.durum() for s in self.satirlar}
        disinda = [ad for ad, d in durumlar.items() if d != "aralık içinde"]
        return {"satir_sayisi": len(self.satirlar), "durumlar": durumlar, "aralik_disinda": disinda}


def ornek_sonuclar() -> SonucTablosu:
    """Örnek amaçlı üç ölçü (standart bu sayıları vermez)."""
    t = SonucTablosu()
    t.ekle("Gönüllü ayrılma (%)", 8, 5, 10, 11.5)
    t.ekle("Devamsızlık (%)", 3, 2, 4, 3.2)
    t.ekle("Eğitim saati / çalışan", 24, 20, 40, 18)
    return t


@dataclass
class UyumMatrisi:
    """Ek A.4: her araç ve süreç, her ilkeyi güçlendirir (+1), nötrdür (0) ya da zayıflatır (−1)."""
    ilkeler: list
    satirlar: dict = field(default_factory=dict)

    def ekle(self, ad: str, degerler: list) -> "UyumMatrisi":
        if len(degerler) != len(self.ilkeler):
            raise GecersizGirdi("her ilke için bir değer gerekir")
        for v in degerler:
            if v not in (-1, 0, 1):
                raise GecersizGirdi("değerler -1, 0 ya da +1 olmalı")
        self.satirlar[ad] = degerler
        return self

    def ozet(self) -> dict:
        n = len(self.ilkeler)
        arac = {ad: round(100 * sum(v) / n, 1) for ad, v in self.satirlar.items()}
        ilke = {}
        for j, ad in enumerate(self.ilkeler):
            sutun = [v[j] for v in self.satirlar.values()]
            ilke[ad] = round(100 * sum(sutun) / len(sutun), 1)
        zayiflatan = [ad for ad, v in self.satirlar.items() if -1 in v]
        return {"arac_puani": arac, "ilke_puani": ilke, "zayiflatan_arac": zayiflatan}


def ornek_uyum() -> UyumMatrisi:
    """Örnek amaçlı matris: üç ilke (adillik, açıklık, hesap verebilirlik) ve üç araç."""
    m = UyumMatrisi(["Adillik ve şeffaflık", "Açıklık", "Hesap verebilirlik"])
    m.ekle("Performans değerlendirme formu", [1, 0, 1])
    m.ekle("Yıllık çalışan anketi", [0, 1, 1])
    m.ekle("Gizli ücret politikası", [-1, -1, 0])
    return m


def uygulama_denetimi(**adimlar: bool) -> list:
    """Madde 7'nin dokuz adımına göre eksikleri listeler (a–i; verilmeyen adım yapılmamış sayılır)."""
    for k in adimlar:
        if k not in UYGULAMA_ADIMLARI:
            raise GecersizGirdi(f"bilinmeyen adım: {k}")
    return [f"{k}) {metin}" for k, metin in UYGULAMA_ADIMLARI.items() if not adimlar.get(k, False)]


# ---------------------------------------------------------------------------
# 3) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["sapma", "aralik", "uyum", "baglanti", "algi", "izleme", "katilim", "kapsama"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "sapma":
        d = hedef_sapmasi(g["hedef"], g["sonuc"])
        return {"deger": d, "ondalik": 1, "birim": "% (hedefe göre sapma)",
                "ifade": f"({_g(g['sonuc'])} − {_g(g['hedef'])}) ÷ {_g(g['hedef'])} × 100",
                "ayrinti": [["Mutlak sapma", round(g["sonuc"] - g["hedef"], 2)],
                            ["Hedefin yüzdesi olarak (%)", round(100 * g["sonuc"] / g["hedef"], 1)]]}

    if metrik == "aralik":
        d = aralik_sapmasi(g["sonuc"], g["alt"], g["ust"])
        durum = "aralık içinde" if d == 0 else ("aralığın altında" if d < 0 else "aralığın üstünde")
        return {"deger": d, "ondalik": 1, "birim": "birim (aralık dışı sapma)",
                "ifade": f"{_g(g['sonuc'])} ile [{_g(g['alt'])}, {_g(g['ust'])}] aralığı",
                "ayrinti": [["Durum", durum],
                            ["Aralık genişliği", round(g["ust"] - g["alt"], 2)]]}

    if metrik == "uyum":
        d = uyum_puani(g["guclendirir"], g["notr"], g["zayiflatir"])
        return {"deger": d, "ondalik": 1, "birim": "puan (−100…+100)",
                "ifade": f"({_g(g['guclendirir'])} − {_g(g['zayiflatir'])}) ÷ ({_g(g['guclendirir'])} + {_g(g['notr'])} + {_g(g['zayiflatir'])}) × 100",
                "ayrinti": [["Toplam değerlendirme", round(g["guclendirir"] + g["notr"] + g["zayiflatir"], 2)],
                            ["Zayıflatanların payı (%)", round(100 * g["zayiflatir"] / (g["guclendirir"] + g["notr"] + g["zayiflatir"]), 1)]]}

    if metrik == "baglanti":
        d = baglanti_orani(g["bagli"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% (bağlı ÷ toplam)",
                "ifade": f"{_g(g['bagli'])} ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Bağlantısı olmayan", round(g["toplam"] - g["bagli"], 2)]]}

    if metrik == "algi":
        d = algi_orani(g["olumlu"], g["yanit"])
        return {"deger": d, "ondalik": 1, "birim": "% (olumlu ÷ yanıt)",
                "ifade": f"{_g(g['olumlu'])} ÷ {_g(g['yanit'])} × 100",
                "ayrinti": [["Olumlu olmayan yanıt", round(g["yanit"] - g["olumlu"], 2)],
                            ["Olumlu olmayanların payı (%)", round(100 - d, 1)]]}

    if metrik == "izleme":
        d = izleme_orani(g["tamamlanan"], g["planlanan"])
        return {"deger": d, "ondalik": 1, "birim": "% (tamamlanan ÷ planlanan)",
                "ifade": f"{_g(g['tamamlanan'])} ÷ {_g(g['planlanan'])} × 100",
                "ayrinti": [["Geciken gözden geçirme", round(g["planlanan"] - g["tamamlanan"], 2)]]}

    if metrik == "katilim":
        d = katilim_orani(g["katilan"], g["hedef_kitle"])
        return {"deger": d, "ondalik": 1, "birim": "% (katılan ÷ hedef kitle)",
                "ifade": f"{_g(g['katilan'])} ÷ {_g(g['hedef_kitle'])} × 100",
                "ayrinti": [["Katılmayan", round(g["hedef_kitle"] - g["katilan"], 2)]]}

    if metrik == "kapsama":
        d = kapsama(g["toplam"], g["uygulanan"], g["kismen"])
        return {"deger": d, "ondalik": 1, "birim": "% (kapsama)",
                "ifade": f"({_g(g['uygulanan'])} + 0,5 × {_g(g['kismen'])}) ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Hiç uygulanmayan ifade", round(g["toplam"] - g["uygulanan"] - g["kismen"], 2)],
                            ["Yalnızca tam uygulananların payı (%)", round(100 * g["uygulanan"] / g["toplam"], 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 4) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30408 — doğrulama çıktısı")
    print(cizgi)
    print(f"Hedef sapması (100→92)   : {hedef_sapmasi(100, 92):+.1f} %")
    print(f"Aralık (92 / 95–110)     : {aralik_sapmasi(92, 95, 110):+.1f}")
    print(f"Uyum puanı (5,3,2)       : {uyum_puani(5, 3, 2):+.1f}")
    print(f"Bağlantı (6/8)           : %{baglanti_orani(6, 8):.1f}")
    print(f"Algı (310/420)           : %{algi_orani(310, 420):.1f}")
    print(f"İzleme (9/12)            : %{izleme_orani(9, 12):.1f}")
    print(f"Kapsama (11, 6, 3)       : %{kapsama(11, 6, 3):.1f}")
    print(cizgi)

    for anahtar, deger in ornek_tablo().ozet().items():
        print(f"{anahtar:<14}: {deger}")
    print(cizgi)
    print(ornek_sonuclar().ozet())
    print(ornek_uyum().ozet())
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("sapma", hedef=100, sonuc=92))
    print(cizgi)

    print("Uygulama denetimi (yalnızca a, b ve c yapılmış):")
    for u in uygulama_denetimi(a=True, b=True, c=True):
        print(" !", u)


if __name__ == "__main__":
    _demo()
