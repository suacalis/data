#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30405_isealim.py
===================
ISO 30405:2023 (Human resource management — Guidelines on recruitment)
çerçevesindeki ölçümlerin Python karşılığı.

ISO 30405 bir rehber standarttır; ölçüme ilişkin içeriği iki ektedir:
  - Ek A.4: işveren markasının işe alıma etkisini gösteren ölçüm örnekleri
  - Ek B.2: yapay zekâ araçlarının sınıflandırma başarımı
Ana metin ayrıca aday/vakans oranını (4.5.2) değerlendirme tasarımının
belirleyicisi olarak tanımlar ve etkili değerlendirmenin parasal faydasına
(4.5.4, Not 1) atıf yapar.

Modül bölümleri:
    1) Başvuru ve aday havuzu
    2) Karar ve işe başlama
    3) İşe alım sonrası
    4) Yapay zekâ araçları
    5) Değerlendirme faydası (türetilmiş)
    6) Huni ve süreç denetimi
    7) Dağıtıcı: hesapla()

Kullanım:
    from iso30405_isealim import teklif_kabul_orani
    teklif_kabul_orani(kabul=12, teklif=15)   ->  80.0

Doğrudan çalıştırıldığında (python3 iso30405_isealim.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar yazdırılır.

Not: Aşama adları ve ölçüm örnekleri ISO 30405:2023'e dayanır. Formüllerin
işlemselleştirilmesi, kod ve açıklamalar özgündür; standart telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "aday_vakans_orani", "havuz_gecis_orani", "nitelikli_basvuru_orani",
    "kendiliginden_basvuru_payi", "referans_yogunlugu",
    "ortalama_doldurma", "teklif_kabul_orani", "zamaninda_baslama_orani",
    "elde_tutma_orani", "terfi_orani",
    "siniflandirma_metrikleri", "secilme_orani_karsilastirma",
    "degerlendirme_faydasi",
    "HUNI_ASAMALARI", "Huni", "ornek_huni", "surec_denetimi",
    "hesapla", "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Başvuru ve aday havuzu
# ---------------------------------------------------------------------------

def aday_vakans_orani(basvuru: float, pozisyon: float) -> float:
    """Açık pozisyon başına başvuru (4.5.2).

    Oran yüksekse ilk değerlendirme aşaması uygun olmayanları elemeye,
    düşükse her adayın kapasitesini anlamaya odaklanır.
    """
    return basvuru / pozisyon


def havuz_gecis_orani(havuza_gecen: float, basvuru: float) -> float:
    """Aday havuzuna geçen başvuru yüzdesi (Ek A.4 c)."""
    return 100 * havuza_gecen / basvuru


def nitelikli_basvuru_orani(karsilayan: float, basvuru: float) -> float:
    """Bilgi, beceri ve yeteneği iş gerekliliklerini karşılayan ya da aşan
    başvuranların yüzdesi (Ek A.4 d)."""
    return 100 * karsilayan / basvuru


def kendiliginden_basvuru_payi(kendiliginden: float, basvuru: float) -> float:
    """İlan ya da kampanyaya bağlı olmayan başvuruların yüzdesi (Ek A.4 b)."""
    return 100 * kendiliginden / basvuru


def referans_yogunlugu(referans: float, pozisyon: float) -> float:
    """Pozisyon başına çalışan referansı (Ek A.4 i)."""
    return referans / pozisyon


# ---------------------------------------------------------------------------
# 2) Karar ve işe başlama
# ---------------------------------------------------------------------------

def ortalama_doldurma(toplam_gun: float, pozisyon: float) -> float:
    """Bir boşluğu doldurmanın ortalama süresi, gün (Ek A.4 f).
    Ölçüm noktalarının tanımı için ISO/TS 30430'a bakılır."""
    return toplam_gun / pozisyon


def teklif_kabul_orani(kabul: float, teklif: float) -> float:
    """Teklifin kabule dönüşme yüzdesi (Ek A.4 g)."""
    return 100 * kabul / teklif


def zamaninda_baslama_orani(zamaninda: float, kabul: float) -> float:
    """Seçilen adaylardan planlanan tarihte işe başlayanların yüzdesi (Ek A.4 h)."""
    return 100 * zamaninda / kabul


# ---------------------------------------------------------------------------
# 3) İşe alım sonrası
# ---------------------------------------------------------------------------

def elde_tutma_orani(kalan: float, ise_alinan: float) -> float:
    """Belirli bir süre sonra (6 ay, 1 yıl) çalışmaya devam eden yeni
    çalışanların yüzdesi (Ek A.4 j). Karşılaştırma için aynı süre korunur."""
    return 100 * kalan / ise_alinan


def terfi_orani(terfi: float, ise_alinan: float) -> float:
    """Kurum için olağan sürede terfi eden yeni çalışanların yüzdesi (Ek A.4 k)."""
    return 100 * terfi / ise_alinan


# ---------------------------------------------------------------------------
# 4) Yapay zekâ araçları (Ek B.2)
# ---------------------------------------------------------------------------

def siniflandirma_metrikleri(dp: float, yp: float, yn: float, dn: float) -> dict:
    """Başvuranı ya da metni sınıflandıran araçların düzeltilmemiş başarımı.

    dp: doğru pozitif, yp: yanlış pozitif, yn: yanlış negatif, dn: doğru negatif.
    F1, kesinlik ile duyarlılığın harmonik ortalamasıdır.
    """
    n = dp + yp + yn + dn
    kes = dp / (dp + yp) if (dp + yp) else 0.0
    duy = dp / (dp + yn) if (dp + yn) else 0.0
    f1 = 2 * kes * duy / (kes + duy) if (kes + duy) else 0.0
    return {"dogruluk": (dp + dn) / n, "kesinlik": kes,
            "duyarlilik": duy, "f1": f1, "n": n}


def secilme_orani_karsilastirma(a_basvuru: float, a_secilen: float,
                                b_basvuru: float, b_secilen: float) -> dict:
    """İki grubun seçilme oranlarını karşılaştırır (türetilmiş).

    Standart, algoritmanın korunan özelliklere göre ayrımcılık yapmadığının
    ampirik olarak gösterilmesini ister. Düşük oranın yüksek orana bölümü
    (seçilme oranı oranı) bu denetimin yaygın bir göstergesidir; dörtte beş
    (0,80) eşiği standarttan değil uygulamadan gelir.
    """
    ra = a_secilen / a_basvuru
    rb = b_secilen / b_basvuru
    return {"a": ra, "b": rb, "oran": min(ra, rb) / max(ra, rb)}


# ---------------------------------------------------------------------------
# 5) Değerlendirme faydası (türetilmiş)
# ---------------------------------------------------------------------------

def degerlendirme_faydasi(secilen: float, sure_yil: float, gecerlilik: float,
                          sdy: float, zx: float, maliyet: float) -> dict:
    """Seçim faydası: N × T × r × SDy × Zx − C (Brogden–Cronbach–Gleser).

    Standart, etkili değerlendirmenin çalışanın kıdemi boyunca yüksek parasal
    değer üretebileceğini belirtip literatüre atıf yapar; formül oradan gelir.
    secilen: işe alınan kişi, sure_yil: ortalama kıdem, gecerlilik: aracın
    ölçüt geçerliği, sdy: performansın parasal standart sapması (TL/yıl),
    zx: seçilenlerin ortalama standart puanı, maliyet: toplam değerlendirme
    maliyeti.
    """
    brut = secilen * sure_yil * gecerlilik * sdy * zx
    return {"brut": brut, "net": brut - maliyet}


# ---------------------------------------------------------------------------
# 6) Huni ve süreç denetimi
# ---------------------------------------------------------------------------

HUNI_ASAMALARI = [
    "Başvuru",
    "Ön elemeyi geçen (aday havuzu)",
    "Değerlendirme — 1. aşama",
    "Değerlendirme — 2. aşama",
    "Teklif yapılan",
    "Teklifi kabul eden",
    "Planlanan tarihte başlayan",
    "6. ayda çalışmaya devam eden",
]


@dataclass
class Huni:
    """İşe alım hunisi: her aşamadaki kişi sayısı."""
    sayilar: list = field(default_factory=list)
    pozisyon: int = 1

    def gecisler(self) -> list:
        ilk = self.sayilar[0]
        satirlar = []
        for i, (ad, s) in enumerate(zip(HUNI_ASAMALARI, self.sayilar)):
            if i == 0 or not self.sayilar[i - 1]:
                onceki = None
            else:
                onceki = round(100 * s / self.sayilar[i - 1], 1)
            satirlar.append({"asama": ad, "sayi": s, "onceki_gore": onceki,
                             "basvuruya_gore": round(100 * s / ilk, 2) if ilk else None})
        return satirlar

    def ozet(self) -> dict:
        s = self.sayilar
        g = self.gecisler()
        dar = min(g[1:], key=lambda r: r["onceki_gore"])
        return {
            "pozisyon": self.pozisyon,
            "aday_vakans": round(s[0] / self.pozisyon, 1),
            "havuz_gecis": round(100 * s[1] / s[0], 1),
            "teklif_kabul": round(100 * s[5] / s[4], 1),
            "zamaninda_baslama": round(100 * s[6] / s[5], 1),
            "elde_tutma_6ay": round(100 * s[7] / s[6], 1),
            "basvurudan_baslamaya": round(100 * s[6] / s[0], 2),
            "en_dar_gecis": dar["asama"],
            "en_dar_gecis_orani": dar["onceki_gore"],
        }


def ornek_huni() -> Huni:
    """On iki pozisyonluk örnek işe alım dönemi."""
    return Huni([480, 96, 40, 18, 15, 12, 10, 9], pozisyon=12)


def surec_denetimi(talep_resmi: bool = False,
                   kisi_profili_analizle: bool = False,
                   paydaslar_belirli: bool = False,
                   veri_saklama_kurali: bool = False,
                   kanal_cesitlilik_etkisi: bool = False,
                   degerlendirme_kanitli: bool = False,
                   yz_belgelenmis: bool = False,
                   reddedilenlere_bilgi: bool = False,
                   yetenek_havuzu: bool = False,
                   surec_sonrasi_degerlendirme: bool = False) -> list:
    """Bir işe alım sürecinin standarda göre eksiklerini listeler."""
    kontroller = [
        (talep_resmi, "Kadro talebi resmîleştirilmemiş: sürecin türü (boşalan iş, "
                      "yeni iş, toplu alım) belirsiz."),
        (kisi_profili_analizle, "Kişi profili yapılandırılmış gereklilik analizine "
                                "dayanmıyor: ölçütler önyargı taşıyabilir."),
        (paydaslar_belirli, "Paydaş listesi ve katılım planı yok: takvim ve karar "
                            "aşamaları aksayabilir."),
        (veri_saklama_kurali, "Aday verisi için saklama süresi ve erişim kuralı "
                              "tanımlanmamış."),
        (kanal_cesitlilik_etkisi, "Kanal önceliği belirlenirken çeşitlilik etkisi "
                                  "değerlendirilmemiş."),
        (degerlendirme_kanitli, "Değerlendirme araçlarının etkililik kanıtı ve yorum "
                                "gerekçesi istenmemiş (ISO 10667)."),
        (yz_belgelenmis, "Yapay zekâ aracı için eğitim verisi, başarım metrikleri ve "
                         "ayrımcılık testi belgelenmemiş (Ek B)."),
        (reddedilenlere_bilgi, "İşe alınmayan adaylar bilgilendirilmiyor ve "
                               "teşekkür edilmiyor."),
        (yetenek_havuzu, "Yetkin ama alınmayan adaylar yetenek havuzunda "
                         "tutulmuyor."),
        (surec_sonrasi_degerlendirme, "Süreç sonrası değerlendirme yapılmıyor: "
                                      "öğrenme döngüsü kapanmıyor."),
    ]
    return [mesaj for durum, mesaj in kontroller if not durum]


# ---------------------------------------------------------------------------
# 7) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "aday_vakans", "havuz_gecis", "nitelikli_basvuru", "kendiliginden",
    "referans", "doldurma_suresi", "teklif_kabul", "zamaninda",
    "elde_tutma", "terfi", "ai_performans", "secilme_orani",
    "degerlendirme_faydasi",
]


def hesapla(metrik: str, **g) -> dict:
    """Ölçüm kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "aday_vakans":
        d = aday_vakans_orani(g["basvuru"], g["pozisyon"])
        return {"deger": d, "ondalik": 1, "birim": "başvuru / pozisyon",
                "ifade": f"{g['basvuru']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Pozisyon başına elenmesi gereken başvuru", round(d - 1, 1)],
                            ["İlk değerlendirme aşamasının odağı",
                             "uygun olmayanları eleme" if d >= 10 else "her adayı tanıma"]]}

    if metrik == "havuz_gecis":
        d = havuz_gecis_orani(g["havuza_gecen"], g["basvuru"])
        return {"deger": d, "ondalik": 1, "birim": "% havuza geçen",
                "ifade": f"({g['havuza_gecen']:g} ÷ {g['basvuru']:g}) × 100",
                "ayrinti": [["Elenen başvuru", g["basvuru"] - g["havuza_gecen"]],
                            ["Havuza giren bir aday için başvuru",
                             round(g["basvuru"] / g["havuza_gecen"], 1)]]}

    if metrik == "nitelikli_basvuru":
        d = nitelikli_basvuru_orani(g["karsilayan"], g["basvuru"])
        return {"deger": d, "ondalik": 1, "birim": "% gereklilikleri karşılayan",
                "ifade": f"({g['karsilayan']:g} ÷ {g['basvuru']:g}) × 100",
                "ayrinti": [["Pozisyon başına gereklilikleri karşılayan",
                             round(g["karsilayan"] / g["pozisyon"], 1)],
                            ["Karşılamayan başvuru", g["basvuru"] - g["karsilayan"]]]}

    if metrik == "kendiliginden":
        d = kendiliginden_basvuru_payi(g["kendiliginden"], g["basvuru"])
        return {"deger": d, "ondalik": 1, "birim": "% kendiliğinden başvuru",
                "ifade": f"({g['kendiliginden']:g} ÷ {g['basvuru']:g}) × 100",
                "ayrinti": [["İlan ve kampanyayla gelen başvuru",
                             g["basvuru"] - g["kendiliginden"]]]}

    if metrik == "referans":
        d = referans_yogunlugu(g["referans"], g["pozisyon"])
        return {"deger": d, "ondalik": 2, "birim": "referans / pozisyon",
                "ifade": f"{g['referans']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Referanstan işe alım oranı (%)",
                             round(100 * g["referans_ise_alinan"] / g["referans"], 1)],
                            ["Referansla dolan pozisyon payı (%)",
                             round(100 * g["referans_ise_alinan"] / g["pozisyon"], 1)]]}

    if metrik == "doldurma_suresi":
        d = ortalama_doldurma(g["toplam_gun"], g["pozisyon"])
        return {"deger": d, "ondalik": 1, "birim": "gün",
                "ifade": f"{g['toplam_gun']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Hafta karşılığı", round(d / 7, 1)]]}

    if metrik == "teklif_kabul":
        d = teklif_kabul_orani(g["kabul"], g["teklif"])
        return {"deger": d, "ondalik": 1, "birim": "% kabul",
                "ifade": f"({g['kabul']:g} ÷ {g['teklif']:g}) × 100",
                "ayrinti": [["Reddedilen teklif", g["teklif"] - g["kabul"]],
                            ["Kabul başına yapılan teklif",
                             round(g["teklif"] / g["kabul"], 2)]]}

    if metrik == "zamaninda":
        d = zamaninda_baslama_orani(g["zamaninda"], g["kabul"])
        return {"deger": d, "ondalik": 1, "birim": "% zamanında başlayan",
                "ifade": f"({g['zamaninda']:g} ÷ {g['kabul']:g}) × 100",
                "ayrinti": [["Geç başlayan ya da başlamayan",
                             g["kabul"] - g["zamaninda"]]]}

    if metrik == "elde_tutma":
        d = elde_tutma_orani(g["kalan"], g["ise_alinan"])
        return {"deger": d, "ondalik": 1, "birim": f"% elde tutma ({g['ay']:g} ay)",
                "ifade": f"({g['kalan']:g} ÷ {g['ise_alinan']:g}) × 100",
                "ayrinti": [["Ayrılan yeni çalışan", g["ise_alinan"] - g["kalan"]],
                            ["Ölçüm süresi (ay)", g["ay"]]]}

    if metrik == "terfi":
        d = terfi_orani(g["terfi"], g["ise_alinan"])
        return {"deger": d, "ondalik": 1, "birim": "% terfi eden",
                "ifade": f"({g['terfi']:g} ÷ {g['ise_alinan']:g}) × 100",
                "ayrinti": [["Terfi etmeyen", g["ise_alinan"] - g["terfi"]],
                            ["Gözlem süresi (ay)", g["sure_ay"]]]}

    if metrik == "ai_performans":
        m = siniflandirma_metrikleri(g["dp"], g["yp"], g["yn"], g["dn"])
        p, r = m["kesinlik"], m["duyarlilik"]
        return {"deger": m["f1"], "ondalik": 3, "birim": "F1 puanı",
                "ifade": f"2 × {p:.3f} × {r:.3f} ÷ ({p:.3f} + {r:.3f})",
                "ayrinti": [["Doğruluk", round(m["dogruluk"], 3)],
                            ["Kesinlik", round(p, 3)],
                            ["Duyarlılık", round(r, 3)],
                            ["Toplam vaka", m["n"]]]}

    if metrik == "secilme_orani":
        m = secilme_orani_karsilastirma(g["a_basvuru"], g["a_secilen"],
                                        g["b_basvuru"], g["b_secilen"])
        dusuk, yuksek = min(m["a"], m["b"]), max(m["a"], m["b"])
        return {"deger": m["oran"], "ondalik": 2, "birim": "seçilme oranları oranı",
                "ifade": f"{dusuk * 100:.1f} % ÷ {yuksek * 100:.1f} %",
                "ayrinti": [["A grubu seçilme oranı (%)", round(100 * m["a"], 1)],
                            ["B grubu seçilme oranı (%)", round(100 * m["b"], 1)],
                            ["Fark (yüzde puan)", round(100 * abs(m["a"] - m["b"]), 1)]]}

    if metrik == "degerlendirme_faydasi":
        m = degerlendirme_faydasi(g["secilen"], g["sure_yil"], g["gecerlilik"],
                                  g["sdy"], g["zx"], g["maliyet"])
        return {"deger": m["net"], "ondalik": 0, "birim": "TL (net fayda)",
                "ifade": (f"{g['secilen']:g} × {g['sure_yil']:g} × {g['gecerlilik']:g} × "
                          f"{g['sdy']:g} × {g['zx']:g} − {g['maliyet']:g}"),
                "ayrinti": [["Brüt fayda (TL)", round(m["brut"])],
                            ["Seçilen kişi başına net fayda (TL)",
                             round(m["net"] / g["secilen"])],
                            ["Fayda / maliyet", round(m["brut"] / g["maliyet"], 2)]]}

    raise ValueError(f"Bilinmeyen ölçüm: {metrik}")


# ---------------------------------------------------------------------------
# 8) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def _demo() -> None:
    cizgi = "-" * 66
    print("ISO 30405 — doğrulama çıktısı")
    print(cizgi)

    h = ornek_huni()
    print(f"{'Aşama':<34}{'Sayı':>6}{'Önceki %':>11}{'Başvuru %':>12}")
    for r in h.gecisler():
        onceki = "—" if r["onceki_gore"] is None else f"{r['onceki_gore']:.1f}"
        print(f"{r['asama']:<34}{r['sayi']:>6}{onceki:>11}{r['basvuruya_gore']:>12.2f}")
    print(cizgi)
    for k, v in h.ozet().items():
        print(f"{k:<22}: {v}")
    print(cizgi)

    m = siniflandirma_metrikleri(80, 20, 40, 860)
    print("Yapay zekâ aracı (dp=80, yp=20, yn=40, dn=860)")
    print(f"  doğruluk {m['dogruluk']:.3f} · kesinlik {m['kesinlik']:.3f} · "
          f"duyarlılık {m['duyarlilik']:.3f} · F1 {m['f1']:.3f}")
    s = secilme_orani_karsilastirma(200, 40, 150, 18)
    print(f"Seçilme oranı oranı : {s['oran']:.2f}  (A {100*s['a']:.1f} %, B {100*s['b']:.1f} %)")
    f = degerlendirme_faydasi(12, 3, 0.4, 120000, 0.8, 600000)
    print(f"Değerlendirme faydası: brüt {_tl(f['brut'])} TL, net {_tl(f['net'])} TL")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("teklif_kabul", teklif=15, kabul=12))
    print(cizgi)

    print("Süreç denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in surec_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
