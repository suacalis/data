#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30433_metrikler.py
=====================
ISO/TS 30433:2021 (Human resource management — Succession planning metrics
cluster) çerçevesindeki yedekleme planlaması metriklerinin Python karşılığı.

Standart, ISO 30414'ün "yedekleme planlaması" kümesini üç ana metrik üzerinden
tanımlar ve dört ek ölçütle genişletir. Modül dört bölüme ayrılmıştır:

    1) Sonuç ve genişlik — yedekleme etkililiği, yedek kapsama oranı,
       havuz büyüme oranı, havuzdan devir
    2) Derinlik          — üç ufuklu hazırlık oranı, pozisyon başına hazır aday,
       yetkinlik eşleşme yüzdesi, çalışan yedek gücü
    3) Açık              — hazır adayı olmayan pozisyon oranı, risk endeksi
    4) Tablo             — pozisyon grubu bazlı küme özeti

Kullanım:
    from iso30433_metrikler import etkililik_orani, kapsama_orani
    etkililik_orani(25, 40)     ->  62.5
    kapsama_orani(24, 44)       ->  54.5454...

Doğrudan çalıştırıldığında (python3 iso30433_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30433:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

__all__ = [
    # sonuç ve genişlik
    "etkililik_orani", "dis_alim_payi", "kapsama_orani", "havuz_buyume",
    "havuz_devir",
    # derinlik
    "hazirlik_orani", "derinlik", "eslesme_yuzdesi", "yedek_gucu_orani",
    # açık ve kaynak
    "hazir_adayi_yok_orani", "risk_endeksi", "gelisim_yatirimi",
    # tablo
    "PozisyonGrubu", "YedeklemeTablosu", "ornek_tablo", "metrik_denetimi",
    # dağıtıcı
    "hesapla", "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Sonuç ve genişlik
# ---------------------------------------------------------------------------

def etkililik_orani(ic_yedekleme: float, toplam_yedekleme: float) -> float:
    """Yedekleme etkililiği (%) = iç yedekleme / toplam kritik pozisyon yedeklemesi.

    Kritik pozisyonların, dışarıdan alım yerine içeriden terfiyle doldurulma
    yüzdesidir. Standart, örnek olarak %70 ile %80 arasındaki bir oranı iyi
    yedekleme etkililiğinin işareti sayar. Kritik pozisyon, kurumsal sonuçlar
    üzerinde doğrudan ve belirgin etkisi olan iş rolüdür.
    """
    return 100 * ic_yedekleme / toplam_yedekleme


def dis_alim_payi(dis_alim: float, toplam_yedekleme: float) -> float:
    """Kritik pozisyonların dışarıdan doldurulma payı (%).

    Dış alım üst düzey pozisyonlarda dışarıdan uzmanlık ve rakip bilgisi
    getirmesi bakımından yararlı olabilir; buna karşılık işe alım süresi ve
    maliyeti yüksektir ve kurumsal bilginin uygulanmasında boşluk yaratır.
    """
    return 100 * dis_alim / toplam_yedekleme


def kapsama_orani(havuz: float, lider: float) -> float:
    """Yedek kapsama oranı (%) = havuzdaki çalışan / toplam lider sayısı.

    Sonucun %100 olması, yedek bekleyen liderlik pozisyonu sayısı kadar
    potansiyel yedek bulunduğu anlamına gelir. Bu bir genişlik ölçüsüdür:
    geniş bir havuz, adayların gerektiğinde devralmaya hazır olacağını
    garanti etmez.
    """
    return 100 * havuz / lider


def havuz_buyume(cari: float, onceki: float) -> float:
    """Havuz büyüme oranı (%) = (cari mevcut − önceki mevcut) / önceki mevcut.

    Oranın pozitif olması için havuza katılanların, havuzdan çıkanları
    (ayrılanlar ya da listeden çıkarılanlar) aşması gerekir; bu nedenle iki
    hareket de tutarlı biçimde izlenir.
    """
    return 100 * (cari - onceki) / onceki


def havuz_devir(ayrilan: float, havuz: float) -> float:
    """Havuzdan devir oranı (%) — türetilmiş.

    Yüksek potansiyellilerin devri ve elde tutulması, havuzun büyüme oranını
    doğrudan etkiler. Standart bu oranı ayrı bir formül olarak vermez;
    büyüme oranının bileşenini görünür kılmak için eklenmiştir.
    """
    return 100 * ayrilan / havuz


# ---------------------------------------------------------------------------
# 2) Derinlik
# ---------------------------------------------------------------------------

def hazirlik_orani(hazir_aday: float, kritik_pozisyon: float) -> float:
    """Yedekleme hazırlık (derinlik) oranı (%).

    Aynı formül üç ufuk için de kullanılır: şimdi hazır, 1–3 yılda hazır,
    4–5 yılda hazır. Büyük kurumlarda üç düzeyin birden iç raporlamada
    kullanılması önerilir. Rakip avlanmasının yoğun olduğu sektörlerde
    ufuklar 3–6 aya ya da 3–6 aylık döngülere çekilebilir.
    """
    return 100 * hazir_aday / kritik_pozisyon


def derinlik(hazir_aday: float, kritik_pozisyon: float) -> float:
    """Pozisyon başına hazır aday — türetilmiş.

    Oran değil, derinlik ölçüsüdür: kaç hazır yedekin gerekli olduğu kurumun
    kendi tahminine dayanır (pozisyonun kritikliği, adayların hazırlık düzeyi
    ve beklenen devir).
    """
    return hazir_aday / kritik_pozisyon


def eslesme_yuzdesi(mevcut_puan: float, gelecek_gereklilik: float) -> float:
    """Yetkinlik eşleşme yüzdesi = mevcut ağırlıklı ortalama / gelecek gereklilik.

    Görev, insan ve liderlik yetkinlik alanları için ayrı ayrı hesaplanır ve
    bir beceri matrisi skor kartında toplanır. Değerlendirmelerin birden çok
    kaynaktan ve kanıta dayalı olması, önyargının en aza indirilmesi şarttır.
    """
    return 100 * mevcut_puan / gelecek_gereklilik


def yedek_gucu_orani(esigi_karsilayan: float, havuz: float) -> float:
    """Yedek gücünün havuza oranı (%).

    Çalışan yedek gücü bir sayımdır: birden çok performans ve değerlendirme
    alanında asgari yetkinlik eşiklerini karşılayan havuz üyelerinin toplam
    sayısı. Eşikleri kurum dengeli skor kartı yaklaşımıyla kendisi belirler.
    """
    return 100 * esigi_karsilayan / havuz


# ---------------------------------------------------------------------------
# 3) Açık ve kaynak
# ---------------------------------------------------------------------------

def hazir_adayi_yok_orani(pozisyon_sayisi: float, toplam_pozisyon: float) -> float:
    """Hazır adayı olmayan pozisyon oranı (%).

    Ölçüm döneminin sonundaki kadro verisiyle hesaplanır. Hedefi sıfıra yakın
    olan tek metriktir. Kapsama ya da etkililik oranının doğrudan tersi
    değildir; pozisyonlar ve nüfuslar genelinde ortalamalarla çalışır.
    """
    return 100 * pozisyon_sayisi / toplam_pozisyon


def risk_endeksi(hazir_adayi_yok_oran: float, kapsama_oran: float,
                 hazirlik_oran: float) -> float:
    """Yedekleme risk endeksi (0–100) — türetilmiş.

    Standart tek bir metriğin süreç hakkında sınırlı ya da çarpık bir görüntü
    verdiğini, kümenin bir pano olarak kurulması gerektiğini belirtir. Bu
    endeks üç açığın ortalamasıdır: hazır adayı olmayan pozisyon payı,
    %100'e göre kapsama açığı ve hazırlık açığı. Standardın parçası değildir.
    """
    kapsama_acik = max(0.0, 100 - min(kapsama_oran, 100))
    hazirlik_acik = max(0.0, 100 - min(hazirlik_oran, 100))
    return (hazir_adayi_yok_oran + kapsama_acik + hazirlik_acik) / 3


def gelisim_yatirimi(butce: float, havuz: float) -> float:
    """Havuzdaki kişi başına gelişim yatırımı — türetilmiş.

    Standart, gelişim faaliyetleri için kaynak (bütçe dâhil) ayrılmasını
    ister: çalışma zamanı, eğitim izni, koçluk, gölge çalışma ve rutin işin
    üstüne gelen gelişim görevleri. Tutar formülü standartta yoktur.
    """
    return butce / havuz


# ---------------------------------------------------------------------------
# 4) Pozisyon grubu tablosu
# ---------------------------------------------------------------------------

@dataclass
class PozisyonGrubu:
    """Bir pozisyon grubunun (unvan düzeyi, işlev, birim) yedekleme verisi."""
    ad: str
    kritik: float
    havuz: float
    hazir_simdi: float
    hazir_1_3: float = 0
    hazir_4_5: float = 0
    hazir_yok: float = 0

    @property
    def kapsama(self) -> float:
        return kapsama_orani(self.havuz, self.kritik)

    @property
    def hazir_oran(self) -> float:
        return hazirlik_orani(self.hazir_simdi, self.kritik)

    @property
    def yok_oran(self) -> float:
        return hazir_adayi_yok_orani(self.hazir_yok, self.kritik)


@dataclass
class YedeklemeTablosu:
    """Pozisyon gruplarından oluşan küme özeti."""
    gruplar: list = field(default_factory=list)

    def ekle(self, ad: str, kritik: float, havuz: float, hazir_simdi: float,
             hazir_1_3: float = 0, hazir_4_5: float = 0,
             hazir_yok: float = 0) -> "YedeklemeTablosu":
        self.gruplar.append(PozisyonGrubu(ad, kritik, havuz, hazir_simdi,
                                          hazir_1_3, hazir_4_5, hazir_yok))
        return self

    def _topla(self, alan: str) -> float:
        return sum(getattr(g, alan) for g in self.gruplar)

    def ozet(self) -> dict:
        kritik = self._topla("kritik")
        havuz = self._topla("havuz")
        r0 = self._topla("hazir_simdi")
        r13 = self._topla("hazir_1_3")
        r45 = self._topla("hazir_4_5")
        yok = self._topla("hazir_yok")
        return {
            "grup_sayisi": len(self.gruplar),
            "kritik_pozisyon": kritik,
            "havuz": havuz,
            "kapsama_yuzde": round(kapsama_orani(havuz, kritik), 1),
            "hazir_simdi_yuzde": round(hazirlik_orani(r0, kritik), 1),
            "hazir_1_3_yuzde": round(hazirlik_orani(r13, kritik), 1),
            "hazir_4_5_yuzde": round(hazirlik_orani(r45, kritik), 1),
            "pozisyon_basina_hazir": round(derinlik(r0, kritik), 2),
            "hazir_adayi_yok_yuzde": round(hazir_adayi_yok_orani(yok, kritik), 1),
            "risk_endeksi": round(
                risk_endeksi(hazir_adayi_yok_orani(yok, kritik),
                             kapsama_orani(havuz, kritik),
                             hazirlik_orani(r0, kritik)), 1),
        }

    def tablo(self) -> list:
        return [[g.ad, g.kritik, g.havuz, g.hazir_simdi, g.hazir_1_3, g.hazir_4_5,
                 g.hazir_yok, round(g.kapsama, 1), round(g.hazir_oran, 1)]
                for g in self.gruplar]


def ornek_tablo() -> YedeklemeTablosu:
    """Dört pozisyon gruplu örnek küme.

    Toplamlar, standardın hazırlık oranı örneğiyle aynı büyüklüktedir:
    102 kritik pozisyon; 82 şimdi hazır (%80), 76 aday 1–3 yılda (%75),
    24 aday 4–5 yılda (%23) hazır.
    """
    t = YedeklemeTablosu()
    t.ekle("Üst yönetim", 12, 14, 9, 8, 3, 4)
    t.ekle("Direktör ve kıdemli müdür", 32, 40, 26, 24, 8, 12)
    t.ekle("Müdür ve takım lideri", 38, 52, 31, 28, 9, 10)
    t.ekle("Kritik uzman ve teknik roller", 20, 24, 16, 16, 4, 8)
    return t


def metrik_denetimi(kritik_pozisyon_tanimli: bool = False,
                    lider_tanimi_yazili: bool = False,
                    havuz_olcutu_yazili: bool = False,
                    uc_ufuk_olculuyor: bool = False,
                    coklu_degerlendirme: bool = False,
                    gelisim_kaynagi_ayrildi: bool = False,
                    pano_olarak_raporlaniyor: bool = False) -> list:
    """Bir yedekleme raporunun eksiklerini listeler.

    Standardın mantığı: kümedeki metriklerin tamamı, kritik pozisyonların ve
    yedek adaylarının doğru belirlenmesine dayanır; tek metrik süreç hakkında
    sınırlı ya da çarpık bir görüntü verir.
    """
    uyarilar = []
    if not kritik_pozisyon_tanimli:
        uyarilar.append("Kritik pozisyon listesi tanımlı değil: kurumsal "
                        "sonuçlar üzerinde doğrudan ve belirgin etkisi olan "
                        "roller yazılı olarak belirlenmeli.")
    if not lider_tanimi_yazili:
        uyarilar.append("Kapsama oranının paydası belirsiz: hangi unvanların "
                        "'lider' sayıldığı raporda belirtilmeli.")
    if not havuz_olcutu_yazili:
        uyarilar.append("Havuza girme ölçütü yazılı değil: adayların yanlış "
                        "belirlenmesi kümenin tamamını geçersiz kılar.")
    if not uc_ufuk_olculuyor:
        uyarilar.append("Hazırlık yalnızca tek ufukta ölçülüyor: şimdi, 1–3 yıl "
                        "ve 4–5 yıl düzeylerinin üçü birden izlenmeli.")
    if not coklu_degerlendirme:
        uyarilar.append("Hazırlık tek kaynaktan belirleniyor: çoklu "
                        "değerlendirme aracı önyargıyı azaltır.")
    if not gelisim_kaynagi_ayrildi:
        uyarilar.append("Gelişim için ayrılmış kaynak (zaman, eğitim izni, "
                        "koçluk, bütçe) yok: havuz belirlemek tek başına "
                        "hazırlık üretmez.")
    if not pano_olarak_raporlaniyor:
        uyarilar.append("Metrikler tek tek raporlanıyor: küme pano olarak "
                        "okunmazsa görüntü sınırlı ya da çarpık olur.")
    return uyarilar


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "etkililik", "kapsama", "hazirlik", "derinlik", "yetkinlik_eslesme",
    "yedek_gucu", "havuz_buyume", "havuz_devir", "hazir_adayi_yok",
    "dis_alim", "gelisim_yatirimi", "risk_endeksi",
]


def _s(x: float) -> str:
    """Sayıları bilimsel gösterime kaçmadan, Türkçe biçimde yazar."""
    x = float(x)
    if x == int(x):
        return f"{int(x):,}".replace(",", ".")
    t = f"{x:,.2f}".rstrip("0")
    if t.endswith("."):
        t = t[:-1]
    return t.replace(",", "\u00a0").replace(".", ",").replace("\u00a0", ".")


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "etkililik":
        d = etkililik_orani(g["ic_yedekleme"], g["toplam_yedekleme"])
        return {"deger": d, "ondalik": 1, "birim": "% içeriden",
                "ifade": f"({_s(g['ic_yedekleme'])} ÷ {_s(g['toplam_yedekleme'])}) × 100",
                "ayrinti": [["Dışarıdan doldurulan kritik pozisyon",
                             g["toplam_yedekleme"] - g["ic_yedekleme"]],
                            ["Dış alım payı (%)", round(100 - d, 1)],
                            ["Önceki döneme fark (puan)", round(d - g["onceki_oran"], 1)],
                            ["Standardın andığı iyi aralık", "%70 – %80"]]}

    if metrik == "kapsama":
        d = kapsama_orani(g["havuz"], g["lider"])
        return {"deger": d, "ondalik": 1, "birim": "% kapsama",
                "ifade": f"({_s(g['havuz'])} ÷ {_s(g['lider'])}) × 100",
                "ayrinti": [["Lider başına aday", round(g["havuz"] / g["lider"], 2)],
                            ["%100 kapsama için gereken ek aday",
                             max(g["lider"] - g["havuz"], 0)],
                            ["Hedef derinliğe göre eksik aday",
                             max(g["hedef_derinlik"] * g["lider"] - g["havuz"], 0)]]}

    if metrik == "hazirlik":
        d = hazirlik_orani(g["hazir_simdi"], g["kritik_pozisyon"])
        return {"deger": d, "ondalik": 1, "birim": "% şimdi hazır",
                "ifade": f"({_s(g['hazir_simdi'])} ÷ {_s(g['kritik_pozisyon'])}) × 100",
                "ayrinti": [["1–3 yılda hazır (%)",
                             round(hazirlik_orani(g["hazir_1_3"], g["kritik_pozisyon"]), 1)],
                            ["4–5 yılda hazır (%)",
                             round(hazirlik_orani(g["hazir_4_5"], g["kritik_pozisyon"]), 1)],
                            ["Pozisyon başına şimdi hazır aday",
                             round(derinlik(g["hazir_simdi"], g["kritik_pozisyon"]), 2)],
                            ["Belirlenmiş toplam hazır aday",
                             g["hazir_simdi"] + g["hazir_1_3"] + g["hazir_4_5"]]]}

    if metrik == "derinlik":
        d = derinlik(g["hazir_aday"], g["kritik_pozisyon"])
        return {"deger": d, "ondalik": 2, "birim": "hazır aday / pozisyon",
                "ifade": f"{_s(g['hazir_aday'])} ÷ {_s(g['kritik_pozisyon'])}",
                "ayrinti": [["Hazırlık oranı (%)",
                             round(hazirlik_orani(g["hazir_aday"], g["kritik_pozisyon"]), 1)],
                            ["Hedef derinlik", g["hedef_derinlik"]],
                            ["Hedefe göre eksik hazır aday",
                             max(round(g["hedef_derinlik"] * g["kritik_pozisyon"]
                                       - g["hazir_aday"]), 0)]]}

    if metrik == "yetkinlik_eslesme":
        d = eslesme_yuzdesi(g["mevcut_puan"], g["gelecek_gereklilik"])
        return {"deger": d, "ondalik": 1, "birim": "% eşleşme",
                "ifade": f"({_s(g['mevcut_puan'])} ÷ {_s(g['gelecek_gereklilik'])}) × 100",
                "ayrinti": [["Puan açığı",
                             round(g["gelecek_gereklilik"] - g["mevcut_puan"], 2)],
                            ["Açığın ölçeğe oranı (%)",
                             round(100 * (g["gelecek_gereklilik"] - g["mevcut_puan"])
                                   / g["olcek"], 1)],
                            ["Ölçek üst sınırına uzaklık",
                             round(g["olcek"] - g["mevcut_puan"], 2)]]}

    if metrik == "yedek_gucu":
        d = yedek_gucu_orani(g["esigi_karsilayan"], g["havuz"])
        return {"deger": d, "ondalik": 1, "birim": "% havuzun eşiği karşılayan payı",
                "ifade": f"({_s(g['esigi_karsilayan'])} ÷ {_s(g['havuz'])}) × 100",
                "ayrinti": [["Yedek gücü (kişi)", g["esigi_karsilayan"]],
                            ["Eşiği karşılamayan (kişi)",
                             g["havuz"] - g["esigi_karsilayan"]],
                            ["Tüm alanlarda ortalama başarı (%)", g["ortalama_basari"]]]}

    if metrik == "havuz_buyume":
        d = havuz_buyume(g["cari"], g["onceki"])
        return {"deger": d, "ondalik": 1, "birim": "% büyüme",
                "ifade": f"(({_s(g['cari'])} − {_s(g['onceki'])}) ÷ {_s(g['onceki'])}) × 100",
                "ayrinti": [["Net değişim (kişi)", g["cari"] - g["onceki"]],
                            ["Havuza katılan (kişi)",
                             g["cari"] - g["onceki"] + g["ayrilan"]],
                            ["Havuzdan ayrılan (kişi)", g["ayrilan"]],
                            ["Havuzdan devir oranı (%)",
                             round(havuz_devir(g["ayrilan"], g["onceki"]), 1)]]}

    if metrik == "havuz_devir":
        d = havuz_devir(g["ayrilan"], g["havuz"])
        return {"deger": d, "ondalik": 1, "birim": "% havuzdan devir",
                "ifade": f"({_s(g['ayrilan'])} ÷ {_s(g['havuz'])}) × 100",
                "ayrinti": [["Havuzda kalan (kişi)", g["havuz"] - g["ayrilan"]],
                            ["Ayrılanların hazır aday olanı (kişi)", g["hazir_kayip"]],
                            ["Hazır aday kaybının payı (%)",
                             round(100 * g["hazir_kayip"] / g["ayrilan"], 1)]]}

    if metrik == "hazir_adayi_yok":
        d = hazir_adayi_yok_orani(g["pozisyon_sayisi"], g["toplam_pozisyon"])
        return {"deger": d, "ondalik": 1, "birim": "% hazır adayı yok",
                "ifade": f"({_s(g['pozisyon_sayisi'])} ÷ {_s(g['toplam_pozisyon'])}) × 100",
                "ayrinti": [["Hazır adayı olan pozisyon",
                             g["toplam_pozisyon"] - g["pozisyon_sayisi"]],
                            ["Önceki döneme fark (puan)", round(d - g["onceki_oran"], 1)],
                            ["Hedef", "sıfıra yakın"]]}

    if metrik == "dis_alim":
        d = dis_alim_payi(g["dis_alim"], g["toplam_yedekleme"])
        return {"deger": d, "ondalik": 1, "birim": "% dışarıdan",
                "ifade": f"({_s(g['dis_alim'])} ÷ {_s(g['toplam_yedekleme'])}) × 100",
                "ayrinti": [["İçeriden doldurulan", g["toplam_yedekleme"] - g["dis_alim"]],
                            ["Dış alımların tahmini maliyeti (TL)",
                             round(g["dis_alim"] * g["ortalama_maliyet"])],
                            ["Bir dış alım azalırsa kazanç (TL)",
                             round(g["ortalama_maliyet"])],
                            ["Yedekleme etkililiği (%)", round(100 - d, 1)]]}

    if metrik == "gelisim_yatirimi":
        d = gelisim_yatirimi(g["butce"], g["havuz"])
        return {"deger": d, "ondalik": 0, "birim": "TL / havuz üyesi",
                "ifade": f"{_s(g['butce'])} ÷ {_s(g['havuz'])}",
                "ayrinti": [["Kritik pozisyon başına (TL)",
                             round(g["butce"] / g["kritik_pozisyon"])],
                            ["Toplam gelişim bütçesi (TL)", round(g["butce"])],
                            ["Havuz büyüklüğü (kişi)", g["havuz"]]]}

    if metrik == "risk_endeksi":
        d = risk_endeksi(g["hazir_adayi_yok_oran"], g["kapsama_oran"],
                         g["hazirlik_oran"])
        _ka = round(max(0.0, 100 - min(g["kapsama_oran"], 100)), 1)
        _ha = round(max(0.0, 100 - min(g["hazirlik_oran"], 100)), 1)
        return {"deger": d, "ondalik": 1, "birim": "risk (0–100)",
                "ifade": (f"({_s(g['hazir_adayi_yok_oran'])} + {_s(_ka)} + "
                          f"{_s(_ha)}) ÷ 3"),
                "ayrinti": [["Kapsama açığı (puan)", _ka],
                            ["Hazırlık açığı (puan)", _ha],
                            ["Hazır adayı olmayan pozisyon payı (%)",
                             g["hazir_adayi_yok_oran"]],
                            ["Not", "standartta yoktur, türetilmiştir"]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 76
    print("ISO/TS 30433 — doğrulama çıktısı")
    print(cizgi)

    print("Yedekleme etkililiği (üç dönemlik karşılaştırma)")
    print(f"{'Dönem':<8}{'İç yedekleme':>14}{'Kritik pozisyon':>18}{'Etkililik %':>14}")
    for ad, ic, top in [("2024", 23, 31), ("2025", 21, 31), ("2026", 25, 40)]:
        print(f"{ad:<8}{ic:>14}{top:>18}{etkililik_orani(ic, top):>14.0f}")
    print(cizgi)

    t = ornek_tablo()
    print("Pozisyon grupları")
    print(f"{'Grup':<32}{'KP':>5}{'Havuz':>7}{'Şimdi':>7}{'1-3':>6}{'4-5':>6}"
          f"{'Yok':>6}{'Kapsama':>9}{'Hazır':>8}")
    for s in t.tablo():
        print(f"{s[0]:<32}{s[1]:>5.0f}{s[2]:>7.0f}{s[3]:>7.0f}{s[4]:>6.0f}"
              f"{s[5]:>6.0f}{s[6]:>6.0f}{s[7]:>9.1f}{s[8]:>8.1f}")
    print(cizgi)
    for k, v in t.ozet().items():
        print(f"{k:<26}: {v}")
    print(cizgi)

    print("Genişlik ve derinlik")
    print(f"Kapsama (24 aday / 44 lider)  : {kapsama_orani(24, 44):.0f} %")
    print(f"Kapsama (132 aday / 44 lider) : {kapsama_orani(132, 44):.0f} %")
    print(f"Hazır şimdi (82 / 102)        : {hazirlik_orani(82, 102):.0f} %")
    print(f"1–3 yıl (76 / 102)            : {hazirlik_orani(76, 102):.0f} %")
    print(f"4–5 yıl (24 / 102)            : {hazirlik_orani(24, 102):.0f} %")
    print(f"Pozisyon başına hazır aday    : {derinlik(82, 102):.2f}")
    print(cizgi)

    print("Yetkinlik eşleşmesi (beceri matrisi)")
    for alan, mevcut, gelecek in [("Vizyon oluşturma", 3.6, 5),
                                  ("Sunum yapma", 2.7, 3),
                                  ("İlişki kurma", 4.2, 5),
                                  ("Proje yönetimi", 3.8, 4.5),
                                  ("Sektör bilgisi", 2.5, 4)]:
        print(f"{alan:<20}{mevcut:>6}{gelecek:>6}{eslesme_yuzdesi(mevcut, gelecek):>8.0f} %")
    print(cizgi)

    print("Değişim ve açık")
    print(f"Yedek gücü oranı (112 / 135)  : {yedek_gucu_orani(112, 135):.1f} %")
    print(f"Havuz büyüme (234 / 201)      : {havuz_buyume(234, 201):.0f} %")
    print(f"Havuzdan devir (18 / 201)     : {havuz_devir(18, 201):.1f} %")
    print(f"Hazır adayı yok (16 / 44)     : {hazir_adayi_yok_orani(16, 44):.0f} %")
    print(f"Risk endeksi                  : {risk_endeksi(36, 54, 80):.1f}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("etkililik", ic_yedekleme=25, toplam_yedekleme=40, onceki_oran=68))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
