#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30414_metrikler.py
=====================
ISO 30414:2025 (Human resource management - Requirements and recommendations for
human capital reporting and disclosure) ikinci baskisindaki insan sermayesi
metriklerinin Python karsiligi. 11 insan sermayesi alani (HCA), Ek A'daki
formuller ve TCFD tabanli aciklama cercevesine dayanir.

Zorunlu metrikler (Tablo 3) ve onerilen metrikler (Tablo 4) ayni hesapla()
dagiticisi uzerinden cagrilir. Kullanim:

    from iso30414_metrikler import hcroi, devir, fte
    fte(30160000, 3260000, 2080)          ->  FTE
    devir(1360, 16400)                    ->  isgucu devir orani (%)
    hesapla("hcroi", rt=4500000, te=3750000, cow=1500000)

Dogrudan calistirildiginda (python3 iso30414_metrikler.py) ornek verilerle
tum ana metrikler hesaplanir. Formuller ISO 30414:2025 Ek A'ya dayanir; kod ve
aciklamalar ozgun yazilmistir, standardin kendisi telif korumalidir.
"""
from __future__ import annotations

__all__ = ["toplam_calisan", "fte", "tfte", "yas_cesitliligi", "cinsiyet_cesitliligi", "engellilik", "diger_cesitlilik", "isgucu_maliyeti", "ogrenme_maliyeti", "calisan_maliyeti", "ise_alim_maliyeti", "maliyet_per_hire", "ciro_fte", "ebit_fte", "maliyet_gider", "hcroi", "kaza", "olum", "kayip_zaman", "devamsizlik", "wellness", "baglilik_endeksi", "ortalama_kidem", "ilk_yil_yipranma", "enps", "kontrol_alani", "cinsiyet_ucret", "cesitlilik_ucret", "ceo_medyan", "zorunlu_egitim", "temsil", "toplu_sozlesme", "basvuru_donusum", "doldurma_suresi", "doldurma_kritik", "teklif_kabul", "kalite_per_hire", "ic_doldurma", "kritik_yuzde", "kritik_ic", "bos_kritik", "ic_hareketlilik", "yedek_kapsam", "yedek_simdi", "yedek_etkinlik", "devir", "gonullu_devir", "gonullu_kritik", "korunan_devir", "ort_egitim_saat", "egitim_katilim", "korunan_egitim", "geri_bildirim", "lider_egitim", "yetkinlik"] + ["hesapla", "METRIK_LISTESI", "ornek_baglilik_anketi", "_demo"]


def _s(x):
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if xf == int(xf):
        return f"{int(xf):,}".replace(",", ".")
    return f"{xf:,.2f}".replace(",", "\u00a7").replace(".", ",").replace("\u00a7", ".")


# ---------------------------------------------------------------------------
# Metrik fonksiyonlari (Ek A formulleri)
# ---------------------------------------------------------------------------
def toplam_calisan(ft=16400, pt=3140, tp=1120):
    """Toplam çalışan (headcount) (wc)."""
    return ft+pt+tp

def fte(hft=30160000, hpt=3260000, hst=2080):
    """Tam zaman eşdeğeri (FTE) (wc)."""
    return (hft+hpt)/(hst)

def tfte(emp=16400, con=1577):
    """Toplam FTE (TFTE) (wc)."""
    return emp+con

def yas_cesitliligi(grup=8536, toplam=16400):
    """Yaş çeşitliliği (grup yüzdesi) (div)."""
    return 100*(grup)/(toplam)

def cinsiyet_cesitliligi(gn=7327, nt=16400):
    """Cinsiyet çeşitliliği (div)."""
    return 100*(gn)/(nt)

def engellilik(dn=300, nt=16400):
    """Engellilik çeşitliliği (div)."""
    return 100*(dn)/(nt)

def diger_cesitlilik(nx=255, nt=16400):
    """Diğer çeşitlilik ölçüsü (boyut X) (div)."""
    return 100*(nx)/(nt)

def isgucu_maliyeti(cc=560000000, bc=150000000, xc=41000000, rc=8000000, lc=42000000, oc=9000000):
    """Toplam işgücü maliyeti (cost)."""
    return cc+bc+xc+rc+lc+oc

def ogrenme_maliyeti(kurs=80000, mat=30000, egt=70000, plat=20000, uye=10500, seyahat=20500):
    """Toplam öğrenme ve gelişim (L&D) maliyeti (cost)."""
    return kurs+mat+egt+plat+uye+seyahat

def calisan_maliyeti(maas=510000000, prim=75000000, yan=170000000, diger=1000000):
    """Toplam çalışan maliyeti (cost)."""
    return maas+prim+yan+diger

def ise_alim_maliyeti(dis=110000, ic=105000):
    """Toplam işe alım maliyeti (cost)."""
    return dis+ic

def maliyet_per_hire(rtc=215000, nnh=53):
    """İşe alım başına maliyet (CPH) (cost)."""
    return (rtc)/(nnh)

def ciro_fte(rt=1540000000, ntfte=16400):
    """FTE başına finansal ciro (prod)."""
    return (rt)/(ntfte)

def ebit_fte(rt=1540000000, te=1380625000, ntfte=16400):
    """FTE başına FVÖK (EBIT) (prod)."""
    return (rt-te)/ntfte

def maliyet_gider(cow=1500000, ox=3750000):
    """İşgücü maliyeti / işletme gideri (prod)."""
    return 100*(cow)/(ox)

def hcroi(rt=4500000, te=3750000, cow=1500000):
    """İnsan sermayesi ROI (HCROI) (prod)."""
    return ((rt-(te-cow))/cow-1)*100

def kaza(toa=27, ht=12000000, navg=16400, tri=18):
    """İş kazası oranı (milyon saat) (hsw)."""
    return 1000000*(toa)/(ht)

def olum(nf=3, ht=12000000):
    """İş kaynaklı ölüm oranı (milyon saat) (hsw)."""
    return 1000000*(nf)/(ht)

def kayip_zaman(ld=1578, ht=12000000):
    """Kayıp zaman sıklık oranı (LTIFR) (hsw)."""
    return 1000000*(ld)/(ht)

def devamsizlik(dua=12000, wd=250, nt=16400):
    """Plansız devamsızlık oranı (hsw)."""
    return 100*(dua)/(wd*nt)

def wellness(nwp=4100, nt=16400):
    """Wellness programı katılım yüzdesi (hsw)."""
    return 100*(nwp)/(nt)

def baglilik_endeksi(toplam_puan=62, madde_sayisi=7, olcek_max=10, onceki_endeks=79):
    """Bağlılık endeksi (anket puanı) (lce)."""
    return 100*toplam_puan/(madde_sayisi*olcek_max)

def ortalama_kidem(yts=114800, nt=16400):
    """Ortalama kıdem (lce)."""
    return (yts)/(nt)

def ilk_yil_yipranma(ey1=120, ny1=800):
    """İlk yıl yıpranma oranı (lce)."""
    return 100*(ey1)/(ny1)

def enps(destekci=520, karsit=180, yanit=1000):
    """eNPS (çalışan net tavsiye skoru) (lce)."""
    return (destekci-karsit)/yanit*100

def kontrol_alani(ndr=13120, nsdr=1085):
    """Kontrol alanı (span of control) (lce)."""
    return (ndr)/(nsdr)

def cinsiyet_ucret(tcf=48000, tcm=52000):
    """Cinsiyet ücret oranı (cew)."""
    return (tcf)/(tcm)

def cesitlilik_ucret(atca=50500, atcw=52000):
    """Çeşitlilik ücret oranı (grup A) (cew)."""
    return (atca)/(atcw)

def ceo_medyan(aceo=5000000, actw=50000):
    """CEO / medyan çalışan ücret oranı (cew)."""
    return (aceo)/(actw)

def zorunlu_egitim(ewc=15600, ew=16400):
    """Zorunlu eğitim tamamlama oranı (cew)."""
    return 100*(ewc)/(ew)

def temsil(nre=9800, nte=16400):
    """Çalışan temsil oranı (cew)."""
    return 100*(nre)/(nte)

def toplu_sozlesme(ncb=7200, nte=16400):
    """Toplu sözleşme kapsama oranı (cew)."""
    return 100*(ncb)/(nte)

def basvuru_donusum(qc=120, qa=480):
    """Başvuru → aday dönüşüm oranı (rec)."""
    return 100*(qc)/(qa)

def doldurma_suresi(tdao=5040, npf=70):
    """Doldurma süresi (gün) (rec)."""
    return (tdao)/(npf)

def doldurma_kritik(cdao=600, ncpf=10):
    """Kritik pozisyon doldurma süresi (gün) (rec)."""
    return (cdao)/(ncpf)

def teklif_kabul(oa=95, om=100):
    """Teklif → kabul oranı (rec)."""
    return 100*(oa)/(om)

def kalite_per_hire(pa=4.2, pe=4.0):
    """İşe alım başına kalite (rec)."""
    return 100*(pa)/(pe)

def ic_doldurma(npfi=180, tnpf=600):
    """İçeriden doldurulan pozisyon yüzdesi (mob)."""
    return 100*(npfi)/(tnpf)

def kritik_yuzde(ncp=1650, tnpo=16400):
    """Kritik pozisyonların yüzdesi (mob)."""
    return 100*(ncp)/(tnpo)

def kritik_ic(ncfi=120, tncf=200):
    """Kritik pozisyonların içeriden doldurulma yüzdesi (mob)."""
    return 100*(ncfi)/(tncf)

def bos_kritik(nvcp=30, tnvp=200):
    """Boş kritik pozisyon oranı (mob)."""
    return 100*(nvcp)/(tnvp)

def ic_hareketlilik(nim=1500, nte=16400):
    """İç hareketlilik oranı (mob)."""
    return 100*(nim)/(nte)

def yedek_kapsam(nlsp=90, nl=60):
    """Yedek kapsam oranı (liderlik) (mob)."""
    return 100*(nlsp)/(nl)

def yedek_simdi(ncpn=210, ncp=1650):
    """Yedek derinliği: şimdi hazır (0–12 ay) (mob)."""
    return 100*(ncpn)/(ncp)

def yedek_etkinlik(nihc=156, ncpo=200):
    """Yedekleme etkinlik oranı (mob)."""
    return 100*(nihc)/(ncpo)

def devir(lt=1360, navg=16400):
    """İşgücü devir oranı (turn)."""
    return 100*(lt)/(navg)

def gonullu_devir(lvl=1000, navg=16400):
    """Gönüllü devir oranı (turn)."""
    return 100*(lvl)/(navg)

def gonullu_kritik(lvct=90, ncav=1650):
    """Gönüllü kritik devir oranı (turn)."""
    return 100*(lvct)/(ncav)

def korunan_devir(ltpg=70, napg=1200):
    """Korunan grup gönüllü devir oranı (turn)."""
    return 100*(ltpg)/(napg)

def ort_egitim_saat(tht=1443200, nwt=16400):
    """İşgücü başına ortalama eğitim saati (skill)."""
    return (tht)/(nwt)

def egitim_katilim(npt=14760, nt=16400):
    """Eğitime katılan işgücü yüzdesi (skill)."""
    return 100*(npt)/(nt)

def korunan_egitim(npup=1800, npt=14760):
    """Korunan grup eğitim katılım yüzdesi (skill)."""
    return 100*(npup)/(npt)

def geri_bildirim(nrf=14400, nt=16400):
    """Güncel performans geri bildirimi yüzdesi (skill)."""
    return 100*(nrf)/(nt)

def lider_egitim(nlt=48, nl=60):
    """Biçimsel eğitime katılan lider yüzdesi (skill)."""
    return 100*(nlt)/(nl)

def yetkinlik(rcr=57400, nt=16400):
    """İşgücü yetkinlik oranı (skill)."""
    return (rcr)/(nt)


METRIK_LISTESI = ["toplam_calisan", "fte", "tfte", "yas_cesitliligi", "cinsiyet_cesitliligi", "engellilik", "diger_cesitlilik", "isgucu_maliyeti", "ogrenme_maliyeti", "calisan_maliyeti", "ise_alim_maliyeti", "maliyet_per_hire", "ciro_fte", "ebit_fte", "maliyet_gider", "hcroi", "kaza", "olum", "kayip_zaman", "devamsizlik", "wellness", "baglilik_endeksi", "ortalama_kidem", "ilk_yil_yipranma", "enps", "kontrol_alani", "cinsiyet_ucret", "cesitlilik_ucret", "ceo_medyan", "zorunlu_egitim", "temsil", "toplu_sozlesme", "basvuru_donusum", "doldurma_suresi", "doldurma_kritik", "teklif_kabul", "kalite_per_hire", "ic_doldurma", "kritik_yuzde", "kritik_ic", "bos_kritik", "ic_hareketlilik", "yedek_kapsam", "yedek_simdi", "yedek_etkinlik", "devir", "gonullu_devir", "gonullu_kritik", "korunan_devir", "ort_egitim_saat", "egitim_katilim", "korunan_egitim", "geri_bildirim", "lider_egitim", "yetkinlik"]


def ornek_baglilik_anketi(olcek_max: int = 10):
    """Tablo A.21 tipi 7 boyutlu ornek bagliklik anketi -> (toplam, madde, endeks)."""
    yanitlar = [8, 7, 8, 6, 7, 8, 7]          # 1-10 olceginde ornek profil
    toplam = sum(yanitlar)
    madde = len(yanitlar)
    endeks = baglilik_endeksi(toplam, madde, olcek_max)
    return {"toplam": toplam, "madde": madde, "endeks": round(endeks, 1)}


# ---------------------------------------------------------------------------
# Dagitici: hesaplayicinin kullandigi arayuz
# ---------------------------------------------------------------------------
def hesapla(metrik: str, **g) -> dict:
    """Metrik kimligi ve girdilerle hesabi yapar; sozluk dondurur.

    Donen anahtarlar: deger, ondalik, birim, ifade, ayrinti.
    """
    if metrik == 'toplam_calisan':
        d = toplam_calisan(g['ft'], g['pt'], g['tp'])
        ifade = " + ".join(_s(g[k]) for k in ['ft', 'pt', 'tp'])
        return {"deger": d, "ondalik": 0, "birim": 'çalışan',
                "ifade": ifade, "ayrinti": [["Tam zamanlı", g['ft']], ["Yarı zamanlı", g['pt']], ["Geçici/mevsimlik", g['tp']], ["Toplam", d]]}
    if metrik == 'fte':
        d = fte(g['hft'], g['hpt'], g['hst'])
        num = g['hft']+g['hpt']
        den = g['hst']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 0, "birim": 'FTE',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'tfte':
        d = tfte(g['emp'], g['con'])
        ifade = " + ".join(_s(g[k]) for k in ['emp', 'con'])
        return {"deger": d, "ondalik": 1, "birim": 'FTE',
                "ifade": ifade, "ayrinti": [["Çalışan FTE", g['emp']], ["Contingent FTE", g['con']], ["Toplam", d]]}
    if metrik == 'yas_cesitliligi':
        d = yas_cesitliligi(g['grup'], g['toplam'])
        num = g['grup']
        den = g['toplam']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'cinsiyet_cesitliligi':
        d = cinsiyet_cesitliligi(g['gn'], g['nt'])
        num = g['gn']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'engellilik':
        d = engellilik(g['dn'], g['nt'])
        num = g['dn']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'diger_cesitlilik':
        d = diger_cesitlilik(g['nx'], g['nt'])
        num = g['nx']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'isgucu_maliyeti':
        d = isgucu_maliyeti(g['cc'], g['bc'], g['xc'], g['rc'], g['lc'], g['oc'])
        ifade = " + ".join(_s(g[k]) for k in ['cc', 'bc', 'xc', 'rc', 'lc', 'oc'])
        return {"deger": d, "ondalik": 0, "birim": 'para birimi',
                "ifade": ifade, "ayrinti": [["Tazminat", g['cc']], ["Yan haklar", g['bc']], ["Dış işgücü", g['xc']], ["İşe alım", g['rc']], ["Öğrenme-gelişim", g['lc']], ["Diğer", g['oc']], ["Toplam", d]]}
    if metrik == 'ogrenme_maliyeti':
        d = ogrenme_maliyeti(g['kurs'], g['mat'], g['egt'], g['plat'], g['uye'], g['seyahat'])
        ifade = " + ".join(_s(g[k]) for k in ['kurs', 'mat', 'egt', 'plat', 'uye', 'seyahat'])
        return {"deger": d, "ondalik": 0, "birim": 'para birimi',
                "ifade": ifade, "ayrinti": [["Kurs ücretleri", g['kurs']], ["Materyal/lisans", g['mat']], ["Eğitmen ücretleri", g['egt']], ["Platform erişimi", g['plat']], ["Üyelik/abonelik", g['uye']], ["Seyahat", g['seyahat']], ["Toplam", d]]}
    if metrik == 'calisan_maliyeti':
        d = calisan_maliyeti(g['maas'], g['prim'], g['yan'], g['diger'])
        ifade = " + ".join(_s(g[k]) for k in ['maas', 'prim', 'yan', 'diger'])
        return {"deger": d, "ondalik": 0, "birim": 'para birimi',
                "ifade": ifade, "ayrinti": [["Maaş", g['maas']], ["Prim/ikramiye", g['prim']], ["Yan haklar", g['yan']], ["Diğer tazminat", g['diger']], ["Toplam", d]]}
    if metrik == 'ise_alim_maliyeti':
        d = ise_alim_maliyeti(g['dis'], g['ic'])
        ifade = " + ".join(_s(g[k]) for k in ['dis', 'ic'])
        return {"deger": d, "ondalik": 0, "birim": 'para birimi',
                "ifade": ifade, "ayrinti": [["Dış maliyetler", g['dis']], ["İç maliyetler", g['ic']], ["Toplam", d]]}
    if metrik == 'maliyet_per_hire':
        d = maliyet_per_hire(g['rtc'], g['nnh'])
        num = g['rtc']
        den = g['nnh']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 0, "birim": 'para birimi / işe alım',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ciro_fte':
        d = ciro_fte(g['rt'], g['ntfte'])
        num = g['rt']
        den = g['ntfte']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 0, "birim": 'para birimi / FTE',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ebit_fte':
        d = ebit_fte(g['rt'], g['te'], g['ntfte'])
        ifade = f"(({_s(g['rt'])} \u2212 {_s(g['te'])}) \u00f7 {_s(g['ntfte'])})"
        return {"deger": d, "ondalik": 0, "birim": 'para birimi / FTE',
                "ifade": ifade, "ayrinti": [["Pay (fark)", g['rt']-g['te']], ["Payda", g['ntfte']]]}
    if metrik == 'maliyet_gider':
        d = maliyet_gider(g['cow'], g['ox'])
        num = g['cow']
        den = g['ox']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'hcroi':
        d = hcroi(g['rt'], g['te'], g['cow'])
        kar = g['rt']-(g['te']-g['cow'])
        ifade = f"[({_s(g['rt'])} \u2212 ({_s(g['te'])} \u2212 {_s(g['cow'])})) \u00f7 {_s(g['cow'])}] \u2212 1, \u00d7100"
        return {"deger": d, "ondalik": 1, "birim": '% HCROI',
                "ifade": ifade, "ayrinti": [["Vergi oncesi kar", kar], ["Isgucu maliyeti", g['cow']], ["Getiri (oran)", round(d/100, 2)]]}
    if metrik == 'kaza':
        d = kaza(g['toa'], g['ht'], g['navg'], g['tri'])
        num = g['toa']
        den = g['ht']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 1.000.000"
        return {"deger": d, "ondalik": 2, "birim": '/ milyon saat',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den], ['Çalışan başına kaza (×100)', round((100*g['toa']/g['navg']), 2)], ['TRIR (200.000 faktörü, /100 FTE)', round((200000*g['tri']/g['ht']), 2)], ['Milyon saat başına oran', round((1000000*g['toa']/g['ht']), 2)]]}
    if metrik == 'olum':
        d = olum(g['nf'], g['ht'])
        num = g['nf']
        den = g['ht']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 1.000.000"
        return {"deger": d, "ondalik": 3, "birim": '/ milyon saat',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'kayip_zaman':
        d = kayip_zaman(g['ld'], g['ht'])
        num = g['ld']
        den = g['ht']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 1.000.000"
        return {"deger": d, "ondalik": 1, "birim": '/ milyon saat',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'devamsizlik':
        d = devamsizlik(g['dua'], g['wd'], g['nt'])
        num = g['dua']
        den = g['wd']*g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 2, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'wellness':
        d = wellness(g['nwp'], g['nt'])
        num = g['nwp']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'baglilik_endeksi':
        d = baglilik_endeksi(g['toplam_puan'], g['madde_sayisi'], g['olcek_max'], g['onceki_endeks'])
        azami = g['madde_sayisi']*g['olcek_max']
        ifade = f"({_s(g['toplam_puan'])} \u00f7 {_s(azami)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '/100 bağlılık endeksi',
                "ifade": ifade, "ayrinti": [["Azami puan (madde x olcek)", azami], ["Madde basina ortalama", round(g['toplam_puan']/g['madde_sayisi'],2)], ["Onceki doneme fark (puan)", round(d-g['onceki_endeks'],1)]]}
    if metrik == 'ortalama_kidem':
        d = ortalama_kidem(g['yts'], g['nt'])
        num = g['yts']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 1, "birim": 'yıl',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ilk_yil_yipranma':
        d = ilk_yil_yipranma(g['ey1'], g['ny1'])
        num = g['ey1']
        den = g['ny1']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'enps':
        d = enps(g['destekci'], g['karsit'], g['yanit'])
        ifade = f"(({_s(g['destekci'])} \u2212 {_s(g['karsit'])}) \u00f7 {_s(g['yanit'])}) \u00d7 100"
        return {"deger": d, "ondalik": 0, "birim": 'eNPS (−100…100)',
                "ifade": ifade, "ayrinti": [["Pay (fark)", g['destekci']-g['karsit']], ["Payda", g['yanit']]]}
    if metrik == 'kontrol_alani':
        d = kontrol_alani(g['ndr'], g['nsdr'])
        num = g['ndr']
        den = g['nsdr']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 1, "birim": 'doğrudan bağlı / yönetici',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'cinsiyet_ucret':
        d = cinsiyet_ucret(g['tcf'], g['tcm'])
        num = g['tcf']
        den = g['tcm']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 3, "birim": 'oran',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'cesitlilik_ucret':
        d = cesitlilik_ucret(g['atca'], g['atcw'])
        num = g['atca']
        den = g['atcw']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 3, "birim": 'oran',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ceo_medyan':
        d = ceo_medyan(g['aceo'], g['actw'])
        num = g['aceo']
        den = g['actw']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 1, "birim": '× medyan',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'zorunlu_egitim':
        d = zorunlu_egitim(g['ewc'], g['ew'])
        num = g['ewc']
        den = g['ew']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'temsil':
        d = temsil(g['nre'], g['nte'])
        num = g['nre']
        den = g['nte']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'toplu_sozlesme':
        d = toplu_sozlesme(g['ncb'], g['nte'])
        num = g['ncb']
        den = g['nte']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'basvuru_donusum':
        d = basvuru_donusum(g['qc'], g['qa'])
        num = g['qc']
        den = g['qa']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'doldurma_suresi':
        d = doldurma_suresi(g['tdao'], g['npf'])
        num = g['tdao']
        den = g['npf']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 0, "birim": 'gün',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'doldurma_kritik':
        d = doldurma_kritik(g['cdao'], g['ncpf'])
        num = g['cdao']
        den = g['ncpf']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 0, "birim": 'gün',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'teklif_kabul':
        d = teklif_kabul(g['oa'], g['om'])
        num = g['oa']
        den = g['om']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'kalite_per_hire':
        d = kalite_per_hire(g['pa'], g['pe'])
        num = g['pa']
        den = g['pe']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ic_doldurma':
        d = ic_doldurma(g['npfi'], g['tnpf'])
        num = g['npfi']
        den = g['tnpf']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'kritik_yuzde':
        d = kritik_yuzde(g['ncp'], g['tnpo'])
        num = g['ncp']
        den = g['tnpo']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'kritik_ic':
        d = kritik_ic(g['ncfi'], g['tncf'])
        num = g['ncfi']
        den = g['tncf']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'bos_kritik':
        d = bos_kritik(g['nvcp'], g['tnvp'])
        num = g['nvcp']
        den = g['tnvp']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ic_hareketlilik':
        d = ic_hareketlilik(g['nim'], g['nte'])
        num = g['nim']
        den = g['nte']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'yedek_kapsam':
        d = yedek_kapsam(g['nlsp'], g['nl'])
        num = g['nlsp']
        den = g['nl']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'yedek_simdi':
        d = yedek_simdi(g['ncpn'], g['ncp'])
        num = g['ncpn']
        den = g['ncp']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'yedek_etkinlik':
        d = yedek_etkinlik(g['nihc'], g['ncpo'])
        num = g['nihc']
        den = g['ncpo']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'devir':
        d = devir(g['lt'], g['navg'])
        num = g['lt']
        den = g['navg']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'gonullu_devir':
        d = gonullu_devir(g['lvl'], g['navg'])
        num = g['lvl']
        den = g['navg']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'gonullu_kritik':
        d = gonullu_kritik(g['lvct'], g['ncav'])
        num = g['lvct']
        den = g['ncav']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'korunan_devir':
        d = korunan_devir(g['ltpg'], g['napg'])
        num = g['ltpg']
        den = g['napg']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'ort_egitim_saat':
        d = ort_egitim_saat(g['tht'], g['nwt'])
        num = g['tht']
        den = g['nwt']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 1, "birim": 'saat',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'egitim_katilim':
        d = egitim_katilim(g['npt'], g['nt'])
        num = g['npt']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'korunan_egitim':
        d = korunan_egitim(g['npup'], g['npt'])
        num = g['npup']
        den = g['npt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'geri_bildirim':
        d = geri_bildirim(g['nrf'], g['nt'])
        num = g['nrf']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'lider_egitim':
        d = lider_egitim(g['nlt'], g['nl'])
        num = g['nlt']
        den = g['nl']
        ifade = f"({_s(num)} \u00f7 {_s(den)}) \u00d7 100"
        return {"deger": d, "ondalik": 1, "birim": '%',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    if metrik == 'yetkinlik':
        d = yetkinlik(g['rcr'], g['nt'])
        num = g['rcr']
        den = g['nt']
        ifade = f"({_s(num)} \u00f7 {_s(den)})"
        return {"deger": d, "ondalik": 2, "birim": '/ birim yetkinlik',
                "ifade": ifade, "ayrinti": [["Pay", num], ["Payda", den]]}
    raise ValueError(f"Bilinmeyen metrik: {metrik}")


def _demo():
    """Ornek verilerle ana metrikleri calistirir (komut satiri dogrulamasi)."""
    print("ISO 30414:2025 - ornek metrik hesaplari")
    print("-" * 48)
    ornekler = [
        ("Toplam calisan",        "toplam_calisan", dict(ft=16400, pt=3140, tp=1120)),
        ("FTE",                   "fte",            dict(hft=30160000, hpt=3260000, hst=2080)),
        ("Cinsiyet cesitliligi",  "cinsiyet_cesitliligi", dict(gn=7327, nt=16400)),
        ("FTE basina ciro",       "ciro_fte",       dict(rt=1540000000, ntfte=16400)),
        ("HCROI (%)",             "hcroi",          dict(rt=4500000, te=3750000, cow=1500000)),
        ("Kaza orani (milyon s.)","kaza",           dict(toa=27, ht=12000000, navg=16400, tri=18)),
        ("Isgucu devir orani",    "devir",          dict(lt=1360, navg=16400)),
        ("Gonullu devir",         "gonullu_devir",  dict(lvl=1000, navg=16400)),
        ("Baglilik endeksi",      "baglilik_endeksi", dict(toplam_puan=62, madde_sayisi=7, olcek_max=10, onceki_endeks=85)),
        ("eNPS",                  "enps",           dict(destekci=520, karsit=180, yanit=1000)),
    ]
    for ad, mid, arg in ornekler:
        r = hesapla(mid, **arg)
        print(f"{ad:<24}: {round(r['deger'], r['ondalik'])} {r['birim']}")
    a = ornek_baglilik_anketi()
    print(f"{'Ornek anket endeksi':<24}: {a['endeks']} /100")


if __name__ == "__main__":
    _demo()

