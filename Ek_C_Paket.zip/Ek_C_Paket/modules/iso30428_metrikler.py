#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30428_metrikler.py
=====================
ISO/TS 30428:2021 (Human resource management — Skills and capabilities metrics
cluster) çerçevesindeki beceri ve yetkinlik metriklerinin Python karşılığı.

Standart, ISO 30414'ün "beceriler ve yetkinlikler" kümesini beş metrik üzerinden
tanımlar. Modül dört bölüme ayrılmıştır:

    1) Maliyet   — toplam gelişim ve eğitim maliyeti; toplulaştırılmış ve
       program düzeyinde iki hesaplama yolu
    2) Oranlar   — çalışan başına, öğrenen başına, bordroya ve gelire oran
    3) Katılım   — genel katılım oranı, kategoriye göre katılım, ortalama
       biçimsel eğitim saati
    4) Yetkinlik — işgücü yetkinlik oranı; basit ve ağırlıklı ortalama

Kullanım:
    from iso30428_metrikler import katilim_orani, ortalama_saat
    katilim_orani(950, 1000)     ->  95.0
    ortalama_saat(45000, 1000)   ->  45.0

Doğrudan çalıştırıldığında (python3 iso30428_metrikler.py) standardın üç vaka
çalışması ve örnek tabloları yeniden üretilir.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30428:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

__all__ = [
    # maliyet
    "toplam_maliyet", "tam_yuklu_oran", "program_maliyeti", "toplam_program_maliyeti",
    "yillik_degisim",
    # oranlar
    "kisi_basi_harcama", "ogrenen_basi_harcama", "bordro_payi", "gelir_payi",
    # katılım ve süre
    "katilim_orani", "kategori_katilim_orani", "ortalama_saat", "saat_dagilimi",
    # yetkinlik
    "agirlikli_yetkinlik", "basit_yetkinlik", "esik_alti_pay", "yetkinlik_acigi",
    # tablo
    "Kategori", "EgitimTablosu", "ornek_tablo", "metrik_denetimi",
    # dağıtıcı
    "hesapla", "METRIK_LISTESI",
]


def _s(x: float) -> str:
    """Sayıları bilimsel gösterime kaçmadan, Türkçe biçimde yazar."""
    x = float(x)
    if x == int(x):
        return f"{int(x):,}".replace(",", ".")
    t = f"{x:,.2f}".rstrip("0")
    if t.endswith("."):
        t = t[:-1]
    return t.replace(",", "\u00a0").replace(".", ",").replace("\u00a0", ".")


# ---------------------------------------------------------------------------
# 1) Toplam gelişim ve eğitim maliyeti
# ---------------------------------------------------------------------------

def toplam_maliyet(egitim_birimleri: float, diger_birimler: float,
                   ogrenim_destegi: float) -> float:
    """Toplam gelişim ve eğitim maliyeti.

    Kurum içindeki tüm eğitim birimlerinin harcaması + eğitim birimlerince
    zaten yakalanmamış olan diğer birimlerin eğitim harcaması (varsa) +
    sertifika ya da derece programları için öğrenim desteği harcaması.

    Kapsama girer: eğitim personelinin ücret ve yan hakları, genel giderler,
    eğitimin doğrudan maliyetleri (oda kirası, malzeme, personel seyahati),
    dış tedarikçiler (geliştirici, eğitmen, LMS sağlayıcısı), öğrenim desteği.

    Kapsam dışıdır: başka kurumların düzenlediği eğitim konferansları, eğitim
    birimi dışındaki çalışanların eğitime katılmak için yaptığı seyahat ve
    katılımcıların eğitimde geçirdiği zamanın değeri (fırsat maliyeti).
    """
    return egitim_birimleri + diger_birimler + ogrenim_destegi


def tam_yuklu_oran(ucret_orani: float, yuk_orani: float) -> float:
    """Tam yüklü saat ücreti = ücret ve bağlı maliyet oranı + yük oranı.

    Ücret ve bağlı maliyet oranı, saatlik ücrete doğrudan bağlı yan hakları
    (işveren payı vergiler gibi) da içerir. Yük, genel gideri temsil eder:
    bölüm gideri eksi ücret ve doğrudan (programa atfedilebilir) maliyetler.
    Yük oranı, yılda fiilen çalışılan saat sayısına bölünerek bulunur; izin,
    tatil, hastalık ve toplantı süreleri hesaba katıldığı için yük oranı çoğu
    zaman ücret oranı kadar ya da ondan yüksek çıkar.
    """
    return ucret_orani + yuk_orani


def program_maliyeti(personel_saati: float, ucret_orani: float,
                     yuk_orani: float, dogrudan: float) -> float:
    """Tek bir programın maliyeti (toplu veri bulunmayan küçük kurumlar için).

        (Personel zamanı × tam yüklü saat ücreti) + diğer doğrudan maliyetler

    Personel zamanı; ihtiyacın belirlenmesi ve doğrulanması, tasarım ve
    geliştirme ya da tedarikçi seçimi ve yönetimi, sunum, öğrenmenin
    pekiştirilmesi, sonuçların ölçülmesi ve programın kapatılması dâhil tüm
    eforu kapsar.
    """
    return personel_saati * tam_yuklu_oran(ucret_orani, yuk_orani) + dogrudan


def toplam_program_maliyeti(programlar: Sequence[Sequence[float]]) -> float:
    """Program düzeyinde hesaplanan maliyetlerin toplamı.

    programlar: her biri (personel_saati, ucret_orani, yuk_orani, dogrudan)
    dörtlüsü olan diziler.
    """
    return sum(program_maliyeti(*p) for p in programlar)


def yillik_degisim(cari: float, onceki: float) -> float:
    """Toplam maliyetin bir önceki yıla göre yüzde değişimi.

    Yıllık yüzde değişim, yaygın biçimde kıyaslanan bir metriktir.
    """
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 2) Dört yaygın oran
# ---------------------------------------------------------------------------

def kisi_basi_harcama(maliyet: float, calisan: float) -> float:
    """Çalışan başına ortalama harcama = toplam maliyet / çalışan sayısı.

    En yaygın kullanılan ve kıyaslanan orandır. Kimi kıyas ölçütleri kişi
    sayısı yerine tam zaman eşdeğerini kullanır; TZE kişi sayısından küçük
    olduğu için bu daha yüksek bir ortalama üretir.
    """
    return maliyet / calisan


def ogrenen_basi_harcama(maliyet: float, ogrenen: float) -> float:
    """Öğrenen başına ortalama harcama = toplam maliyet / öğrenen sayısı."""
    return maliyet / ogrenen


def bordro_payi(maliyet: float, bordro: float) -> float:
    """Toplam maliyetin bordroya oranı (%)."""
    return 100 * maliyet / bordro


def gelir_payi(maliyet: float, gelir: float) -> float:
    """Toplam maliyetin gelire oranı (%)."""
    return 100 * maliyet / gelir


# ---------------------------------------------------------------------------
# 3) Katılım ve süre
# ---------------------------------------------------------------------------

def katilim_orani(katilan: float, toplam: float) -> float:
    """Eğitime katılan çalışan oranı (%).

    En az bir biçimsel eğitim deneyimine katılan çalışan sayısının toplam
    çalışan sayısına oranı. Biçimsel eğitim; eğitmenli sınıf, sanal eğitmenli
    sınıf, çevrim içi ya da e-öğrenme, simülasyon ve biçimsel koçluğu kapsar;
    biçimsel bir kursun parçası olan yapılandırılmış mobil öğrenme de dâhildir.

    Bu bir genişlik (erişim) ölçüsüdür ve öğrenen başına harcama ile ortalama
    eğitim saati gibi derinlik ölçüleriyle birlikte okunur.
    """
    return 100 * katilan / toplam


def kategori_katilim_orani(kategoride_katilan: float, toplam: float) -> float:
    """Kategoriye göre katılım oranı (%).

    Payda, kurumun tamamı ya da o kategorideki toplam çalışan sayısı olabilir;
    hangisinin kullanıldığı raporda belirtilmelidir. Kategori listesi kuruma
    özgüdür; bu metrik dış raporlama için tasarlanmamıştır.
    """
    return 100 * kategoride_katilan / toplam


def ortalama_saat(toplam_saat: float, calisan: float) -> float:
    """Çalışan başına ortalama biçimsel eğitim saati.

    Toplam biçimsel eğitim saati, tüm biçimsel eğitimlerin saatlerinin
    toplamıdır. Biçimsel olmayan öğrenme (iş başında, gayriresmî koçluk,
    bilgi arama) hesaba katılmaz.
    """
    return toplam_saat / calisan


def saat_dagilimi(uyum_saat: float, toplam_saat: float) -> float:
    """Uyum eğitiminin toplam eğitim saati içindeki payı (%)."""
    return 100 * uyum_saat / toplam_saat


# ---------------------------------------------------------------------------
# 4) İşgücü yetkinlik oranı
# ---------------------------------------------------------------------------

def basit_yetkinlik(puanlar: Sequence[float]) -> float:
    """İşgücü yetkinlik oranı = çalışan yetkinlik puanlarının ortalaması.

    Yetkinlik, hiç/az yetenekten uzmanlığa uzanan bir yelpaze olarak
    tanımlanır ve çoğunlukla beş düzeyli bir ölçekle ölçülür. Puanlar nesnel
    bir ölçme aracıyla ya da çalışanın, yöneticisinin veya her ikisinin
    görüşüyle üretilebilir; her durumda işin gerekleri tanımlanmalı ve düzeyleri
    ayırt edecek bir ölçek kurulmalıdır. En az beş düzey önerilir.
    """
    return sum(puanlar) / len(puanlar)


def agirlikli_yetkinlik(puanlar: Sequence[float],
                        kisiler: Sequence[float]) -> float:
    """Grup ortalamalarının kişi sayısıyla ağırlıklı ortalaması.

    Bölüm, meslek grubu ya da kurum düzeyine çıkmak için kullanılır ve tüm
    çalışanların basit ortalamasıyla aynı sonucu verir; avantajı her grubun
    kendi oranını da göstermesidir.
    """
    return sum(p * k for p, k in zip(puanlar, kisiler)) / sum(kisiler)


def esik_alti_pay(puanlar: Sequence[float], esik: float) -> float:
    """İstenen yetkinlik düzeyinin altında kalan çalışanların payı (%).

    Ortalama tek başına dağılımı göstermez: ortalaması kabul edilebilir bir
    grupta bile çalışanların önemli bir bölümü eşiğin altında olabilir.
    """
    return 100 * sum(1 for p in puanlar if p < esik) / len(puanlar)


def yetkinlik_acigi(mevcut: float, hedef: float) -> float:
    """Hedef düzeye uzaklık (puan)."""
    return hedef - mevcut


# ---------------------------------------------------------------------------
# 5) Kategori tablosu
# ---------------------------------------------------------------------------

@dataclass
class Kategori:
    """Bir kategorinin (uyum, liderlik, demografik grup) eğitim verisi."""
    ad: str
    katilan: float
    toplam: float
    saat: float = 0

    @property
    def katilim(self) -> float:
        return katilim_orani(self.katilan, self.toplam)

    @property
    def saat_kisi(self) -> float:
        return ortalama_saat(self.saat, self.toplam)


@dataclass
class EgitimTablosu:
    """Kategorilerden oluşan katılım ve saat tablosu."""
    kategoriler: list = field(default_factory=list)

    def ekle(self, ad: str, katilan: float, toplam: float,
             saat: float = 0) -> "EgitimTablosu":
        self.kategoriler.append(Kategori(ad, katilan, toplam, saat))
        return self

    def ozet(self, hedef_katilim: float = 90) -> dict:
        genel = self.kategoriler[0]
        altta = [k.ad for k in self.kategoriler[1:] if k.katilim < hedef_katilim]
        return {
            "kategori_sayisi": len(self.kategoriler),
            "genel_kategori": genel.ad,
            "genel_katilim_yuzde": round(genel.katilim, 1),
            "genel_saat_kisi": round(genel.saat_kisi, 1),
            "hedef_katilim_yuzde": hedef_katilim,
            "hedefin_altinda": altta,
            "en_dusuk_katilim": min(
                ((k.ad, round(k.katilim, 1)) for k in self.kategoriler[1:]),
                key=lambda x: x[1], default=None),
            "en_yuksek_saat": max(
                ((k.ad, round(k.saat_kisi, 1)) for k in self.kategoriler[1:]),
                key=lambda x: x[1], default=None),
        }

    def tablo(self) -> list:
        return [[k.ad, k.katilan, k.toplam, k.saat,
                 round(k.katilim, 1), round(k.saat_kisi, 1)]
                for k in self.kategoriler]


def ornek_tablo() -> EgitimTablosu:
    """1.000 çalışanlı bir kurum için örnek katılım ve saat tablosu.

    İlk satır genel toplamdır: 950 çalışan en az bir biçimsel eğitime katılmış
    (%95), toplam 45.000 saat eğitim verilmiş (kişi başına 45 saat). Alt
    satırlar aynı verinin uyum, demografi ve kıdem kırılımlarıdır. Uyum dışı
    katılımın (%45) manşet orandan ne kadar düşük olduğu buradan görülür.
    """
    t = EgitimTablosu()
    t.ekle("Tüm çalışanlar", 950, 1000, 45000)
    t.ekle("Uyum eğitimi", 930, 1000, 17000)
    t.ekle("Uyum dışı eğitim", 450, 1000, 28000)
    t.ekle("Yönetim", 380, 400, 25000)
    t.ekle("Yönetim dışı", 570, 600, 20000)
    t.ekle("Kıdem: 1 yıldan az", 50, 50, 9000)
    t.ekle("Kıdem: 1–3 yıl", 250, 250, 13000)
    t.ekle("Kıdem: 4–10 yıl", 390, 400, 18000)
    t.ekle("Kıdem: 10 yıl ve üzeri", 260, 300, 5000)
    return t


def metrik_denetimi(maliyet_tanimi_yazili: bool = False,
                    payda_tanimi_yazili: bool = False,
                    uyum_ayrimi_var: bool = False,
                    kategori_listesi_var: bool = False,
                    yetkinlik_olcegi_aciklandi: bool = False,
                    gecici_isgucu_eki_var: bool = False,
                    genislik_ve_derinlik_birlikte: bool = False) -> list:
    """Bir beceri ve yetkinlik raporunun eksiklerini listeler.

    Standardın mantığı: hiçbir tek metrik eğitim çabasının bütününü göstermez;
    genişlik ve derinlik ölçüleri birlikte okunmalı, tanımlar açıklanmalıdır.
    """
    uyarilar = []
    if not maliyet_tanimi_yazili:
        uyarilar.append("Maliyet tanımının kapsamı yazılı değil: fırsat "
                        "maliyetinin dâhil olup olmadığı belirtilmeli, yoksa "
                        "kıyaslama yanıltır.")
    if not payda_tanimi_yazili:
        uyarilar.append("Payda tanımı belirsiz: çalışan sayısı, öğrenen sayısı, "
                        "tam zaman eşdeğeri ya da toplam işgücü.")
    if not uyum_ayrimi_var:
        uyarilar.append("Uyum ve uyum dışı eğitim ayrılmamış: manşet katılım "
                        "oranı gelişim fırsatının gerçek kapsamını gizler.")
    if not kategori_listesi_var:
        uyarilar.append("Kuruma özgü kategori listesi yok: eğitim karmasının "
                        "önceliklerle uyumu değerlendirilemez.")
    if not yetkinlik_olcegi_aciklandi:
        uyarilar.append("Yetkinlik ölçeği ve puanlama yöntemi açıklanmamış: "
                        "en az beş düzeyli bir ölçek önerilir.")
    if not gecici_isgucu_eki_var:
        uyarilar.append("Geçici işgücü için ek tablo yok: sözleşmeli ve geçici "
                        "işçilerin aldığı eğitim ayrı gösterilmeli.")
    if not genislik_ve_derinlik_birlikte:
        uyarilar.append("Genişlik (katılım) ve derinlik (harcama, saat) "
                        "ölçüleri birlikte raporlanmıyor: tek metrik bütünü "
                        "göstermez.")
    return uyarilar


# ---------------------------------------------------------------------------
# 6) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "toplam_maliyet", "program_maliyeti", "yillik_degisim",
    "kisi_basi_harcama", "ogrenen_basi_harcama", "bordro_payi", "gelir_payi",
    "katilim", "kategori_katilim", "ortalama_saat",
    "yetkinlik", "yetkinlik_agirlikli",
]


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "toplam_maliyet":
        d = toplam_maliyet(g["egitim_birimleri"], g["diger_birimler"],
                           g["ogrenim_destegi"])
        return {"deger": d, "ondalik": 0, "birim": "TL",
                "ifade": (f"{_s(g['egitim_birimleri'])} + {_s(g['diger_birimler'])} + "
                          f"{_s(g['ogrenim_destegi'])}"),
                "ayrinti": [["Eğitim birimlerinin payı (%)",
                             round(100 * g["egitim_birimleri"] / d, 1)],
                            ["Diğer birimlerin payı (%)",
                             round(100 * g["diger_birimler"] / d, 1)],
                            ["Öğrenim desteğinin payı (%)",
                             round(100 * g["ogrenim_destegi"] / d, 1)],
                            ["Çalışan başına harcama (TL)",
                             round(kisi_basi_harcama(d, g["calisan"]))]]}

    if metrik == "program_maliyeti":
        oran = tam_yuklu_oran(g["ucret_orani"], g["yuk_orani"])
        d = program_maliyeti(g["personel_saati"], g["ucret_orani"],
                             g["yuk_orani"], g["dogrudan"])
        return {"deger": d, "ondalik": 0, "birim": "TL / program",
                "ifade": (f"({_s(g['personel_saati'])} × {_s(oran)}) + "
                          f"{_s(g['dogrudan'])}"),
                "ayrinti": [["Tam yüklü saat ücreti (TL)", round(oran)],
                            ["Personel zamanının maliyeti (TL)",
                             round(g["personel_saati"] * oran)],
                            ["Doğrudan maliyetler (TL)", round(g["dogrudan"])],
                            ["Personel zamanının payı (%)",
                             round(100 * g["personel_saati"] * oran / d, 1)]]}

    if metrik == "yillik_degisim":
        d = yillik_degisim(g["cari"], g["onceki"])
        return {"deger": d, "ondalik": 1, "birim": "% yıllık değişim",
                "ifade": (f"(({_s(g['cari'])} − {_s(g['onceki'])}) ÷ "
                          f"{_s(g['onceki'])}) × 100"),
                "ayrinti": [["Mutlak değişim (TL)", round(g["cari"] - g["onceki"])],
                            ["Cari yıl kişi başı harcama (TL)",
                             round(kisi_basi_harcama(g["cari"], g["calisan"]))],
                            ["Önceki yıl kişi başı harcama (TL)",
                             round(kisi_basi_harcama(g["onceki"], g["calisan"]))]]}

    if metrik == "kisi_basi_harcama":
        d = kisi_basi_harcama(g["maliyet"], g["calisan"])
        return {"deger": d, "ondalik": 0, "birim": "TL / çalışan",
                "ifade": f"{_s(g['maliyet'])} ÷ {_s(g['calisan'])}",
                "ayrinti": [["Öğrenen başına harcama (TL)",
                             round(ogrenen_basi_harcama(g["maliyet"], g["ogrenen"]))],
                            ["TZE başına harcama (TL)",
                             round(kisi_basi_harcama(g["maliyet"], g["tze"]))],
                            ["Öğrenen oranı (%)",
                             round(100 * g["ogrenen"] / g["calisan"], 1)]]}

    if metrik == "ogrenen_basi_harcama":
        d = ogrenen_basi_harcama(g["maliyet"], g["ogrenen"])
        return {"deger": d, "ondalik": 0, "birim": "TL / öğrenen",
                "ifade": f"{_s(g['maliyet'])} ÷ {_s(g['ogrenen'])}",
                "ayrinti": [["Çalışan başına harcama (TL)",
                             round(kisi_basi_harcama(g["maliyet"], g["calisan"]))],
                            ["İki oran arasındaki fark (TL)",
                             round(d - kisi_basi_harcama(g["maliyet"], g["calisan"]))],
                            ["Eğitime katılmayan çalışan",
                             g["calisan"] - g["ogrenen"]]]}

    if metrik == "bordro_payi":
        d = bordro_payi(g["maliyet"], g["bordro"])
        return {"deger": d, "ondalik": 2, "birim": "% bordro",
                "ifade": f"({_s(g['maliyet'])} ÷ {_s(g['bordro'])}) × 100",
                "ayrinti": [["Gelire oranı (%)",
                             round(gelir_payi(g["maliyet"], g["gelir"]), 2)],
                            ["Bordronun gelire oranı (%)",
                             round(100 * g["bordro"] / g["gelir"], 1)],
                            ["Toplam eğitim maliyeti (TL)", round(g["maliyet"])]]}

    if metrik == "gelir_payi":
        d = gelir_payi(g["maliyet"], g["gelir"])
        return {"deger": d, "ondalik": 2, "birim": "% gelir",
                "ifade": f"({_s(g['maliyet'])} ÷ {_s(g['gelir'])}) × 100",
                "ayrinti": [["Çalışan başına gelir (TL)",
                             round(g["gelir"] / g["calisan"])],
                            ["Çalışan başına eğitim harcaması (TL)",
                             round(kisi_basi_harcama(g["maliyet"], g["calisan"]))],
                            ["Toplam eğitim maliyeti (TL)", round(g["maliyet"])]]}

    if metrik == "katilim":
        d = katilim_orani(g["katilan"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% katılım",
                "ifade": f"({_s(g['katilan'])} ÷ {_s(g['toplam'])}) × 100",
                "ayrinti": [["Uyum dışı katılım oranı (%)",
                             round(katilim_orani(g["uyum_disi"], g["toplam"]), 1)],
                            ["İki oran arasındaki fark (puan)",
                             round(d - katilim_orani(g["uyum_disi"], g["toplam"]), 1)],
                            ["Hiç eğitim almayan çalışan",
                             g["toplam"] - g["katilan"]],
                            ["Yalnızca uyum eğitimi alan (kişi)",
                             g["katilan"] - g["uyum_disi"]]]}

    if metrik == "kategori_katilim":
        d = kategori_katilim_orani(g["kategoride_katilan"], g["kategori_toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% kategori katılımı",
                "ifade": (f"({_s(g['kategoride_katilan'])} ÷ "
                          f"{_s(g['kategori_toplam'])}) × 100"),
                "ayrinti": [["Kurum genelindeki payı (%)",
                             round(kategori_katilim_orani(g["kategoride_katilan"],
                                                          g["kurum_toplam"]), 1)],
                            ["Kategorideki katılmayan (kişi)",
                             g["kategori_toplam"] - g["kategoride_katilan"]],
                            ["Kategorinin kurumdaki payı (%)",
                             round(100 * g["kategori_toplam"] / g["kurum_toplam"], 1)]]}

    if metrik == "ortalama_saat":
        d = ortalama_saat(g["toplam_saat"], g["calisan"])
        return {"deger": d, "ondalik": 1, "birim": "saat / çalışan",
                "ifade": f"{_s(g['toplam_saat'])} ÷ {_s(g['calisan'])}",
                "ayrinti": [["TZE başına saat",
                             round(ortalama_saat(g["toplam_saat"], g["tze"]), 1)],
                            ["Uyum eğitiminin payı (%)",
                             round(saat_dagilimi(g["uyum_saat"], g["toplam_saat"]), 1)],
                            ["Çalışan başına uyum dışı saat",
                             round(ortalama_saat(g["toplam_saat"] - g["uyum_saat"],
                                                 g["calisan"]), 1)],
                            ["Öğrenen başına saat",
                             round(ortalama_saat(g["toplam_saat"], g["ogrenen"]), 1)]]}

    if metrik == "yetkinlik":
        puanlar = [float(x) for x in g["puanlar"]]
        d = basit_yetkinlik(puanlar)
        return {"deger": d, "ondalik": 2, "birim": "ortalama yetkinlik düzeyi",
                "ifade": (f"({' + '.join(_s(p) for p in puanlar)}) ÷ "
                          f"{len(puanlar)}"),
                "ayrinti": [["Değerlendirilen çalışan", len(puanlar)],
                            ["Hedef düzeyin altında kalan pay (%)",
                             round(esik_alti_pay(puanlar, g["hedef"]), 1)],
                            ["Hedefe uzaklık (puan)",
                             round(yetkinlik_acigi(d, g["hedef"]), 2)],
                            ["En üst düzeydeki çalışan (kişi)",
                             sum(1 for p in puanlar if p >= g["olcek"])]]}

    if metrik == "yetkinlik_agirlikli":
        puanlar = [float(x) for x in g["grup_puanlari"]]
        kisiler = [float(x) for x in g["grup_kisileri"]]
        d = agirlikli_yetkinlik(puanlar, kisiler)
        toplam_kisi = sum(kisiler)
        return {"deger": d, "ondalik": 2, "birim": "ağırlıklı yetkinlik düzeyi",
                "ifade": " + ".join(
                    f"({_s(p)} × {_s(k)}/{_s(toplam_kisi)})"
                    for p, k in zip(puanlar, kisiler)),
                "ayrinti": [["Grup sayısı", len(puanlar)],
                            ["Toplam çalışan", toplam_kisi],
                            ["Grupların basit ortalaması",
                             round(basit_yetkinlik(puanlar), 2)],
                            ["Hedefe uzaklık (puan)",
                             round(yetkinlik_acigi(d, g["hedef"]), 2)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 7) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def _demo() -> None:
    cizgi = "-" * 76
    print("ISO/TS 30428 — doğrulama çıktısı")
    print(cizgi)

    print("Vaka 1: tek merkezî eğitim birimi ve beş iş birimi")
    birimler = [("Eğitim birimi", 515_000), ("İş birimi 1", 15_000),
                ("İş birimi 2", 10_000), ("İş birimi 3", 35_000),
                ("İş birimi 4", 20_000), ("İş birimi 5", 25_000),
                ("Öğrenim desteği", 30_000)]
    for ad, tutar in birimler:
        print(f"  {ad:<24}{_tl(tutar):>12}")
    t1 = toplam_maliyet(515_000, 105_000, 30_000)
    print(f"  {'TOPLAM':<24}{_tl(t1):>12}")
    print(f"  Eğitim biriminin payı  : {100 * 515_000 / t1:.0f} %")
    print(cizgi)

    print("Vaka 2: küçük merkezî birim + kendi eğitim birimi olan iş birimleri")
    t2 = toplam_maliyet(65_000, 115_000 + 145_000 + 25_000 + 15_000 + 230_000,
                        30_000)
    print(f"  TOPLAM                  {_tl(t2):>12}")
    print(cizgi)

    print("Vaka 3: eğitim birimi olmayan kurum (program düzeyinde hesap)")
    programlar = [(40, 35, 50, 5_000), (80, 40, 50, 10_000), (20, 50, 50, 25_000)]
    for i, p in enumerate(programlar, 1):
        oran = tam_yuklu_oran(p[1], p[2])
        print(f"  Program {i}: ({p[0]} sa × {oran}) + {_tl(p[3])} = "
              f"{_tl(program_maliyeti(*p))}")
    print(f"  TOPLAM                  {_tl(toplam_program_maliyeti(programlar)):>12}")
    print(cizgi)

    print("Dört yaygın oran (maliyet 100.000; 50 çalışan, 30 öğrenen)")
    print(f"  Çalışan başına harcama : {_tl(kisi_basi_harcama(100_000, 50))}")
    print(f"  Öğrenen başına harcama : {_tl(ogrenen_basi_harcama(100_000, 30))}")
    print(f"  Bordro payı            : {bordro_payi(100_000, 2_500_000):.1f} %")
    print(f"  Gelir payı             : {gelir_payi(100_000, 10_000_000):.1f} %")
    print(cizgi)

    tab = ornek_tablo()
    print("Katılım ve saat tablosu (1.000 çalışanlı kurum)")
    print(f"{'Kategori':<26}{'Katılan':>9}{'Toplam':>8}{'Saat':>9}"
          f"{'Katılım %':>11}{'Saat/kişi':>11}")
    for s in tab.tablo():
        print(f"{s[0]:<26}{s[1]:>9.0f}{s[2]:>8.0f}{s[3]:>9.0f}{s[4]:>11.1f}{s[5]:>11.1f}")
    print(cizgi)
    for k, v in tab.ozet().items():
        print(f"{k:<24}: {v}")
    print(cizgi)

    print("İşgücü yetkinlik oranı")
    temsilciler = [3, 3, 2, 3, 4, 4, 5, 1]
    print(f"  Satış temsilcileri (8)  : {basit_yetkinlik(temsilciler):.2f}")
    print(f"  Süpervizörler (2)       : {basit_yetkinlik([3, 4]):.2f}")
    print(f"  Bölüm müdürü (1)        : {basit_yetkinlik([4]):.2f}")
    agirlikli = agirlikli_yetkinlik([3.125, 3.5, 4.0], [8, 2, 1])
    print(f"  Ağırlıklı ortalama      : {agirlikli:.2f}")
    print(f"  Basit ortalama (11 kişi): {basit_yetkinlik(temsilciler + [3, 4, 4]):.2f}")
    print(f"  Hedef 3'ün altında kalan: "
          f"{esik_alti_pay(temsilciler + [3, 4, 4], 3):.1f} %")
    print(cizgi)

    print("Bölüm düzeyinden kurum düzeyine (10 bölüm, 1.000 çalışan)")
    puan = [3.28, 3.73, 2.91, 2.47, 3.68, 4.24, 2.56, 2.80, 3.29, 2.68]
    kisi = [11, 56, 19, 125, 345, 85, 175, 22, 58, 104]
    print(f"  Kurum yetkinlik oranı   : {agirlikli_yetkinlik(puan, kisi):.2f}")
    dusuk = [f"Bölüm {i+1} ({p})" for i, p in enumerate(puan) if p < 3]
    print(f"  Hedefin altındaki bölümler: {', '.join(dusuk)}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("katilim", katilan=950, toplam=1000, uyum_disi=450))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
