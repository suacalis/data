#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso23326_metrikler.py
=====================
BS ISO 23326:2022 (Human resource management — Employee engagement — Guidelines)
çerçevesindeki çalışan bağlılığı ölçüm ve öz değerlendirme kavramlarının Python karşılığı.

Standart bir rehberdir: formül, eşik ya da ölçek vermez. Ölçümü (madde 5.3) yalnızca
yöntem olarak sayar: odak grupları, çalışan anketleri ve geçerli araçlar (ör. Utrecht
İşe Bağlılık Ölçeği, UWES). Bağlılığı dinçlik (vigour), adanmışlık (dedication) ve
yoğunlaşma (absorption) boyutlarıyla tanımlar (madde 4.3). Bu modüldeki tüm hesaplar
bu kavramları sayıya dökmek için TÜRETİLMİŞTİR. Modül üç bölüme ayrılmıştır:

    1) Ölçüm      — UWES benzeri puan, anket katılımı, olumlu yanıt, dönemsel değişim, anonimlik
    2) Uygulama   — fazla çalışma, işe başlama programı, eğitime erişim, kapsama (madde 6–10)
    3) Yapılar    — öz değerlendirme tablosu, ilke denetimi (madde 4.1), dağıtıcı

Kullanım:
    from iso23326_metrikler import katilim_orani, kapsama
    katilim_orani(420, 600)     ->  70.0
    kapsama(6, 4, 1)            ->  75.0

Doğrudan çalıştırıldığında (python3 iso23326_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Kavramlar ISO 23326:2022'ye dayanır. Oranlar, 0–6 ölçeği (UWES kılavuzundan),
kapsama puanlaması ve denetim kuralları bu modülde türetilmiştir. Kod ve açıklamalar
özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi", "ALANLAR", "KOSULLAR",
    "uwes_puani", "katilim_orani", "olumlu_oran", "donemsel_degisim", "anonimlik_marji",
    "fazla_calisma_orani", "onboarding_orani", "egitim_erisimi", "kapsama",
    "Alan", "OzDegerlendirme", "ornek_tablo", "ilke_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, negatif değer, ölçek dışı puan vb."""


# Madde 6–10: rehber ifadelerinin sayısı (standarttaki "organizations should" maddeleri)
ALANLAR = [
    ("6.2", "Kültür ve değerler", 6),
    ("6.3", "İletişim", 7),
    ("6.4", "Çalışanların güçlendirilmesi", 7),
    ("6.5", "Çalışan temsili", 2),
    ("7", "Destekleyici liderlik", 7),
    ("8", "Örgütsel öğrenme", 9),
    ("9.2", "İş tasarımı", 3),
    ("9.3", "Çalışma ortamı", 8),
    ("9.4", "İşyerinde sağlığı geliştirme", 7),
    ("9.5", "Dayanıklılık, sürdürülebilirlik ve iş-yaşam yönetimi", 3),
    ("10.2", "Ücret (dışsal)", 4),
    ("10.3", "Takdir (içsel)", 4),
]

# Şekil 1: bağlılığın koşulları (öncüller)
KOSULLAR = ["Örgüt kültürü ve iletişim", "Destekleyici liderlik", "Örgütsel öğrenme",
            "İş içeriği ve iş tasarımı", "Ücret ve takdir"]


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


# ---------------------------------------------------------------------------
# 1) Ölçüm (madde 4.3, 5.3, 4.1)
# ---------------------------------------------------------------------------

def uwes_puani(dincilik: list, adanmislik: list, yogunlasma: list) -> dict:
    """UWES benzeri puan: her boyutun ortalaması ve dokuz maddenin genel ortalaması (0–6 ölçeği).

    Standart yalnızca ölçeğin adını anar (5.3); 0–6 ölçeği ve üç madde/boyut düzeni
    ölçeğin kısa formundan alınmıştır, bu sayfada türetilmiş kabul edilir.
    """
    for ad, liste in (("dinçlik", dincilik), ("adanmışlık", adanmislik), ("yoğunlaşma", yogunlasma)):
        if len(liste) != 3:
            raise GecersizGirdi(f"{ad} için üç madde puanı gerekir")
        for p in liste:
            if p < 0 or p > 6:
                raise GecersizGirdi(f"{ad} puanı 0 ile 6 arasında olmalı")
    d = sum(dincilik) / 3
    a = sum(adanmislik) / 3
    y = sum(yogunlasma) / 3
    toplam_madde = sum(dincilik) + sum(adanmislik) + sum(yogunlasma)
    boyutlar = [("dinçlik", d), ("adanmışlık", a), ("yoğunlaşma", y)]
    en_dusuk = boyutlar[0]
    for b in boyutlar[1:]:
        if b[1] < en_dusuk[1]:
            en_dusuk = b
    return {"dincilik": d, "adanmislik": a, "yogunlasma": y,
            "toplam": toplam_madde / 9, "madde_toplami": toplam_madde, "en_dusuk": en_dusuk[0]}


def katilim_orani(yanit: float, davet: float) -> float:
    """Anket katılım oranı: yanıt veren ÷ davet edilen × 100 (%)."""
    _negatif_yok(yanit=yanit)
    if yanit > davet:
        raise GecersizGirdi("yanıt sayısı davet edilen sayısını aşamaz")
    return 100 * _bol(yanit, davet, "davet edilen sayısı")


def olumlu_oran(olumlu: float, toplam: float) -> float:
    """Olumlu yanıt oranı: olumlu yanıt ÷ toplam yanıt × 100 (%)."""
    _negatif_yok(olumlu=olumlu)
    if olumlu > toplam:
        raise GecersizGirdi("olumlu yanıt sayısı toplam yanıtı aşamaz")
    return 100 * _bol(olumlu, toplam, "toplam yanıt")


def donemsel_degisim(onceki: float, simdiki: float) -> float:
    """İki ölçüm dönemi arasındaki puan farkı: şimdiki − önceki."""
    _negatif_yok(onceki=onceki, simdiki=simdiki)
    return simdiki - onceki


def anonimlik_marji(grup: float, esik: float) -> float:
    """Raporlama grubu büyüklüğü − kurumun belirlediği asgari grup büyüklüğü (≥ 0 ise kabul)."""
    _negatif_yok(grup=grup)
    if esik <= 0:
        raise GecersizGirdi("asgari grup büyüklüğü sıfırdan büyük olmalı")
    return grup - esik


# ---------------------------------------------------------------------------
# 2) Uygulama göstergeleri (madde 9.3, 8, 6.4 ve 6–10)
# ---------------------------------------------------------------------------

def fazla_calisma_orani(gercek: float, sozlesme: float) -> float:
    """Sözleşme süresinin üstünde çalışma payı: (gerçek − sözleşme) ÷ sözleşme × 100 (%)."""
    _negatif_yok(gercek=gercek)
    return 100 * _bol(gercek - sozlesme, sozlesme, "sözleşme süresi")


def onboarding_orani(tamamlayan: float, yeni: float) -> float:
    """İşe başlama programını tamamlayan yeni çalışanların payı (%)."""
    _negatif_yok(tamamlayan=tamamlayan)
    if tamamlayan > yeni:
        raise GecersizGirdi("tamamlayan sayısı yeni işe başlayan sayısını aşamaz")
    return 100 * _bol(tamamlayan, yeni, "yeni işe başlayan sayısı")


def egitim_erisimi(katilan: float, calisan: float) -> float:
    """Dönem içinde en az bir öğrenme etkinliğine katılan çalışanların payı (%)."""
    _negatif_yok(katilan=katilan)
    if katilan > calisan:
        raise GecersizGirdi("katılan sayısı çalışan sayısını aşamaz")
    return 100 * _bol(katilan, calisan, "çalışan sayısı")


def kapsama(toplam: float, uygulanan: float, kismen: float = 0) -> float:
    """Rehber ifadelerinin uygulama kapsaması (%): (uygulanan + 0,5 × kısmen) ÷ toplam × 100."""
    _negatif_yok(uygulanan=uygulanan, kismen=kismen)
    if uygulanan + kismen > toplam:
        raise GecersizGirdi("uygulanan ve kısmen uygulanan toplamı ifade sayısını aşamaz")
    return 100 * _bol(uygulanan + 0.5 * kismen, toplam, "ifade sayısı")


# ---------------------------------------------------------------------------
# 3) Yapılar: öz değerlendirme tablosu ve ilke denetimi
# ---------------------------------------------------------------------------

@dataclass
class Alan:
    """Standardın bir maddesi için öz değerlendirme satırı."""
    kod: str
    ad: str
    toplam: int
    uygulanan: float = 0
    kismen: float = 0

    def kapsama(self) -> float:
        return kapsama(self.toplam, self.uygulanan, self.kismen)


@dataclass
class OzDegerlendirme:
    """Madde 6–10 için öz değerlendirme tablosu. Hedef kapsama kurumca belirlenir (varsayılan %70)."""
    alanlar: list = field(default_factory=lambda: [Alan(k, a, n) for k, a, n in ALANLAR])
    hedef: float = 70.0

    def gir(self, kod: str, uygulanan: float, kismen: float = 0) -> "OzDegerlendirme":
        for a in self.alanlar:
            if a.kod == kod:
                a.uygulanan, a.kismen = uygulanan, kismen
                a.kapsama()  # doğrulama
                return self
        raise GecersizGirdi(f"bilinmeyen madde: {kod}")

    def ozet(self) -> dict:
        toplam = sum(a.toplam for a in self.alanlar)
        uyg = sum(a.uygulanan for a in self.alanlar)
        kis = sum(a.kismen for a in self.alanlar)
        oranlar = [(a.kapsama(), a.kod) for a in self.alanlar]
        en_zayif = oranlar[0]
        for o in oranlar[1:]:
            if o[0] < en_zayif[0]:
                en_zayif = o
        return {
            "alan_sayisi": len(self.alanlar),
            "toplam_ifade": toplam,
            "genel_kapsama": round(kapsama(toplam, uyg, kis), 1),
            "hedef_alti": [k for o, k in oranlar if o < self.hedef],
            "en_zayif": en_zayif[1],
        }


def ornek_tablo() -> OzDegerlendirme:
    """Örnek amaçlı doldurulmuş tablo (standart bu sayıları vermez)."""
    t = OzDegerlendirme()
    for kod, u, k in [("6.2", 4, 1), ("6.3", 5, 1), ("6.4", 3, 2), ("6.5", 2, 0), ("7", 4, 2), ("8", 5, 2),
                      ("9.2", 1, 1), ("9.3", 4, 2), ("9.4", 3, 1), ("9.5", 2, 0), ("10.2", 3, 0), ("10.3", 1, 1)]:
        t.gir(kod, u, k)
    return t


def ilke_denetimi(paydas_rolleri_tanimli: bool = False,
                  kulture_ve_politikaya_gomulu: bool = False,
                  iki_yonlu_iletisim_var: bool = False,
                  ilerleme_duzenli_olculuyor_anonim: bool = False,
                  asiri_baglilik_riski_degerlendiriliyor: bool = False,
                  veri_koruma_yasalarina_uyum: bool = False) -> list:
    """Madde 4.1'deki altı ilkeye göre eksikleri listeler (hazırlık kontrol listesi, uygunluk sınaması değil)."""
    kontroller = [
        (paydas_rolleri_tanimli, "Üst yönetim, yöneticiler, İK uzmanları, çalışanlar ve temsilcilerin bağlılıktaki rolleri tanımlı değil."),
        (kulture_ve_politikaya_gomulu, "Çalışan bağlılığı kurum kültürüne gömülü değil ya da politikalarla hayata geçirilmiyor."),
        (iki_yonlu_iletisim_var, "İki yönlü iletişim mekanizması tanımlı değil."),
        (ilerleme_duzenli_olculuyor_anonim, "Bağlılık hedeflerine karşı ilerleme düzenli ve bireysel düzeyde anonim ve gizli yöntemlerle ölçülmüyor."),
        (asiri_baglilik_riski_degerlendiriliyor, "Uzun süreli aşırı bağlılığın sağlık riskleri düzenli değerlendirilmiyor."),
        (veri_koruma_yasalarina_uyum, "Veri koruma ve gizlilik mevzuatı gözetilmiyor."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["uwes", "katilim", "olumlu", "degisim", "anonim",
                  "fazla", "onboarding", "egitim", "kapsama"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "uwes":
        u = uwes_puani([g["d1"], g["d2"], g["d3"]], [g["a1"], g["a2"], g["a3"]], [g["y1"], g["y2"], g["y3"]])
        return {"deger": u["toplam"], "ondalik": 2, "birim": "puan (0–6 ortalama)",
                "ifade": f"{_g(u['madde_toplami'])} ÷ 9",
                "ayrinti": [["Dinçlik (vigour) ortalaması", round(u["dincilik"], 2)],
                            ["Adanmışlık (dedication) ortalaması", round(u["adanmislik"], 2)],
                            ["Yoğunlaşma (absorption) ortalaması", round(u["yogunlasma"], 2)],
                            ["En düşük boyut", u["en_dusuk"]]]}

    if metrik == "katilim":
        d = katilim_orani(g["yanit"], g["davet"])
        return {"deger": d, "ondalik": 1, "birim": "% (yanıt ÷ davet)",
                "ifade": f"{_g(g['yanit'])} ÷ {_g(g['davet'])} × 100",
                "ayrinti": [["Yanıt vermeyen", round(g["davet"] - g["yanit"], 2)],
                            ["Yanıt vermeyenlerin payı (%)", round(100 - d, 1)]]}

    if metrik == "olumlu":
        d = olumlu_oran(g["olumlu"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% (olumlu ÷ toplam yanıt)",
                "ifade": f"{_g(g['olumlu'])} ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Olumlu olmayan yanıt", round(g["toplam"] - g["olumlu"], 2)],
                            ["Olumlu olmayanların payı (%)", round(100 - d, 1)]]}

    if metrik == "degisim":
        d = donemsel_degisim(g["onceki"], g["simdiki"])
        return {"deger": d, "ondalik": 2, "birim": "puan (şimdiki − önceki)",
                "ifade": f"{_g(g['simdiki'])} − {_g(g['onceki'])}",
                "ayrinti": [["Önceki döneme göre değişim (%)", round(100 * _bol(d, g["onceki"], "önceki dönem puanı"), 1)]]}

    if metrik == "anonim":
        d = anonimlik_marji(g["grup"], g["esik"])
        return {"deger": d, "ondalik": 0, "birim": "kişi (grup − eşik)",
                "ifade": f"{_g(g['grup'])} − {_g(g['esik'])}",
                "ayrinti": [["Grup büyüklüğü ÷ eşik", round(g["grup"] / g["esik"], 2)]]}

    if metrik == "fazla":
        d = fazla_calisma_orani(g["gercek"], g["sozlesme"])
        return {"deger": d, "ondalik": 1, "birim": "% (sözleşme süresinin üstü)",
                "ifade": f"({_g(g['gercek'])} − {_g(g['sozlesme'])}) ÷ {_g(g['sozlesme'])} × 100",
                "ayrinti": [["Fark (saat/hafta)", round(g["gercek"] - g["sozlesme"], 2)]]}

    if metrik == "onboarding":
        d = onboarding_orani(g["tamamlayan"], g["yeni"])
        return {"deger": d, "ondalik": 1, "birim": "% (tamamlayan ÷ yeni)",
                "ifade": f"{_g(g['tamamlayan'])} ÷ {_g(g['yeni'])} × 100",
                "ayrinti": [["Programı tamamlamayan", round(g["yeni"] - g["tamamlayan"], 2)]]}

    if metrik == "egitim":
        d = egitim_erisimi(g["katilan"], g["calisan"])
        return {"deger": d, "ondalik": 1, "birim": "% (katılan ÷ çalışan)",
                "ifade": f"{_g(g['katilan'])} ÷ {_g(g['calisan'])} × 100",
                "ayrinti": [["Etkinliğe katılmayan çalışan", round(g["calisan"] - g["katilan"], 2)]]}

    if metrik == "kapsama":
        d = kapsama(g["toplam"], g["uygulanan"], g["kismen"])
        return {"deger": d, "ondalik": 1, "birim": "% (kapsama)",
                "ifade": f"({_g(g['uygulanan'])} + 0,5 × {_g(g['kismen'])}) ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Hiç uygulanmayan ifade", round(g["toplam"] - g["uygulanan"] - g["kismen"], 2)],
                            ["Yalnızca tam uygulananların payı (%)", round(100 * g["uygulanan"] / g["toplam"], 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 23326 — doğrulama çıktısı")
    print(cizgi)

    u = uwes_puani([5, 4, 5], [4, 5, 4], [3, 4, 3])
    print(f"UWES benzeri puan : {u['toplam']:.2f} (dinçlik {u['dincilik']:.2f}, adanmışlık {u['adanmislik']:.2f}, "
          f"yoğunlaşma {u['yogunlasma']:.2f}); en düşük: {u['en_dusuk']}")
    print(f"Katılım (420/600) : %{katilim_orani(420, 600):.1f}")
    print(f"Olumlu (310/420)  : %{olumlu_oran(310, 420):.1f}")
    print(f"Değişim (4,1→4,3) : {donemsel_degisim(4.1, 4.3):+.2f} puan")
    print(f"Anonimlik (8, 5)  : {anonimlik_marji(8, 5):+.0f} kişi")
    print(f"Fazla çalışma     : %{fazla_calisma_orani(44, 40):.1f}")
    print(f"Kapsama (6, 4, 1) : %{kapsama(6, 4, 1):.1f}")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<14}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("katilim", yanit=420, davet=600))
    print(cizgi)

    print("İlke denetimi (hiçbir ilkeyi sağlamayan bir kurum için):")
    for u in ilke_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
