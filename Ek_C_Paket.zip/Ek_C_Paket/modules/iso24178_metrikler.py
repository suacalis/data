#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso24178_metrikler.py
=====================
ISO/TS 24178:2021 (Human resource management — Organizational culture
metrics cluster) çerçevesindeki örgüt kültürü metriklerinin Python karşılığı.

Teknik şartname, ISO 30414'ün "örgüt kültürü" kümesindeki iki metriği ele
alır: bağlılık, memnuniyet ve bağlanma ile tutma oranı. Her metrik için
genel tanım, amaç, formül, bağlam etkenleri ve öngörü etkenlerini anlatır.
Bağlılık için Ek A'da 25 maddelik bir temel anket ve puanlama örneği
verir (beşli ölçek, toplam puan 125'e bölünür). Tutma oranının ayrıntılı
formülü ISO/TS 30421'e bırakılmıştır. Bu modüldeki formüller, şartnamenin
anlattığı ölçümlerin yaygın uygulama tanımlarıdır ve kurumunuzun kendi
tanımıyla uyarlanmalıdır. Modül dört bölümden oluşur:

    1) Anket puanlaması — madde puanı, kültür endeksi, boyut puanları
    2) Yanıt ve bölge raporlaması — yanıt oranı, bölge endeksi (Tablo 2)
    3) Tutma — tutma oranı ve kayıp nedeni dağılımı
    4) Yardımcı yapılar — anket tablosu, kültür denetimi, dağıtıcı

Kullanım:
    from iso24178_metrikler import madde_ortalamasi, kultur_endeksi
    madde_ortalamasi(6, 20, 48, 84, 42)   ->  3.68
    kultur_endeksi(18000, 200)            ->  72.0

Doğrudan çalıştırıldığında (python3 iso24178_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, ölçek ve anket yapısı ISO/TS 24178:2021'e dayanır. Kod,
madde metinlerinin Türkçe karşılıkları, açıklamalar ve örnek değerler özgün
olarak yazılmıştır; şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # anket puanlaması
    "madde_ortalamasi", "olumlu_orani", "kultur_endeksi", "boyut_puani", "zayif_boyut",
    # yanıt ve bölge raporlaması
    "yanit_orani", "hata_payi", "bolge_endeksi", "agirlikli_bolge_endeksi",
    # tutma
    "tutma_orani", "erken_kayip_payi",
    # yardımcı
    "MADDELER", "BOYUTLAR", "AnketTablosu", "ornek_tablo", "kultur_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _oran(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


# ---------------------------------------------------------------------------
# 1) Anket puanlaması (Ek A)
# ---------------------------------------------------------------------------

# Ek A: kesinlikle katılmıyorum = 1 ... kesinlikle katılıyorum = 5
SECENEKLER = ("Kesinlikle katılmıyorum", "Katılmıyorum", "Ne katılıyorum ne katılmıyorum",
              "Katılıyorum", "Kesinlikle katılıyorum")

# Ek A'daki 25 temel kültür ifadesinin özgün Türkçe karşılıkları
MADDELER = [
    "Kurumumuzun net bir amacı var.",
    "İşimin bu amaca nasıl hizmet ettiğini anlıyorum.",
    "Şirketimizin net davranışsal değerleri var.",
    "Çalışmam karşılığında adil ücret alıyorum.",
    "İşim için net bir yönlendirme alıyorum.",
    "İşimi yapmak için gereken araç ve ekipmana sahibim.",
    "İş yükleri genellikle makul.",
    "Beyan edilen değerlerimiz karar vermeye yön veriyor.",
    "Katkım için değer görüyorum.",
    "İşimi yapacağıma güveniliyor.",
    "Kurum içi iletişim etkili.",
    "İşbirliği destekleniyor.",
    "Kurum bana adil davranıyor.",
    "Çalışan önerileri teşvik ediliyor.",
    "Çalışan önerileri uygulanıyor.",
    "Kurumumuzda insanlar iş birliği yapıyor.",
    "İnsanlar birbirine yardım etmeye istekli.",
    "İnsanların gelişme fırsatı var.",
    "Öğrenme ve gelişim teşvik ediliyor.",
    "Amirime güveniyorum.",
    "Üst düzey kurumsal liderliğe güveniyorum.",
    "Bu kurum etik davranıyor.",
    "Çalışanlar iyi işleri için takdir ediliyor.",
    "İş yerimizde stres iyi yönetiliyor.",
    "Kurumumuz toplumsal olarak sorumlu.",
]

# (boyut adı, ilk madde, son madde) — Ek A.2.3'teki eşleme
BOYUTLAR = [
    ("Amaç ifadesinin varlığı", 1, 2),
    ("Değer ifadesinin varlığı", 3, 3),
    ("Amaç: çalışanın gerçekliği", 4, 7),
    ("Davranışsal değerler", 8, 19),
    ("Liderlik hizalaması", 20, 25),
]


def madde_ortalamasi(kes_katilmiyor: float, katilmiyor: float, kararsiz: float,
                     katiliyor: float, kes_katiliyor: float) -> float:
    """Bir ifadenin ortalama puanı (1–5): puan × yanıt sayısı toplamı / yanıtlayan."""
    sayilar = (kes_katilmiyor, katilmiyor, kararsiz, katiliyor, kes_katiliyor)
    if min(sayilar) < 0:
        raise GecersizGirdi("yanıt sayıları negatif olamaz")
    n = sum(sayilar)
    if n <= 0:
        raise GecersizGirdi("yanıtlayan sayısı sıfırdan büyük olmalı")
    return sum((i + 1) * s for i, s in enumerate(sayilar)) / n


def olumlu_orani(katiliyor: float, kes_katiliyor: float, toplam: float) -> float:
    """Olumlu yanıt (katılıyorum + kesinlikle katılıyorum) oranı (%)."""
    return _oran(katiliyor + kes_katiliyor, toplam, "olumlu yanıt")


def kultur_endeksi(toplam_puan: float, yanitci: float, madde_sayisi: int = 25) -> float:
    """Genel kültür yüzdesi = toplam puan / (5 × madde sayısı × yanıtlayan) × 100.

    Ek A: her ifade puanlanır ve toplam puan 125'e bölünerek genel yüzde sonuç
    elde edilir (25 madde × en fazla 5 puan). Çok yanıtlayanlı veride payda,
    yanıtlayan sayısıyla çarpılır.
    """
    if madde_sayisi <= 0 or yanitci <= 0:
        raise GecersizGirdi("madde ve yanıtlayan sayısı sıfırdan büyük olmalı")
    azami = 5 * madde_sayisi * yanitci
    en_az = madde_sayisi * yanitci
    if toplam_puan < en_az or toplam_puan > azami:
        raise GecersizGirdi("toplam puan olası aralığın dışında")
    return 100 * toplam_puan / azami


def boyut_puani(ortalamalar: list) -> list:
    """Beş boyutun puanını (%) verir: ortalama / 5 × 100 (ortalamalar 1–5)."""
    if len(ortalamalar) != 5:
        raise GecersizGirdi("beş boyut ortalaması gerekir")
    for o in ortalamalar:
        if not (1 <= o <= 5):
            raise GecersizGirdi("boyut ortalaması 1 ile 5 arasında olmalı")
    return [100 * o / 5 for o in ortalamalar]


def zayif_boyut(ortalamalar: list) -> tuple:
    """En düşük puanlı boyut (ad, ortalama). Eşitlikte ilki seçilir."""
    boyut_puani(ortalamalar)
    i = min(range(5), key=lambda k: ortalamalar[k])
    return BOYUTLAR[i][0], ortalamalar[i]


# ---------------------------------------------------------------------------
# 2) Yanıt ve bölge raporlaması (madde 4.3.2, 4.4, Tablo 2)
# ---------------------------------------------------------------------------

def yanit_orani(yanit: float, davet: float) -> float:
    """Anket yanıt oranı (%). Şartname, taraflılığı azaltmak için yüksek katılım ister (4.4)."""
    return _oran(yanit, davet, "yanıt")


def hata_payi(yanit: float, davet: float) -> float:
    """Bir yüzde tahmininde en kötü durum hata payı (± puan, %95 güven).

    1,96 × √(0,25 / n × (N − n) / (N − 1)) × 100; sonlu kitle düzeltmesiyle.
    Şartname bu hesabı vermez; türetilmiştir ve yanıtların rastgele
    dağıldığını varsayar.
    """
    if davet <= 1 or yanit < 1 or yanit > davet:
        raise GecersizGirdi("davet 1'den büyük, yanıt 1 ile davet arasında olmalı")
    return 196 * math.sqrt(0.25 / yanit * (davet - yanit) / (davet - 1))


def bolge_endeksi(endeksler: list) -> float:
    """Bölge endekslerinin basit ortalaması (Tablo 2'deki "ortalama bağlılık endeksi")."""
    if not endeksler:
        raise GecersizGirdi("en az bir endeks gerekir")
    for e in endeksler:
        if not (0 <= e <= 100):
            raise GecersizGirdi("endeks 0 ile 100 arasında olmalı")
    return sum(endeksler) / len(endeksler)


def agirlikli_bolge_endeksi(endeksler: list, calisanlar: list) -> float:
    """Çalışan sayısıyla ağırlıklı bölge endeksi ortalaması (türetilmiş)."""
    if len(endeksler) != len(calisanlar) or min(calisanlar) < 0 or sum(calisanlar) <= 0:
        raise GecersizGirdi("çalışan sayıları geçersiz")
    return sum(e * c for e, c in zip(endeksler, calisanlar)) / sum(calisanlar)


# ---------------------------------------------------------------------------
# 3) Tutma (madde 5)
# ---------------------------------------------------------------------------

def tutma_orani(baslangic: float, ayrilan: float) -> float:
    """Tutma oranı (%) = (dönem başı çalışan − aynı gruptan ayrılan) / dönem başı × 100.

    Şartname, tutma oranını "istikrar endeksi" olarak anar ve ayrıntılı
    formülünü ISO/TS 30421'e bırakır; bu tanım basitleştirilmiştir.
    """
    return 100 - _oran(ayrilan, baslangic, "ayrılan")


def erken_kayip_payi(deneme: float, ilk_iki_yil: float, toplam: float) -> float:
    """Kayıpların deneme/eğitim dönemi ve ilk iki yıldaki payı (%).

    Şartname (5.3.3): deneme ya da eğitim döneminde kayıp olası bir işe alım
    sorununa; deneme sonrası ama bir ila iki yıl içindeki kayıp, beyan edilen
    kültürün yaşanmadığına işaret edebilir.
    """
    return _oran(deneme + ilk_iki_yil, toplam, "erken kayıp")


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar: anket tablosu
# ---------------------------------------------------------------------------

@dataclass
class AnketTablosu:
    """Her ifade için beş seçeneğin yanıt sayıları (SD, D, N, A, SA)."""
    sayilar: list = field(default_factory=list)

    def ekle(self, sayilar) -> "AnketTablosu":
        self.sayilar.append(list(sayilar))
        return self

    @property
    def ortalamalar(self) -> list:
        return [madde_ortalamasi(*s) for s in self.sayilar]

    def ozet(self) -> dict:
        ort = self.ortalamalar
        toplam_puan = sum((i + 1) * c for s in self.sayilar for i, c in enumerate(s))
        yanit = sum(sum(s) for s in self.sayilar)
        boyutlar = []
        for ad, ilk, son in BOYUTLAR:
            dilim = ort[ilk - 1:son]
            boyutlar.append((ad, round(sum(dilim) / len(dilim), 2)))
        en_dusuk = sorted(range(len(ort)), key=lambda i: ort[i])[:3]
        return {
            "madde_sayisi": len(ort),
            "genel_endeks": round(100 * toplam_puan / (5 * yanit), 1),
            "olumlu_orani": round(100 * sum(s[3] + s[4] for s in self.sayilar) / yanit, 1),
            "boyutlar": boyutlar,
            "en_zayif_boyut": min(boyutlar, key=lambda b: b[1]),
            "en_dusuk_uc_madde": [(i + 1, round(ort[i], 2)) for i in en_dusuk],
        }


ORNEK_SAYILAR = [
    [0, 6, 44, 93, 57],
    [1, 10, 55, 91, 43],
    [1, 19, 72, 81, 27],
    [3, 32, 84, 66, 15],
    [1, 12, 61, 89, 37],
    [1, 10, 55, 91, 43],
    [8, 48, 89, 48, 7],
    [4, 37, 87, 60, 12],
    [1, 15, 67, 85, 32],
    [0, 8, 50, 92, 50],
    [4, 37, 87, 60, 12],
    [1, 12, 61, 89, 37],
    [2, 22, 77, 77, 22],
    [1, 19, 72, 81, 27],
    [15, 66, 84, 32, 3],
    [0, 8, 50, 92, 50],
    [0, 6, 44, 93, 57],
    [1, 15, 67, 85, 32],
    [3, 27, 81, 71, 18],
    [1, 10, 55, 91, 43],
    [6, 42, 88, 54, 10],
    [1, 12, 61, 89, 37],
    [3, 32, 84, 66, 15],
    [10, 54, 88, 42, 6],
    [1, 15, 67, 85, 32]
]


def ornek_tablo() -> AnketTablosu:
    """25 ifadelik, 200 yanıtlı örnek anket (uydurma veri)."""
    t = AnketTablosu()
    for s in ORNEK_SAYILAR:
        t.ekle(s)
    return t


def kultur_denetimi(amac_ifadesi: bool = False,
                    deger_ifadesi: bool = False,
                    olgunluk_belirlendi: bool = False,
                    anonimlik_guvencesi: bool = False,
                    yuksek_katilim: bool = False,
                    kirilimlar_tanimli: bool = False,
                    sonuclar_tartisildi: bool = False,
                    tutma_kok_neden: bool = False) -> list:
    """Bir kültür ölçüm sisteminin, şartnamenin beklentilerine göre eksiklerini sıralar.

    Maddeler ISO/TS 24178'in giriş, 4.3, 4.4, 5.3 ve Ek A bölümlerinden
    türetilmiştir; bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (amac_ifadesi, "Kurumun net bir amaç (misyon/vizyon) ifadesi yok: amaç soruları çalışanın gerçekliğini ölçemez (4.3.1)."),
        (deger_ifadesi, "Davranışı yönlendiren değerler yazılı ve duyurulmuş değil: değer sorularının dayanağı yok (4.3.1)."),
        (olgunluk_belirlendi, "Kültürel olgunluk aşaması (1–4) belirlenmemiş; soruların derinliği buna göre seçilmeli (Tablo 1)."),
        (anonimlik_guvencesi, "Kullanılan aracın çalışanların anonimliğini güvence altına aldığı belgelenmemiş (4.3.2)."),
        (yuksek_katilim, "Dengeli ve en az taraflı sonuç için yüksek katılım oranı hedeflenmiyor (4.4)."),
        (kirilimlar_tanimli, "Kırılımlar (bölüm, konum, işgücü kategorisi, düzey, işlev, kıdem) tanımlanmamış (Giriş)."),
        (sonuclar_tartisildi, "Sonuçlar odak grup ve toplantılarla çalışanlarla tartışılıp kök nedene inilmiyor (A.2.4)."),
        (tutma_kok_neden, "Tutma oranı kırılımları ve kayıp nedenleri (deneme dönemi, kıdem, gerekçeli fesih) çözümlenmiyor (5.3)."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "kultur_endeksi", "madde_puani", "boyut", "katilim", "bolge_endeks",
    "tutma_orani", "kayip_nedeni",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "kultur_endeksi":
        d = kultur_endeksi(g["toplam_puan"], g["yanitci"], g["madde_sayisi"])
        ort = g["toplam_puan"] / (g["madde_sayisi"] * g["yanitci"])
        return {"deger": d, "ondalik": 1, "birim": "% kültür endeksi",
                "ifade": f"{_g(g['toplam_puan'])} ÷ (5 × {_g(g['madde_sayisi'])} × {_g(g['yanitci'])}) × 100",
                "ayrinti": [["Madde başına ortalama puan (1–5)", round(ort, 2)],
                            ["Azami puan", 5 * g["madde_sayisi"] * g["yanitci"]],
                            ["Tarafsız düzeye (3 puan) göre fark (puan)", round(ort - 3, 2)]]}

    if metrik == "madde_puani":
        sayilar = (g["kes_katilmiyor"], g["katilmiyor"], g["kararsiz"], g["katiliyor"], g["kes_katiliyor"])
        d = madde_ortalamasi(*sayilar)
        n = sum(sayilar)
        return {"deger": d, "ondalik": 2, "birim": "puan (1–5)",
                "ifade": "(" + " + ".join(f"{i + 1}×{_g(s)}" for i, s in enumerate(sayilar)) + f") ÷ {_g(n)}",
                "ayrinti": [["Yanıtlayan", n],
                            ["Olumlu yanıt oranı (%)", round(olumlu_orani(g["katiliyor"], g["kes_katiliyor"], n), 1)],
                            ["Olumsuz yanıt oranı (%)", round(100 * (g["kes_katilmiyor"] + g["katilmiyor"]) / n, 1)],
                            ["Ölçek yüzdesi (%)", round(100 * d / 5, 1)]]}

    if metrik == "boyut":
        ort = [g["amac_var"], g["deger_var"], g["amac_gerceklik"], g["deger_davranis"], g["liderlik"]]
        ad, d = zayif_boyut(ort)
        return {"deger": 100 * d / 5, "ondalik": 1, "birim": "% (en zayıf boyut)",
                "ifade": "min(" + ", ".join(_g(x) for x in ort) + ") ÷ 5 × 100",
                "ayrinti": [["En zayıf boyut", ad],
                            ["Beş boyutun ortalaması (%)", round(100 * sum(ort) / 25, 1)],
                            ["En güçlü ile en zayıf arasındaki fark (puan, 1–5)", round(max(ort) - d, 2)]]}

    if metrik == "katilim":
        d = yanit_orani(g["yanit"], g["davet"])
        return {"deger": d, "ondalik": 1, "birim": "% yanıt oranı",
                "ifade": f"({_g(g['yanit'])} ÷ {_g(g['davet'])}) × 100",
                "ayrinti": [["Yanıtlamayan", g["davet"] - g["yanit"]],
                            ["Yanıtlamayanların payı (%)", round(100 - d, 1)],
                            ["Oran tahmininde en kötü durum hata payı (± puan, %95 güven)",
                             round(hata_payi(g["yanit"], g["davet"]), 1)]]}

    if metrik == "bolge_endeks":
        e = [g["endeks_1"], g["endeks_2"], g["endeks_3"]]
        c = [g["calisan_1"], g["calisan_2"], g["calisan_3"]]
        d = bolge_endeksi(e)
        if min(c) < 0 or sum(c) <= 0:
            raise GecersizGirdi("çalışan sayıları geçersiz")
        w = sum(x * y for x, y in zip(e, c)) / sum(c)
        return {"deger": d, "ondalik": 1, "birim": "endeks (0–100, basit ortalama)",
                "ifade": "(" + " + ".join(_g(x) for x in e) + ") ÷ 3",
                "ayrinti": [["Çalışan sayısıyla ağırlıklı ortalama", round(w, 1)],
                            ["En yüksek ile en düşük bölge farkı (puan)", round(max(e) - min(e), 1)],
                            ["Ağırlıklı ile basit ortalama farkı (puan)", round(w - d, 1)]]}

    if metrik == "tutma_orani":
        d = tutma_orani(g["baslangic"], g["ayrilan"])
        return {"deger": d, "ondalik": 1, "birim": "% tutma oranı",
                "ifade": f"(({_g(g['baslangic'])} − {_g(g['ayrilan'])}) ÷ {_g(g['baslangic'])}) × 100",
                "ayrinti": [["Dönem sonunda kalan", g["baslangic"] - g["ayrilan"]],
                            ["Ayrılış oranı (%)", round(100 - d, 1)]]}

    if metrik == "kayip_nedeni":
        kalemler = [g["deneme"], g["ilk_iki_yil"], g["gerekceli_fesih"], g["diger_gonullu"], g["emeklilik"]]
        if min(kalemler) < 0:
            raise GecersizGirdi("kayıp kalemleri negatif olamaz")
        t = sum(kalemler)
        d = erken_kayip_payi(g["deneme"], g["ilk_iki_yil"], t)
        return {"deger": d, "ondalik": 1, "birim": "% erken kayıp",
                "ifade": f"(({_g(g['deneme'])} + {_g(g['ilk_iki_yil'])}) ÷ {_g(t)}) × 100",
                "ayrinti": [["Toplam kayıp", t],
                            ["Deneme ve eğitim dönemi payı (%)", round(100 * g["deneme"] / t, 1)],
                            ["İlk iki yıl payı (%)", round(100 * g["ilk_iki_yil"] / t, 1)],
                            ["Emeklilik payı (%)", round(100 * g["emeklilik"] / t, 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 24178 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    ort = t.ortalamalar
    print("25 ifadelik temel kültür anketi (200 yanıt; uydurma örnek veri)")
    print(f"{'No':<4}{'İfade':<54}{'Ort.':>6}")
    for i, (m, o) in enumerate(zip(MADDELER, ort), 1):
        print(f"{i:<4}{m[:52]:<54}{o:>6.2f}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<20}: {deger}")
    print(cizgi)

    print(f"Yanıt oranı              : {yanit_orani(200, 240):.1f} %"
          f" (± {hata_payi(200, 240):.1f} puan)")
    print(f"Bölge endeksi (Tablo 2)  : {bolge_endeksi([84, 86, 81]):.1f}"
          f" (ağırlıklı {sum(x*y for x, y in zip([84,86,81],[300,500,400]))/1200:.1f})")
    print(f"Tutma oranı              : {tutma_orani(500, 62):.1f} %")
    print(f"Erken kayıp payı         : {erken_kayip_payi(9, 21, 62):.1f} %")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("kultur_endeksi", toplam_puan=18000, yanitci=200, madde_sayisi=25))
    print(cizgi)

    print("Ölçüm sistemi denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in kultur_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
