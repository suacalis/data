#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso24179_metrikler.py
=====================
ISO/TS 24179:2020 (Human resource management — Occupational health and safety
metrics) çerçevesindeki iş sağlığı ve güvenliği (İSG) metriklerinin Python
karşılığı.

Standart, ISO 30414'ün "kurumsal sağlık, güvenlik ve iyi olma hâli" kümesini
ayrıntılandırır ve dört metrik tanımlar. Dördü de aynı biçimi kullanır:

    A = B / C × 100

Değişen yalnızca B ile C'nin ne olduğudur:

    1) Kayıp zaman   — B: kayıp çalışma süresi,  C: planlanan çalışma süresi
    2) Kaza sayısı   — B: iş kazası sayısı,      C: ortalama kadro
    3) Ölüm sayısı   — B: ölümlü kaza sayısı,    C: ortalama kadro
    4) Eğitim oranı  — B: eğitim katılımcısı,    C: ortalama kadro

Modül ayrıca standardın "önleyici programların başarısını göstermek" başlığı
altında andığı kazasız süre göstergesini ve İSG uygulamasında yaygın olan
sıklık/ağırlık oranlarını türetilmiş metrik olarak içerir.

Kullanım:
    from iso24179_metrikler import kaza_yuzdesi, siklik_orani
    kaza_yuzdesi(50, 1200)          ->  4.166...
    siklik_orani(50, 998_400)       -> 50.08

Doğrudan çalıştırıldığında (python3 iso24179_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 24179:2020'ye dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif
korumalıdır. Türetilmiş metrikler ayrıca işaretlenmiştir.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

__all__ = [
    # standardın dört metriği
    "yuzde", "kayip_zaman_yuzdesi", "kaza_yuzdesi", "olum_yuzdesi",
    "egitim_yuzdesi",
    # önleme ve türetilmiş göstergeler
    "kazasiz_saat", "siklik_orani", "agirlik_orani", "yuz_bin_basina",
    "kaza_maliyeti", "donem_degisimi",
    # yardımcı
    "Donem", "IsgTablosu", "ornek_tablo", "metrik_denetimi", "hesapla",
    "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Standardın ortak formülü
# ---------------------------------------------------------------------------

def yuzde(b: float, c: float) -> float:
    """Standardın dört metriğinde de kullanılan ortak biçim: A = B / C × 100."""
    return 100 * b / c


def kayip_zaman_yuzdesi(kayip_saat: float, planlanan_saat: float) -> float:
    """İşle ilgili yaralanma, kaza ve hastalık nedeniyle kaybedilen çalışma süresi (%).

    Kayıp zaman, ölüm, kalıcı iş göremezlik ya da bir gün veya vardiya ve
    üzerinde iş kaybıyla sonuçlanan olayları kapsar. Çalışma süresi saat ya da
    gün olarak ifade edilebilir; iki taraf da aynı birimde olmalıdır.
    """
    return yuzde(kayip_saat, planlanan_saat)


def kaza_yuzdesi(kaza_sayisi: float, ortalama_kadro: float) -> float:
    """İş kazasına uğrayan işgücünün payı (%). Payda ortalama kadrodur."""
    return yuzde(kaza_sayisi, ortalama_kadro)


def olum_yuzdesi(olum_sayisi: float, ortalama_kadro: float) -> float:
    """İş kazası sonucu ölen işgücünün payı (%).

    Standart, bu metriğin yüzdenin yanı sıra mutlak kişi sayısıyla da
    verilmesini ister: yalnızca yüzde raporlamak, sayının etkisine karşı
    duyarsızlaştırır.
    """
    return yuzde(olum_sayisi, ortalama_kadro)


def egitim_yuzdesi(katilimci: float, ortalama_kadro: float) -> float:
    """İSG eğitimine katılan çalışanların payı (%)."""
    return yuzde(katilimci, ortalama_kadro)


# ---------------------------------------------------------------------------
# 2) Önleme ve türetilmiş göstergeler
# ---------------------------------------------------------------------------

def kazasiz_saat(gun: float, gunluk_calisan_saat: float) -> float:
    """Son olaydan bu yana çalışılan toplam saat.

    Standart, önleyici programların başarısını göstermek için son yaralanma,
    kaza ya da hastalık tespitinden bu yana çalışılan saat sayısının
    kullanılabileceğini belirtir.
    """
    return gun * gunluk_calisan_saat


def siklik_orani(olay: float, calisilan_saat: float,
                 taban: float = 1_000_000) -> float:
    """Sıklık oranı (türetilmiş): taban çalışma saati başına olay sayısı.

    Standardın parçası değildir; İSG uygulamasında yaygındır. Taban olarak
    1.000.000 saat (LTIFR) ya da 200.000 saat kullanılır. Payda kadro değil
    fiilen çalışılan saat olduğu için, kadro büyüklüğünden ve çalışma
    süresinden bağımsız karşılaştırmaya izin verir.
    """
    return taban * olay / calisilan_saat


def agirlik_orani(kayip_gun: float, calisilan_saat: float,
                  taban: float = 1000) -> float:
    """Ağırlık oranı (türetilmiş): taban çalışma saati başına kayıp gün.

    Sıklık oranı olayın kaç kez olduğunu, ağırlık oranı ne kadar ağır
    olduğunu gösterir. İkisi birlikte okunur: az sayıda ama ağır olay ile
    çok sayıda hafif olay aynı sıklık oranını verebilir.
    """
    return taban * kayip_gun / calisilan_saat


def yuz_bin_basina(olay: float, kadro: float) -> float:
    """Yüz bin çalışan başına olay (türetilmiş).

    Ölümlü kaza gibi seyrek olaylarda yüzde çok küçük çıkar ve okunamaz;
    ulusal ve uluslararası istatistikler bu nedenle yüz bin çalışan tabanını
    kullanır.
    """
    return 100_000 * olay / kadro


def kaza_maliyeti(verimlilik_kaybi: float, kaybedilen_is: float,
                  yedekleme: float, calisana_odeme: float,
                  onarim: float, sigorta: float, hukuki: float) -> float:
    """İş kazasının kuruma maliyeti.

    Kalemler standardın kazaların izlenme gerekçesi olarak saydığı olumsuz
    etkilerden alınmıştır: verimlilik kaybı, kaçan iş fırsatı, yerine
    çalışanın ücreti ya da fazla mesai, çalışana yapılan geri ödemeler,
    onarım–kiralama–yenileme giderleri, sigorta priminde değişim ve hukuki
    giderler.
    """
    return (verimlilik_kaybi + kaybedilen_is + yedekleme + calisana_odeme
            + onarim + sigorta + hukuki)


def donem_degisimi(cari: float, onceki: float) -> float:
    """Önceki döneme göre değişim (%). Negatif değer iyileşmedir."""
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 3) Yardımcı yapılar
# ---------------------------------------------------------------------------

@dataclass
class Donem:
    """Bir ölçüm döneminin İSG verisi."""
    ad: str
    yaralanma_saat: float = 0.0
    kaza_saat: float = 0.0
    hastalik_saat: float = 0.0
    kaza_sayisi: float = 0.0
    olum_sayisi: float = 0.0
    egitim_katilimci: float = 0.0
    ortalama_kadro: float = 0.0
    planlanan_saat: float = 0.0

    @property
    def toplam_kayip_saat(self) -> float:
        return self.yaralanma_saat + self.kaza_saat + self.hastalik_saat

    @property
    def kayip_zaman_yuzde(self) -> float:
        return kayip_zaman_yuzdesi(self.toplam_kayip_saat, self.planlanan_saat)

    @property
    def kaza_yuzde(self) -> float:
        return kaza_yuzdesi(self.kaza_sayisi, self.ortalama_kadro)

    @property
    def olum_yuzde(self) -> float:
        return olum_yuzdesi(self.olum_sayisi, self.ortalama_kadro)

    @property
    def egitim_yuzde(self) -> float:
        return egitim_yuzdesi(self.egitim_katilimci, self.ortalama_kadro)

    def ozet(self) -> dict:
        return {
            "toplam_kayip_saat": round(self.toplam_kayip_saat, 1),
            "kayip_zaman_yuzde": round(self.kayip_zaman_yuzde, 4),
            "kaza_yuzde": round(self.kaza_yuzde, 2),
            "olum_yuzde": round(self.olum_yuzde, 3),
            "olum_yuz_bin": round(yuz_bin_basina(self.olum_sayisi,
                                                 self.ortalama_kadro), 1),
            "egitim_yuzde": round(self.egitim_yuzde, 1),
            "siklik_orani": round(siklik_orani(self.kaza_sayisi,
                                               self.planlanan_saat), 2),
        }


@dataclass
class IsgTablosu:
    """Cari dönem ve karşılaştırma dönemlerinden oluşan tablo."""
    donemler: list = field(default_factory=list)

    def ekle(self, donem: Donem) -> "IsgTablosu":
        self.donemler.append(donem)
        return self

    def egilim(self, alan: str) -> list:
        """Bir alanın dönemler boyunca aldığı değerler (cari dönem başta)."""
        return [getattr(d, alan) for d in self.donemler]

    def karsilastirma(self) -> dict:
        """Cari dönemin bir önceki dönemle karşılaştırması (% değişim)."""
        if len(self.donemler) < 2:
            return {}
        c, o = self.donemler[0], self.donemler[1]
        return {
            "kayip_saat_degisim": round(
                donem_degisimi(c.toplam_kayip_saat, o.toplam_kayip_saat), 1),
            "kaza_degisim": round(
                donem_degisimi(c.kaza_sayisi, o.kaza_sayisi), 1),
            "olum_degisim": round(
                donem_degisimi(c.olum_sayisi, o.olum_sayisi), 1),
            "egitim_degisim": round(
                donem_degisimi(c.egitim_yuzde, o.egitim_yuzde), 1),
        }


def ornek_tablo() -> IsgTablosu:
    """Cari altı ay ve üç karşılaştırma dönemi.

    Kayıp saat, kaza ve ölüm satırları standardın örnek tablolarındaki
    değerlerdir; kadro, planlanan saat ve eğitim satırları tutarlı bir örnek
    kurmak için eklenmiştir (standart bu paydaları vermez).
    """
    t = IsgTablosu()
    veri = [
        ("Cari 6 ay", 90, 87, 100, 50, 5, 1040, 1200, 998400),
        ("Bir yıl önce", 85, 87, 90, 60, 7, 980, 1180, 981760),
        ("İki yıl önce", 85, 80, 85, 55, 10, 900, 1150, 956800),
        ("Üç yıl önce", 80, 70, 80, 85, 7, 850, 1200, 998400),
    ]
    for ad, yar, kaz, has, ks, os_, eg, kadro, saat in veri:
        t.ekle(Donem(ad, yar, kaz, has, ks, os_, eg, kadro, saat))
    return t


def metrik_denetimi(kadro_kategorileri_tanimli: bool = False,
                    kayit_sureci_var: bool = False,
                    kirilim_var: bool = False,
                    olum_mutlak_sayi: bool = False,
                    egitim_zamanlamasi_izleniyor: bool = False,
                    onceki_donem_var: bool = False) -> list:
    """Bir İSG raporunun eksiklerini listeler.

    Standardın mantığı: dört metrik toplulaştırılmış hâlde asgari düzeydir;
    kırılım olmadan kök nedene inilemez ve müdahale tasarlanamaz.
    """
    uyarilar = []
    if not kadro_kategorileri_tanimli:
        uyarilar.append("İşgücü kategorileri (kadrolu, geçici, yüklenici, dış "
                        "kaynak) tanımlı değil: metrik kimin kapsandığını "
                        "söylemiyor.")
    if not kayit_sureci_var:
        uyarilar.append("Tüm İSG olaylarını kaydeden bir süreç ve prosedür yok: "
                        "sayılar eksik toplanır, iyileşme yanılsaması doğar.")
    if not kirilim_var:
        uyarilar.append("Kırılım yok (birim, konum, ürün hattı, işlev, olay "
                        "türü, çalışan kategorisi, günün saati, olay anındaki "
                        "eğitim durumu): kök nedene inilemez.")
    if not olum_mutlak_sayi:
        uyarilar.append("Ölümlü kaza yalnızca yüzdeyle veriliyor: mutlak kişi "
                        "sayısı olmadan rakam duyarsızlaştırır.")
    if not egitim_zamanlamasi_izleniyor:
        uyarilar.append("Eğitimin zamanlaması izlenmiyor: yeni başlayanların ve "
                        "tazeleme eğitimlerinin belgelenmiş süre içinde "
                        "tamamlanıp tamamlanmadığı bilinmiyor.")
    if not onceki_donem_var:
        uyarilar.append("Önceki dönem ve yıl karşılaştırması yok: standardın "
                        "önerdiği karşılaştırma aralığı üç ilâ beş yıldır.")
    return uyarilar


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "kayip_zaman", "kayip_zaman_dagilim", "kaza_orani", "olum_orani",
    "egitim_orani", "egitim_zamanlilik", "kazasiz_sure", "siklik_orani",
    "agirlik_orani", "kaza_maliyeti", "donem_karsilastirma",
]


def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "kayip_zaman":
        d = kayip_zaman_yuzdesi(g["kayip_saat"], g["planlanan_saat"])
        return {"deger": d, "ondalik": 3, "birim": "% kayıp zaman",
                "ifade": f"({g['kayip_saat']:g} ÷ {g['planlanan_saat']:g}) × 100",
                "ayrinti": [["Kayıp gün karşılığı (8 saat)",
                             round(g["kayip_saat"] / 8, 1)],
                            ["Çalışan başına kayıp saat",
                             round(g["kayip_saat"] / g["ortalama_kadro"], 2)],
                            ["100 çalışan başına kayıp gün",
                             round(100 * g["kayip_saat"] / 8 / g["ortalama_kadro"], 1)]]}

    if metrik == "kayip_zaman_dagilim":
        t = g["yaralanma"] + g["kaza"] + g["hastalik"]
        return {"deger": t, "ondalik": 0, "birim": "saat",
                "ifade": f"{g['yaralanma']:g} + {g['kaza']:g} + {g['hastalik']:g}",
                "ayrinti": [["Yaralanmanın payı (%)", round(100 * g["yaralanma"] / t, 1)],
                            ["Kazanın payı (%)", round(100 * g["kaza"] / t, 1)],
                            ["Hastalığın payı (%)", round(100 * g["hastalik"] / t, 1)],
                            ["Planlanan süreye oranı (%)",
                             round(kayip_zaman_yuzdesi(t, g["planlanan_saat"]), 3)]]}

    if metrik == "kaza_orani":
        d = kaza_yuzdesi(g["kaza_sayisi"], g["ortalama_kadro"])
        return {"deger": d, "ondalik": 2, "birim": "% işgücü",
                "ifade": f"({g['kaza_sayisi']:g} ÷ {g['ortalama_kadro']:g}) × 100",
                "ayrinti": [["100 çalışan başına kaza", round(d, 2)],
                            ["Kaza başına ortalama kayıp saat",
                             round(g["kayip_saat"] / g["kaza_sayisi"], 1)],
                            ["Sıklık oranı (1.000.000 saat)",
                             round(siklik_orani(g["kaza_sayisi"], g["calisilan_saat"]), 2)]]}

    if metrik == "olum_orani":
        d = olum_yuzdesi(g["olum_sayisi"], g["ortalama_kadro"])
        return {"deger": d, "ondalik": 3, "birim": "% işgücü",
                "ifade": f"({g['olum_sayisi']:g} ÷ {g['ortalama_kadro']:g}) × 100",
                "ayrinti": [["Ölen kişi sayısı (mutlak)", g["olum_sayisi"]],
                            ["100.000 çalışan başına",
                             round(yuz_bin_basina(g["olum_sayisi"], g["ortalama_kadro"]), 1)],
                            ["Ölümlü kazanın tüm kazalara oranı (%)",
                             round(100 * g["olum_sayisi"] / g["kaza_sayisi"], 1)]]}

    if metrik == "egitim_orani":
        d = egitim_yuzdesi(g["katilimci"], g["ortalama_kadro"])
        return {"deger": d, "ondalik": 1, "birim": "% çalışan",
                "ifade": f"({g['katilimci']:g} ÷ {g['ortalama_kadro']:g}) × 100",
                "ayrinti": [["Eğitim almamış çalışan",
                             round(g["ortalama_kadro"] - g["katilimci"])],
                            ["Eğitim almamışların payı (%)", round(100 - d, 1)],
                            ["Kişi başına eğitim saati",
                             round(g["toplam_egitim_saati"] / g["ortalama_kadro"], 2)]]}

    if metrik == "egitim_zamanlilik":
        d = yuzde(g["zamaninda"], g["yeni_calisan"])
        return {"deger": d, "ondalik": 1, "birim": "% zamanında",
                "ifade": f"({g['zamaninda']:g} ÷ {g['yeni_calisan']:g}) × 100",
                "ayrinti": [["Süreyi aşan yeni çalışan",
                             g["yeni_calisan"] - g["zamaninda"]],
                            ["Ortalama gecikme (gün)", g["ortalama_gecikme"]],
                            ["Belgelenmiş süre (gün)", g["hedef_gun"]]]}

    if metrik == "kazasiz_sure":
        saat = kazasiz_saat(g["gun"], g["gunluk_calisan_saat"])
        return {"deger": saat, "ondalik": 0, "birim": "çalışma saati",
                "ifade": f"{g['gun']:g} × {g['gunluk_calisan_saat']:g}",
                "ayrinti": [["Kazasız gün", g["gun"]],
                            ["Hafta karşılığı", round(g["gun"] / 7, 1)],
                            ["Önceki en iyi süreye fark (gün)",
                             g["gun"] - g["onceki_rekor"]]]}

    if metrik == "siklik_orani":
        d = siklik_orani(g["olay"], g["calisilan_saat"])
        return {"deger": d, "ondalik": 2, "birim": "olay / 1.000.000 saat",
                "ifade": f"(1.000.000 × {g['olay']:g}) ÷ {g['calisilan_saat']:g}",
                "ayrinti": [["200.000 saat tabanıyla",
                             round(siklik_orani(g["olay"], g["calisilan_saat"], 200_000), 2)],
                            ["Kadro başına oran (%)",
                             round(kaza_yuzdesi(g["olay"], g["ortalama_kadro"]), 2)],
                            ["Çalışan başına yıllık saat",
                             round(g["calisilan_saat"] / g["ortalama_kadro"])]]}

    if metrik == "agirlik_orani":
        d = agirlik_orani(g["kayip_gun"], g["calisilan_saat"])
        return {"deger": d, "ondalik": 3, "birim": "kayıp gün / 1.000 saat",
                "ifade": f"(1.000 × {g['kayip_gun']:g}) ÷ {g['calisilan_saat']:g}",
                "ayrinti": [["Toplam kayıp gün", g["kayip_gun"]],
                            ["Olay başına ortalama kayıp gün",
                             round(g["kayip_gun"] / g["olay"], 1)],
                            ["Sıklık oranı (1.000.000 saat)",
                             round(siklik_orani(g["olay"], g["calisilan_saat"]), 2)]]}

    if metrik == "kaza_maliyeti":
        t = kaza_maliyeti(g["verimlilik_kaybi"], g["kaybedilen_is"],
                          g["yedekleme"], g["calisana_odeme"], g["onarim"],
                          g["sigorta"], g["hukuki"])
        return {"deger": t, "ondalik": 0, "birim": "TL",
                "ifade": (f"{g['verimlilik_kaybi']:g} + {g['kaybedilen_is']:g} + "
                          f"{g['yedekleme']:g} + {g['calisana_odeme']:g} + "
                          f"{g['onarim']:g} + {g['sigorta']:g} + {g['hukuki']:g}"),
                "ayrinti": [["Olay başına maliyet (TL)", round(t / g["olay"])],
                            ["Doğrudan ödemelerin payı (%)",
                             round(100 * (g["calisana_odeme"] + g["onarim"]
                                          + g["hukuki"]) / t, 1)],
                            ["Verimlilik ve iş kaybının payı (%)",
                             round(100 * (g["verimlilik_kaybi"]
                                          + g["kaybedilen_is"]) / t, 1)]]}

    if metrik == "donem_karsilastirma":
        d = donem_degisimi(g["cari"], g["onceki"])
        uc = (g["onceki"] + g["iki_yil"] + g["uc_yil"]) / 3
        return {"deger": d, "ondalik": 1, "birim": "% değişim",
                "ifade": f"(({g['cari']:g} − {g['onceki']:g}) ÷ {g['onceki']:g}) × 100",
                "ayrinti": [["Üç dönemlik ortalama", round(uc, 1)],
                            ["Cari dönemin ortalamadan farkı (%)",
                             round(donem_degisimi(g["cari"], uc), 1)],
                            ["Üç yıl öncesine göre değişim (%)",
                             round(donem_degisimi(g["cari"], g["uc_yil"]), 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 70
    print("ISO/TS 24179 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Altı aylık analiz ve karşılaştırma")
    print(f"{'Dönem':<15}{'Kayıp saat':>11}{'Kayıp %':>9}{'Kaza':>6}"
          f"{'Kaza %':>8}{'Ölüm':>6}{'Eğitim %':>10}")
    for d in t.donemler:
        print(f"{d.ad:<15}{d.toplam_kayip_saat:>11.0f}{d.kayip_zaman_yuzde:>9.3f}"
              f"{d.kaza_sayisi:>6.0f}{d.kaza_yuzde:>8.2f}{d.olum_sayisi:>6.0f}"
              f"{d.egitim_yuzde:>10.1f}")
    print(cizgi)

    print("Cari dönem özeti")
    for k, v in t.donemler[0].ozet().items():
        print(f"  {k:<20}: {v}")
    print("Önceki döneme göre değişim (%)")
    for k, v in t.karsilastirma().items():
        print(f"  {k:<20}: {v:+}")
    print(cizgi)

    print(f"Sıklık oranı (1.000.000 saat) : {siklik_orani(50, 998_400):.2f}")
    print(f"  200.000 saat tabanıyla      : {siklik_orani(50, 998_400, 200_000):.2f}")
    print(f"Ağırlık oranı (1.000 saat)    : {agirlik_orani(35, 998_400):.3f}")
    print(f"100.000 çalışan başına ölüm   : {yuz_bin_basina(5, 1200):.1f}")
    print(f"Kazasız sürede çalışılan saat : {_tl(kazasiz_saat(128, 9600))}")
    maliyet = kaza_maliyeti(180_000, 250_000, 120_000, 60_000, 90_000, 45_000, 75_000)
    print(f"Bir kazanın maliyeti          : {_tl(maliyet)} TL")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("kaza_orani", kaza_sayisi=50, ortalama_kadro=1200,
                  kayip_saat=87, calisilan_saat=998_400))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
