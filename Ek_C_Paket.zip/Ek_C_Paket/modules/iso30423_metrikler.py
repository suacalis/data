#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30423_metrikler.py
=====================
ISO/TS 30423:2021 (Human resource management — Compliance and ethics metrics
cluster) çerçevesindeki uyum ve etik metriklerinin Python karşılığı.

Standart, ISO 30414'ün "uyum ve etik" kümesini beş metrik üzerinden tanımlar.
Kümenin ayırt edici yanı, metriklerin çoğunun oran değil sayım olmasıdır ve
üç ayrı hesap mantığı kullanılır. Modül dört bölüme ayrılmıştır:

    1) Birikim  — yıl başından itibaren kümülatif toplam (şikâyetler, dış
       taraflara havale edilen uyuşmazlıklar)
    2) Hareket  — açılış bakiyesi + eklenen − kapanış bakiyesi (sonuçlandırılan
       disiplin işlemleri; dış taraflarca sonuçlandırılan uyuşmazlıklar)
    3) Oran     — uyum ve etik eğitimini tamamlayan çalışan oranı
    4) Türetilmiş — TZE'ye oranlama, iç çözüm payı, kategori payı, eğilim

Kullanım:
    from iso30423_metrikler import kumulatif, sonuclandirilan
    kumulatif([3, 5, 4, 4, 4, 2])        ->  [3, 8, 12, 16, 20, 22]
    sonuclandirilan(25, 10, 10)          ->  25

Doğrudan çalıştırıldığında (python3 iso30423_metrikler.py) standardın örnek
tablolarına karşılık gelen hesaplar yeniden üretilir.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30423:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

__all__ = [
    # birikim
    "kumulatif", "yil_basindan_toplam",
    # hareket
    "sonuclandirilan", "dis_sonuclandirilan", "acik_dosya",
    # oran
    "egitim_tamamlama", "sure_icinde_tamamlama",
    # türetilmiş
    "tze_orani", "ic_cozum_orani", "kategori_payi", "yillik_degisim",
    "hedef_sapmasi", "sikayetsiz_gun",
    # tablo
    "Donem", "UyumTablosu", "ornek_tablo", "metrik_denetimi",
    # dağıtıcı
    "hesapla", "METRIK_LISTESI",
]


def _s(x: float) -> str:
    """Sayıları bilimsel gösterime kaçmadan, Türkçe biçimde yazar."""
    x = float(x)
    if x == int(x):
        return f"{int(x):,}".replace(",", ".")
    t = f"{x:,.2f}".rstrip("0")
    if t.endswith("."):
        t = t[:-1]
    return t.replace(",", "\u00a0").replace(".", ",").replace("\u00a0", ".")


# ---------------------------------------------------------------------------
# 1) Birikim mantığı: yıl başından itibaren kümülatif toplam
# ---------------------------------------------------------------------------

def kumulatif(aylik: Sequence[float]) -> list:
    """Yıl başından itibaren biriken toplam serisi.

    Hesap, mali yıl ve/veya yıllık bütçe döngüsüyle hizalanır. Hesaplama anı,
    her ölçüm döneminin sonunda kayıtlı olan sayıdır (birinci ayın sonu,
    ikinci çeyreğin sonu, yıl sonu toplamları gibi).

    Aynı formül hem tüm kategorilerin toplamına hem de her kategoriye ayrı ayrı
    uygulanır: taciz, ayrımcılık (doğrudan/dolaylı), saldırı (sözlü/fiziksel).
    """
    toplam, seri = 0.0, []
    for deger in aylik:
        toplam += deger
        seri.append(toplam)
    return seri


def yil_basindan_toplam(aylik: Sequence[float]) -> float:
    """Dönem sonundaki yıl başından itibaren toplam."""
    return sum(aylik)


# ---------------------------------------------------------------------------
# 2) Hareket hesabı
# ---------------------------------------------------------------------------

def sonuclandirilan(acilis: float, eklenen: float, kapanis: float) -> float:
    """Sonuçlandırılan disiplin işlemi sayısı.

        Açılış bakiyesi + Dönemde eklenen disiplin dosyası − Kapanış bakiyesi

    Bir dönemde açılan dosyayla sonuçlanan dosya aynı değildir; bu hesap,
    önceki dönemlerden devreden ve bu dönemde kapanan dosyaları da yakalar.
    Ölçüm noktası (örneğin ayın ilk günü) tutarlı biçimde uygulanmalıdır.
    """
    return acilis + eklenen - kapanis


def dis_sonuclandirilan(acilis: float, havale: float, geri_cekilen: float,
                        kapanis: float) -> float:
    """Dış taraflarca sonuçlandırılan uyuşmazlık sayısı.

        Açılış bakiyesi + Dönemde dış taraflara havale edilen
        − Dönemde geri çekilen − Kapanış bakiyesi

    Dış bulgular (denetim dâhil) bu hesapla izlenir; her bulgunun kaynağı,
    içeriği ve doğurduğu eylem ayrıca kaydedilir.
    """
    return acilis + havale - geri_cekilen - kapanis


def acik_dosya(acilis: float, eklenen: float, sonuclanan: float) -> float:
    """Dönem sonunda açık kalan dosya sayısı (kapanış bakiyesi kontrolü)."""
    return acilis + eklenen - sonuclanan


# ---------------------------------------------------------------------------
# 3) Oran mantığı
# ---------------------------------------------------------------------------

def egitim_tamamlama(tamamlayan: float, tamamlamasi_gereken: float) -> float:
    """Uyum ve etik eğitimini tamamlayan çalışan oranı (%).

        (Eğitimi tamamlayan toplam çalışan
         ÷ Eğitimi tamamlaması gereken toplam çalışan) × 100

    "Tamamlama", katılımcının kurumun tatmin edici tamamlama tanımına göre
    eğitimi uygulamada yetkin bulunması demektir; salt katılım yeterli değildir.
    """
    return 100 * tamamlayan / tamamlamasi_gereken


def sure_icinde_tamamlama(sure_icinde: float, tamamlamasi_gereken: float) -> float:
    """Öngörülen süre içinde eğitimi tamamlayan çalışan oranı (%).

    Standart, uyuma ulaşmak ya da onu sürdürmek ve etik eğitimini bitirmek için
    geçen süreye de hedef konmasını ve raporlamanın bu hedefe göre yapılmasını
    ister. Genel tamamlama yüksek olsa da süre içinde tamamlanan pay düşükse
    süreç aksıyor demektir.
    """
    return 100 * sure_icinde / tamamlamasi_gereken


# ---------------------------------------------------------------------------
# 4) Türetilmiş ölçüler
# ---------------------------------------------------------------------------

def tze_orani(vaka: float, tze: float) -> float:
    """Vaka sayısının tam zaman eşdeğerine oranı (%) — türetilmiş.

    Standardın bağlam açıklaması: kurum ölçüm döneminde ikiye katlanmışsa,
    sabit kalan bir uyuşmazlık sayısı TZE'ye oran olarak yarıya inmiş demektir.
    """
    return 100 * vaka / tze


def ic_cozum_orani(ic_cozulen: float, toplam: float) -> float:
    """İçeride çözülen şikâyetlerin payı (%).

    Şikâyetler ayrıca içeride ve dışarıda çözülenler olarak sınıflandırılabilir;
    içeride çözülen payın artması olumlu bir eğilim sayılır.
    """
    return 100 * ic_cozulen / toplam


def kategori_payi(kategori: float, toplam: float) -> float:
    """Bir kategorinin toplam içindeki payı (%) — türetilmiş."""
    return 100 * kategori / toplam


def yillik_degisim(cari: float, onceki: float) -> float:
    """Bir metriğin önceki yıla göre yüzde değişimi — türetilmiş.

    Raporlama, önceki dönemlerle cari dönemi ve geçmiş yıllarla cari yılı
    karşılaştırır; tipik karşılaştırma aralığı üç ilâ beş yıldır.
    """
    return 100 * (cari - onceki) / onceki


def hedef_sapmasi(gerceklesen: float, hedef: float) -> float:
    """Hedeflenen uyum düzeyinden sapma (puan) — türetilmiş.

    Her kurum, her metrik için hedef uyum düzeyini ve sapmanın hangi eşikten
    sonra "kayda değer" sayılacağını kendisi belirler, belgeler ve paydaşlara
    duyurur.
    """
    return gerceklesen - hedef


def sikayetsiz_gun(donem_gun: float, sikayetli_gun: float) -> float:
    """Belirlenen dönemdeki şikâyetsiz gün sayısı — türetilmiş.

    Kurumlar iyileşmeyi olayın yokluğuyla da raporlayabilir: son şikâyetten bu
    yana geçen gün ya da dönemdeki şikâyetsiz gün sayısı.
    """
    return donem_gun - sikayetli_gun


# ---------------------------------------------------------------------------
# 5) Dönem tablosu
# ---------------------------------------------------------------------------

@dataclass
class Donem:
    """Tek bir ölçüm döneminin uyum verisi."""
    ad: str
    sikayet: float = 0
    acilis: float = 0
    eklenen: float = 0
    kapanis: float = 0
    havale: float = 0

    @property
    def sonuclanan(self) -> float:
        return sonuclandirilan(self.acilis, self.eklenen, self.kapanis)


@dataclass
class UyumTablosu:
    """Dönemlerden oluşan kümülatif uyum tablosu."""
    donemler: list = field(default_factory=list)

    def ekle(self, ad: str, sikayet: float = 0, acilis: float = 0,
             eklenen: float = 0, kapanis: float = 0,
             havale: float = 0) -> "UyumTablosu":
        self.donemler.append(Donem(ad, sikayet, acilis, eklenen, kapanis, havale))
        return self

    def _topla(self, alan: str) -> float:
        return sum(getattr(d, alan) for d in self.donemler)

    def ozet(self, tze: float = 1000) -> dict:
        sikayet = self._topla("sikayet")
        havale = self._topla("havale")
        sonuclanan = sum(d.sonuclanan for d in self.donemler)
        return {
            "donem_sayisi": len(self.donemler),
            "toplam_sikayet": sikayet,
            "toplam_havale": havale,
            "toplam_sonuclanan": sonuclanan,
            "eklenen_disiplin": self._topla("eklenen"),
            "sikayet_tze_yuzde": round(tze_orani(sikayet, tze), 2),
            "havale_tze_yuzde": round(tze_orani(havale, tze), 2),
            "dis_havale_payi_yuzde": round(kategori_payi(havale, sikayet), 1)
            if sikayet else None,
            "acik_kalan": round(acik_dosya(
                self.donemler[0].acilis, self._topla("eklenen"), sonuclanan), 0)
            if self.donemler else None,
        }

    def tablo(self) -> list:
        seri = kumulatif([d.sikayet for d in self.donemler])
        return [[d.ad, d.sikayet, d.acilis, d.eklenen, d.kapanis, d.havale,
                 seri[i], d.sonuclanan]
                for i, d in enumerate(self.donemler)]


def ornek_tablo() -> UyumTablosu:
    """Altı aylık örnek tablo (1.000 kişilik bir kurum için).

    Şikâyet serisi standardın kümülatif örneğiyle aynı büyüklüktedir:
    3, 5, 4, 4, 4, 2 → yıl başından itibaren 22. Disiplin işlemlerinde açılış
    bakiyeleri bir önceki ayın kapanış bakiyesini takip edecek biçimde
    kurulmuştur; dış havale serisi 1, 2, 2, 4, 1, 2 → 12'dir.
    """
    t = UyumTablosu()
    t.ekle("Ocak", sikayet=3, acilis=25, eklenen=10, kapanis=22, havale=1)
    t.ekle("Şubat", sikayet=5, acilis=22, eklenen=10, kapanis=20, havale=2)
    t.ekle("Mart", sikayet=4, acilis=20, eklenen=15, kapanis=25, havale=2)
    t.ekle("Nisan", sikayet=4, acilis=25, eklenen=8, kapanis=20, havale=4)
    t.ekle("Mayıs", sikayet=4, acilis=20, eklenen=9, kapanis=15, havale=1)
    t.ekle("Haziran", sikayet=2, acilis=15, eklenen=12, kapanis=17, havale=2)
    return t


def metrik_denetimi(sikayet_tanimi_yazili: bool = False,
                    disiplin_tanimi_yazili: bool = False,
                    kayit_sureci_var: bool = False,
                    hedef_uyum_belirlendi: bool = False,
                    kayda_deger_sapma_tanimli: bool = False,
                    kategori_bazli_raporlama: bool = False,
                    bulgu_eylem_kaydi_var: bool = False,
                    baglam_notu_var: bool = False) -> list:
    """Bir uyum ve etik raporunun eksiklerini listeler.

    Standardın mantığı: bu kümedeki sayılar, tanımlar ve hedefler yazılı
    olmadan ne kurum içinde ne de kurumlar arasında yorumlanabilir.
    """
    uyarilar = []
    if not sikayet_tanimi_yazili:
        uyarilar.append("'Şikâyet' tanımı yazılı değil: bir şikâyetin hangi "
                        "anda resmî sayıldığı (kayıt ya da soruşturmanın "
                        "başlaması) belirtilmeli.")
    if not disiplin_tanimi_yazili:
        uyarilar.append("'Disiplin işlemi' tanımı yazılı değil ve ilgili iç ve "
                        "dış taraflar bilgilendirilmemiş.")
    if not kayit_sureci_var:
        uyarilar.append("Tüm resmî şikâyetleri ve disiplin işlemlerini yakalayan "
                        "bir kayıt ve yönetim süreci yok.")
    if not hedef_uyum_belirlendi:
        uyarilar.append("Her metrik için hedeflenen uyum düzeyi belirlenmemiş, "
                        "belgelenmemiş ve paydaşlara duyurulmamış.")
    if not kayda_deger_sapma_tanimli:
        uyarilar.append("Hedeften sapmanın hangi eşikten sonra 'kayda değer' "
                        "sayılacağı tanımlanmamış.")
    if not kategori_bazli_raporlama:
        uyarilar.append("Formül yalnızca toplama uygulanmış: her kategoriye "
                        "(taciz, ayrımcılık, saldırı vb.) ayrı ayrı da "
                        "uygulanmalı.")
    if not bulgu_eylem_kaydi_var:
        uyarilar.append("Dış bulgular için kaynak, bulgu ve alınan eylem kaydı "
                        "yok; kabul edilmeyen tavsiyeler için gerekçe de "
                        "yazılmalı.")
    if not baglam_notu_var:
        uyarilar.append("Bağlam notu yok: kadro değişimi, farkındalık "
                        "kampanyaları, yeniden yapılanma ve ekonomik koşullar "
                        "sayının yanına yazılmalı.")
    return uyarilar


# ---------------------------------------------------------------------------
# 6) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "kumulatif", "sonuclandirilan", "dis_sonuclandirilan", "egitim_tamamlama",
    "sure_icinde", "tze_orani", "ic_cozum", "kategori_payi", "yillik_degisim",
    "sikayetsiz_gun",
]


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "kumulatif":
        aylik = [float(x) for x in g["aylik"]]
        seri = kumulatif(aylik)
        d = seri[-1]
        return {"deger": d, "ondalik": 0, "birim": "vaka (yıl başından itibaren)",
                "ifade": " + ".join(_s(x) for x in aylik),
                "ayrinti": [["Dönem sayısı", len(aylik)],
                            ["Dönem ortalaması", round(d / len(aylik), 2)],
                            ["En yüksek dönem", max(aylik)],
                            ["Son dönem", aylik[-1]],
                            ["TZE'ye oranı (%)", round(tze_orani(d, g["tze"]), 2)]]}

    if metrik == "sonuclandirilan":
        d = sonuclandirilan(g["acilis"], g["eklenen"], g["kapanis"])
        return {"deger": d, "ondalik": 0, "birim": "sonuçlandırılan işlem",
                "ifade": (f"{_s(g['acilis'])} + {_s(g['eklenen'])} − "
                          f"{_s(g['kapanis'])}"),
                "ayrinti": [["Dönem sonunda açık kalan", g["kapanis"]],
                            ["Dönemde işleme giren toplam",
                             g["acilis"] + g["eklenen"]],
                            ["Sonuçlandırma oranı (%)",
                             round(100 * d / (g["acilis"] + g["eklenen"]), 1)],
                            ["TZE'ye oranı (%)", round(tze_orani(d, g["tze"]), 2)]]}

    if metrik == "dis_sonuclandirilan":
        d = dis_sonuclandirilan(g["acilis"], g["havale"], g["geri_cekilen"],
                                g["kapanis"])
        return {"deger": d, "ondalik": 0, "birim": "sonuçlandırılan uyuşmazlık",
                "ifade": (f"{_s(g['acilis'])} + {_s(g['havale'])} − "
                          f"{_s(g['geri_cekilen'])} − {_s(g['kapanis'])}"),
                "ayrinti": [["Dönem sonunda açık kalan", g["kapanis"]],
                            ["Geri çekilen", g["geri_cekilen"]],
                            ["Geri çekilme oranı (%)",
                             round(100 * g["geri_cekilen"] / g["havale"], 1)],
                            ["TZE'ye oranı (%)", round(tze_orani(d, g["tze"]), 2)]]}

    if metrik == "egitim_tamamlama":
        d = egitim_tamamlama(g["tamamlayan"], g["tamamlamasi_gereken"])
        sure = sure_icinde_tamamlama(g["sure_icinde"], g["tamamlamasi_gereken"])
        return {"deger": d, "ondalik": 1, "birim": "% tamamlama",
                "ifade": (f"({_s(g['tamamlayan'])} ÷ "
                          f"{_s(g['tamamlamasi_gereken'])}) × 100"),
                "ayrinti": [["Süre içinde tamamlama (%)", round(sure, 1)],
                            ["Süre hedefini kaçıran (kişi)",
                             g["tamamlayan"] - g["sure_icinde"]],
                            ["Hiç tamamlamayan (kişi)",
                             g["tamamlamasi_gereken"] - g["tamamlayan"]],
                            ["Hedeften sapma (puan)",
                             round(hedef_sapmasi(d, g["hedef"]), 1)]]}

    if metrik == "sure_icinde":
        d = sure_icinde_tamamlama(g["sure_icinde"], g["tamamlamasi_gereken"])
        genel = egitim_tamamlama(g["tamamlayan"], g["tamamlamasi_gereken"])
        return {"deger": d, "ondalik": 1, "birim": "% süre içinde tamamlama",
                "ifade": (f"({_s(g['sure_icinde'])} ÷ "
                          f"{_s(g['tamamlamasi_gereken'])}) × 100"),
                "ayrinti": [["Genel tamamlama oranı (%)", round(genel, 1)],
                            ["İki oran arasındaki fark (puan)",
                             round(genel - d, 1)],
                            ["Süre hedefini kaçıran (kişi)",
                             g["tamamlayan"] - g["sure_icinde"]]]}

    if metrik == "tze_orani":
        d = tze_orani(g["vaka"], g["tze"])
        onceki = tze_orani(g["onceki_vaka"], g["onceki_tze"])
        return {"deger": d, "ondalik": 2, "birim": "% TZE başına vaka",
                "ifade": f"({_s(g['vaka'])} ÷ {_s(g['tze'])}) × 100",
                "ayrinti": [["Önceki dönem oranı (%)", round(onceki, 2)],
                            ["Oran değişimi (puan)", round(d - onceki, 2)],
                            ["Mutlak vaka değişimi", g["vaka"] - g["onceki_vaka"]],
                            ["Kadro değişimi (%)",
                             round(yillik_degisim(g["tze"], g["onceki_tze"]), 1)]]}

    if metrik == "ic_cozum":
        d = ic_cozum_orani(g["ic_cozulen"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% içeride çözülen",
                "ifade": f"({_s(g['ic_cozulen'])} ÷ {_s(g['toplam'])}) × 100",
                "ayrinti": [["Dışarıda çözülen", g["toplam"] - g["ic_cozulen"]],
                            ["Dış çözüm oranı (%)", round(100 - d, 1)],
                            ["Önceki döneme fark (puan)",
                             round(d - g["onceki_oran"], 1)]]}

    if metrik == "kategori_payi":
        d = kategori_payi(g["kategori"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% toplam içinde",
                "ifade": f"({_s(g['kategori'])} ÷ {_s(g['toplam'])}) × 100",
                "ayrinti": [["Diğer kategoriler (vaka)",
                             g["toplam"] - g["kategori"]],
                            ["Kategorideki yıllık değişim (%)",
                             round(yillik_degisim(g["kategori"],
                                                  g["onceki_kategori"]), 1)],
                            ["Önceki dönem payı (%)",
                             round(kategori_payi(g["onceki_kategori"],
                                                 g["onceki_toplam"]), 1)]]}

    if metrik == "yillik_degisim":
        d = yillik_degisim(g["cari"], g["onceki"])
        return {"deger": d, "ondalik": 1, "birim": "% yıllık değişim",
                "ifade": (f"(({_s(g['cari'])} − {_s(g['onceki'])}) ÷ "
                          f"{_s(g['onceki'])}) × 100"),
                "ayrinti": [["Mutlak değişim", g["cari"] - g["onceki"]],
                            ["Cari dönem TZE oranı (%)",
                             round(tze_orani(g["cari"], g["tze"]), 2)],
                            ["Önceki dönem TZE oranı (%)",
                             round(tze_orani(g["onceki"], g["onceki_tze"]), 2)]]}

    if metrik == "sikayetsiz_gun":
        d = sikayetsiz_gun(g["donem_gun"], g["sikayetli_gun"])
        return {"deger": d, "ondalik": 0, "birim": "şikâyetsiz gün",
                "ifade": f"{_s(g['donem_gun'])} − {_s(g['sikayetli_gun'])}",
                "ayrinti": [["Dönemdeki şikâyetli gün", g["sikayetli_gun"]],
                            ["Şikâyetsiz gün payı (%)",
                             round(100 * d / g["donem_gun"], 1)],
                            ["Son şikâyetten bu yana geçen gün",
                             g["son_sikayetten_gun"]]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 7) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 78
    print("ISO/TS 30423 — doğrulama çıktısı")
    print(cizgi)

    print("Şikâyetler: yıl başından itibaren birikim")
    aylar = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran"]
    aylik = [3, 5, 4, 4, 4, 2]
    seri = kumulatif(aylik)
    print(f"{'Ay':<10}{'Şikâyet':>9}{'Kümülatif':>12}")
    for ad, a, k in zip(aylar, aylik, seri):
        print(f"{ad:<10}{a:>9.0f}{k:>12.0f}")
    print(f"{'TOPLAM':<10}{sum(aylik):>9.0f}")
    print(cizgi)

    print("Şikâyet kategorileri (dört yıllık karşılaştırma)")
    kategoriler = [
        ("Taciz - cinsel", [2, 5, 7, 10]),
        ("Taciz", [2, 7, 10, 15]),
        ("Ayrımcılık - doğrudan", [4, 10, 12, 15]),
        ("Ayrımcılık - dolaylı", [7, 5, 2, 0]),
        ("Saldırı - sözlü", [7, 4, 2, 0]),
        ("Saldırı - fiziksel", [0, 1, 5, 7]),
    ]
    print(f"{'Kategori':<24}{'2026':>7}{'2025':>7}{'2024':>7}{'2023':>7}{'Pay %':>8}")
    toplamlar = [sum(k[1][i] for k in kategoriler) for i in range(4)]
    for ad, degerler in kategoriler:
        pay = kategori_payi(degerler[0], toplamlar[0]) if toplamlar[0] else 0
        print(f"{ad:<24}" + "".join(f"{d:>7.0f}" for d in degerler) + f"{pay:>8.1f}")
    print(f"{'TOPLAM':<24}" + "".join(f"{t:>7.0f}" for t in toplamlar))
    print(cizgi)

    print("İçeride mi dışarıda mı çözüldü?")
    for yil, ic, dis in [("2026", 16, 6), ("2025", 20, 12),
                         ("2024", 10, 28), ("2023", 7, 37)]:
        print(f"  {yil}: içeride {ic:>3}, dışarıda {dis:>3} → "
              f"iç çözüm oranı {ic_cozum_orani(ic, ic + dis):.1f} %")
    print(cizgi)

    print("Disiplin işlemleri: hareket hesabı")
    t = ornek_tablo()
    print(f"{'Ay':<10}{'Açılış':>8}{'Eklenen':>9}{'Kapanış':>9}"
          f"{'Sonuçlanan':>12}{'Havale':>8}{'Küm. şikâyet':>14}")
    for satir in t.tablo():
        print(f"{satir[0]:<10}{satir[2]:>8.0f}{satir[3]:>9.0f}{satir[4]:>9.0f}"
              f"{satir[7]:>12.0f}{satir[5]:>8.0f}{satir[6]:>14.0f}")
    print(cizgi)
    for k, v in t.ozet().items():
        print(f"{k:<24}: {v}")
    print(cizgi)

    print("Dış taraflarca sonuçlandırılan uyuşmazlıklar")
    print(f"  Açılış 20, havale 3, geri çekilen 0, kapanış 16 → "
          f"{dis_sonuclandirilan(20, 3, 0, 16):.0f}")
    print(f"  Açılış 16, havale 5, geri çekilen 1, kapanış 15 → "
          f"{dis_sonuclandirilan(16, 5, 1, 15):.0f}")
    print(cizgi)

    print("Uyum ve etik eğitimi tamamlama (dört yıllık karşılaştırma)")
    egitimler = [("Uyum 1", [90, 85, 85, 80]), ("Uyum 2", [87, 87, 80, 70]),
                 ("Etik 1", [100, 90, 85, 80]), ("Etik 2", [80, 75, 70, 70])]
    print(f"{'Eğitim':<10}{'2026':>7}{'2025':>7}{'2024':>7}{'2023':>7}"
          f"{'Değişim %':>12}")
    for ad, degerler in egitimler:
        deg = yillik_degisim(degerler[0], degerler[1])
        print(f"{ad:<10}" + "".join(f"{d:>7.0f}" for d in degerler) + f"{deg:>12.1f}")
    print(f"  900/1000 çalışan tamamladı → {egitim_tamamlama(900, 1000):.1f} %")
    print(f"  Bunun 780'i süre içinde   → {sure_icinde_tamamlama(780, 1000):.1f} %")
    print(cizgi)

    print("Bağlam: kadro büyürken sabit kalan vaka sayısı")
    print(f"  2023: 2 kaza uyuşmazlığı / 500 TZE → {tze_orani(2, 500):.2f} %")
    print(f"  2026: 2 kaza uyuşmazlığı / 1000 TZE → {tze_orani(2, 1000):.2f} %")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("sonuclandirilan", acilis=25, eklenen=10, kapanis=22, tze=1000))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
