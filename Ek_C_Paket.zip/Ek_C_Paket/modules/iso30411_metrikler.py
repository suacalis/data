#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30411_metrikler.py
=====================
ISO/TS 30411:2018 (Human resource management — Quality of hire metric)
çerçevesindeki işe alım kalitesi (QoH) metriğinin Python karşılığı.

Teknik şartname işe alım kalitesini, çalışanın işe alım sonrası performansının
işe alım öncesi beklentilerle karşılaştırılması olarak tanımlar ve iki yaklaşım sunar:
  A) Performans hedeflerinin gerçekleşmesi: yeni işe alımların ortalama performans puanı
  B) Bilgi, beceri ve yeteneklerde (KSA) beklentilere göre memnuniyet: ortalama KSA puanı
Modül üç bölüme ayrılmıştır:

    1) Ortalamalar  — yaklaşım A ve B ortalamaları, grup için ortalamaların ortalaması
    2) Karşılaştırma — beklenti farkı, beklentiyi karşılama oranı
    3) Yardımcı yapılar — yeni işe alım tablosu, denetim, dağıtıcı

Kullanım:
    from iso30411_metrikler import ortalama_puan, beklenti_farki_yuzde
    ortalama_puan(20, 6)               ->  3.3333...
    beklenti_farki_yuzde(3.3333, 3)    ->  11.11...

Doğrudan çalıştırıldığında (python3 iso30411_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30411:2018'e dayanır.
Beklentiyi karşılama oranı ve ölçekteki göreli konum şartnamede formül olarak
verilmez; bu modülde türetilmiş hesaplardır. Kod ve açıklamalar özgün olarak
yazılmıştır; şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # ortalamalar
    "ortalama_puan", "ortalamalarin_ortalamasi",
    # karşılaştırma
    "beklenti_farki_yuzde", "beklenti_farki_puan", "karsilama_orani", "olcekte_konum",
    # yardımcı
    "YeniIsealim", "QoHTablosu", "ornek_tablo", "qoh_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, puan ölçek dışında vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _olcek(alt: float, ust: float) -> None:
    if ust <= alt:
        raise GecersizGirdi("ölçek üst sınırı alt sınırdan büyük olmalı")


def _ortalama_kontrol(ort: float, alt: float, ust: float) -> None:
    _olcek(alt, ust)
    if ort < alt or ort > ust:
        raise GecersizGirdi("ortalama ölçek sınırları içinde olmalı")


# ---------------------------------------------------------------------------
# 1) Ortalamalar (madde 5.2 ve 5.3)
# ---------------------------------------------------------------------------

def ortalama_puan(toplam: float, adet: float) -> float:
    """Puanların toplamı ÷ kişi (ya da madde) sayısı.

    Yaklaşım A (5.2.3): yeni işe alımların değerlendirme dönemi sonundaki
    performans puanları toplamı ÷ toplam yeni işe alım.
    Yaklaşım B (5.3.3): KSA puanları toplamı ÷ toplam KSA maddesi.
    """
    if toplam < 0:
        raise GecersizGirdi("puan toplamı negatif olamaz")
    return _bol(toplam, adet, "kişi ya da madde sayısı")


def ortalamalarin_ortalamasi(*ortalamalar: float) -> float:
    """Grup için işe alım kalitesi: bireysel ortalamaların ortalaması (5.3.4)."""
    if not ortalamalar:
        raise GecersizGirdi("en az bir ortalama gerekir")
    for o in ortalamalar:
        if o < 0:
            raise GecersizGirdi("ortalama negatif olamaz")
    return sum(ortalamalar) / len(ortalamalar)


# ---------------------------------------------------------------------------
# 2) Karşılaştırma
# ---------------------------------------------------------------------------

def beklenti_farki_puan(ortalama: float, beklenti: float) -> float:
    """Ortalama − işe alım öncesi beklenti (puan)."""
    return ortalama - beklenti


def beklenti_farki_yuzde(ortalama: float, beklenti: float) -> float:
    """(ortalama − beklenti) ÷ beklenti × 100.

    Şartname örnekleri: 3,33 → beklentinin %11 üstünde; 3,6 → %20; 3,5 → %17.
    """
    return 100 * (ortalama - beklenti) / _beklenti(beklenti)


def _beklenti(beklenti: float) -> float:
    if beklenti <= 0:
        raise GecersizGirdi("beklenti sıfırdan büyük olmalı")
    return beklenti


def karsilama_orani(toplam: float, karsilayan: float) -> float:
    """Beklentiyi karşılayan ya da aşan yeni işe alımların yüzdesi (türetilmiş).

    Girişteki "beklentileri karşılayan ya da aşan ürün/hizmet yüzdesi" tanımından
    esinlenir; şartname bu oranı formül olarak vermez.
    """
    if toplam <= 0:
        raise GecersizGirdi("toplam sıfırdan büyük olmalı")
    if karsilayan < 0 or karsilayan > toplam:
        raise GecersizGirdi("karşılayan 0 ile toplam arasında olmalı")
    return 100 * karsilayan / toplam


def olcekte_konum(ortalama: float, alt: float, ust: float) -> float:
    """Ortalamanın ölçek içindeki konumu (%): (ortalama − alt) ÷ (üst − alt) × 100 (türetilmiş)."""
    _ortalama_kontrol(ortalama, alt, ust)
    return 100 * (ortalama - alt) / (ust - alt)


# ---------------------------------------------------------------------------
# 3) Yardımcı yapılar: yeni işe alım tablosu
# ---------------------------------------------------------------------------

@dataclass
class YeniIsealim:
    """Tek bir yeni işe alımın puanları."""
    ad: str
    performans: float | None = None          # yaklaşım A
    ksa: list = field(default_factory=list)  # yaklaşım B madde puanları

    def ksa_ortalama(self) -> float:
        return ortalama_puan(sum(self.ksa), len(self.ksa))


@dataclass
class QoHTablosu:
    """Yeni işe alımlar tablosu."""
    kisiler: list = field(default_factory=list)
    beklenti: float = 3
    alt: float = 1
    ust: float = 5

    def ekle(self, ad, performans=None, ksa=None) -> "QoHTablosu":
        for p in ([performans] if performans is not None else []) + list(ksa or []):
            if p < self.alt or p > self.ust:
                raise GecersizGirdi("puan ölçek sınırları içinde olmalı")
        self.kisiler.append(YeniIsealim(ad, performans, list(ksa or [])))
        return self

    def ozet(self) -> dict:
        a = [k.performans for k in self.kisiler if k.performans is not None]
        b = [k.ksa_ortalama() for k in self.kisiler if k.ksa]
        ort_a = ortalama_puan(sum(a), len(a))
        out = {
            "yeni_isealim": len(self.kisiler),
            "a_ortalama": round(ort_a, 2),
            "a_beklenti_farki_yuzde": round(beklenti_farki_yuzde(ort_a, self.beklenti), 1),
            "a_karsilama_yuzde": round(karsilama_orani(len(a), sum(1 for p in a if p >= self.beklenti)), 1),
        }
        if b:
            ort_b = ortalamalarin_ortalamasi(*b)
            out["b_ortalama"] = round(ort_b, 2)
            out["b_beklenti_farki_yuzde"] = round(beklenti_farki_yuzde(ort_b, self.beklenti), 1)
        return out


def ornek_tablo() -> QoHTablosu:
    """Şartnamenin örnekleri: yaklaşım A için altı yeni işe alım (2, 2, 3, 4, 5, 4);
    yaklaşım B için A kişisinin KSA puanları (4, 2, 3, 4, 5)."""
    t = QoHTablosu()
    t.ekle("A", 2, [4, 2, 3, 4, 5])
    for ad, p in (("B", 2), ("C", 3), ("D", 4), ("E", 5), ("F", 4)):
        t.ekle(ad, p)
    return t


def qoh_denetimi(beklenti_onceden_yazili: bool = False,
                 donem_tanimli: bool = False,
                 olcek_belgeli: bool = False,
                 puanlama_tutarli: bool = False,
                 anket_dogrulanmis: bool = False,
                 baglam_notlari: bool = False,
                 kapsam_ayri: bool = False) -> list:
    """Bir QoH raporunun eksiklerini listeler.

    Maddeler ISO/TS 30411'in 4 ve 5. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (beklenti_onceden_yazili, "İşe alım öncesi beklentiler (kabul edilebilir en düşük performans ölçütleri) işe alımdan önce yazılmamış."),
        (donem_tanimli, "Değerlendirme dönemi (3, 6, 9 ya da 12 ay) tanımlanmamış."),
        (olcek_belgeli, "Puanlama ölçeği ve kabul edilebilir düzey (ör. 1–5; 3 kabul edilebilir) belgelenmemiş."),
        (puanlama_tutarli, "Hat yöneticilerinin cömert/katı puanlama farkları dengelenmemiş; eğilim kaliteyi değil puanlama stilini yansıtabilir."),
        (anket_dogrulanmis, "KSA soruları, elde tutma, müşteri/gelir büyümesi ve kârlılık gibi örgütsel çıktılarla ilişki açısından sınanmamış."),
        (baglam_notlari, "Bağlam etkenleri (işe alım başına maliyet, işe alma süresi, devir ve elde tutma oranı) yazılmamış."),
        (kapsam_ayri, "İşe alımın etkisi ve işe alımın elde tutulması bu metrikle karıştırılıyor; ayrı belgelerle ölçülür."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["performans", "ksa", "grup", "fark", "karsilama"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def _ort_ayrinti(ort: float, beklenti: float, alt: float, ust: float) -> list:
    return [["Beklenti farkı (puan)", round(beklenti_farki_puan(ort, beklenti), 2)],
            ["Beklentinin üstünde ya da altında (%)", round(beklenti_farki_yuzde(ort, beklenti), 1)],
            ["Ölçekteki göreli konum (%)", round(olcekte_konum(ort, alt, ust), 1)]]


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "performans":
        d = ortalama_puan(g["puan_toplami"], g["kisi"])
        _ortalama_kontrol(d, g["alt"], g["ust"])
        return {"deger": d, "ondalik": 2, "birim": "ortalama performans puanı",
                "ifade": f"{_g(g['puan_toplami'])} ÷ {_g(g['kisi'])}",
                "ayrinti": _ort_ayrinti(d, g["beklenti"], g["alt"], g["ust"])}

    if metrik == "ksa":
        d = ortalama_puan(g["ksa_toplami"], g["madde"])
        _ortalama_kontrol(d, g["alt"], g["ust"])
        return {"deger": d, "ondalik": 2, "birim": "ortalama KSA puanı",
                "ifade": f"{_g(g['ksa_toplami'])} ÷ {_g(g['madde'])}",
                "ayrinti": _ort_ayrinti(d, g["beklenti"], g["alt"], g["ust"])}

    if metrik == "grup":
        o = [g[f"o{i}"] for i in range(1, 7)]
        d = ortalamalarin_ortalamasi(*o)
        _ortalama_kontrol(d, g["alt"], g["ust"])
        return {"deger": d, "ondalik": 2, "birim": "grup QoH (ortalamaların ortalaması)",
                "ifade": "(" + " + ".join(_g(x) for x in o) + ") ÷ 6",
                "ayrinti": _ort_ayrinti(d, g["beklenti"], g["alt"], g["ust"])
                           + [["En düşük bireysel ortalama", min(o)], ["En yüksek bireysel ortalama", max(o)]]}

    if metrik == "fark":
        d = beklenti_farki_yuzde(g["ortalama"], g["beklenti"])
        return {"deger": d, "ondalik": 1, "birim": "% (beklentinin üstünde)",
                "ifade": f"({_g(g['ortalama'])} − {_g(g['beklenti'])}) ÷ {_g(g['beklenti'])} × 100",
                "ayrinti": [["Beklenti farkı (puan)", round(beklenti_farki_puan(g["ortalama"], g["beklenti"]), 2)],
                            ["Ortalamanın beklentiye oranı", round(g["ortalama"] / g["beklenti"], 2)]]}

    if metrik == "karsilama":
        d = karsilama_orani(g["toplam_yeni"], g["karsilayan"])
        return {"deger": d, "ondalik": 1, "birim": "% (beklentiyi karşılayan ya da aşan)",
                "ifade": f"{_g(g['karsilayan'])} ÷ {_g(g['toplam_yeni'])} × 100",
                "ayrinti": [["Beklentinin altında kalan yeni işe alım", g["toplam_yeni"] - g["karsilayan"]],
                            ["Beklentinin altında kalan pay (%)", round(100 - d, 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30411 — doğrulama çıktısı")
    print(cizgi)

    print("Yaklaşım A (6 yeni işe alım; ölçek 1–5, beklenti 3)")
    a = ortalama_puan(2 + 2 + 3 + 4 + 5 + 4, 6)
    print(f"  ortalama {a:.2f}  -> beklentinin %{beklenti_farki_yuzde(a, 3):.0f} üstünde")
    print("Yaklaşım B (tek kişi, 5 KSA maddesi)")
    b = ortalama_puan(4 + 2 + 3 + 4 + 5, 5)
    print(f"  ortalama {b:.1f}  -> beklentinin %{beklenti_farki_yuzde(b, 3):.0f} üstünde")
    print(f"Grup (ortalamaların ortalaması 3,5): %{beklenti_farki_yuzde(3.5, 3):.0f} (0,5 puan)")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<24}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("performans", puan_toplami=20, kisi=6, beklenti=3, alt=1, ust=5))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in qoh_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
