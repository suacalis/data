#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30435_metrikler.py
=====================
ISO 30435:2023 (Human resource management — Workforce data quality)
rehberindeki işgücü veri kalitesi ölçümlerinin Python karşılığı.

Standart bir metrik şartnamesi değil, süreç rehberidir: işgücü verisinin
belirlenmesi, yakalanması, bakımı ve gözden geçirilmesi için politika, süreç
ve uygulamaları anlatır. Veri kalitesini beş unsurla tanımlar: doğruluk,
güncellik, tamlık, tutarlılık ve uygunluk. Tablo 4, veri grupları için
örnek gözden geçirme sıklığı, örnek hacmi ve doğruluk/tamlık düzeyi verir.
Formül vermez. Bu modüldeki formüller, bu beş unsurun yaygın uygulama
tanımlarıdır ve kurumunuzun kendi tanımıyla uyarlanmalıdır. Modül dört
bölümden oluşur:

    1) Doğruluk ve örnekleme — doğruluk oranı, gereken örnek, hatasız örnek sınırı
    2) Tamlık, güncellik, tutarlılık, uygunluk
    3) Belge teyidi, tarihsel temizlik iş yükü, boyut skor kartı
    4) Yardımcı yapılar — denetim tablosu (Tablo 4), denetim kontrol listesi, dağıtıcı

Kullanım:
    from iso30435_metrikler import dogruluk_orani, gereken_ornek
    dogruluk_orani(200, 6)     ->  97.0
    gereken_ornek(1200, 5)     ->  60

Doğrudan çalıştırıldığında (python3 iso30435_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Terimler ve süreç yapısı ISO 30435:2023'e dayanır. Kod, açıklamalar ve
örnek değerler özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # doğruluk ve örnekleme
    "hata_orani", "dogruluk_orani", "esik_karsilandi", "gereken_ornek",
    "hatasiz_ust_sinir",
    # diğer boyutlar
    "tamlik_orani", "zamaninda_orani", "ortalama_gecikme", "tutarlilik_orani",
    "uygunluk_orani", "belge_teyit_orani", "temizlik_is_yuku", "zayif_halka",
    # yardımcı
    "TABLO4", "VeriGrubu", "DenetimTablosu", "ornek_tablo", "veri_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _oran(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


def _yuzde(x: float, ad: str) -> float:
    if x < 0 or x > 100:
        raise GecersizGirdi(f"{ad} 0 ile 100 arasında olmalı")
    return x


# ---------------------------------------------------------------------------
# 1) Doğruluk ve örnekleme (madde 4.2, 7.4, Tablo 4)
# ---------------------------------------------------------------------------

def hata_orani(ornek: float, hatali: float) -> float:
    """Örneklenen kayıtlardaki hata oranı (%) = hatalı / örnek × 100."""
    return _oran(hatali, ornek, "hatalı")


def dogruluk_orani(ornek: float, hatali: float) -> float:
    """Doğruluk (%) = (1 − hatalı / örnek) × 100.

    Standart, doğruluk düzeyinin verinin niteliğine ve ilgili sektör
    kılavuzlarına göre belirlenmesini ister (madde 4.2). Hata, kurumun
    yazılı kuralına göre sayılır: yanlış değer, eskimiş değer, kanıtsız değer.
    """
    return 100 - hata_orani(ornek, hatali)


def esik_karsilandi(deger: float, esik: float) -> bool:
    """Ölçülen düzey, kullanıcı tanımlı toleransı karşılıyor mu (madde 7.4)."""
    return deger >= _yuzde(esik, "eşik")


def gereken_ornek(kayit: float, ornek_pct: float) -> int:
    """Bir veri grubundan gözden geçirilecek asgari kayıt = ⌈kayıt × pct / 100⌉.

    Tablo 4, örneklenecek hacmi veri grubuna göre yüzde olarak verir
    (örneğin %1–%5, %2, %5).
    """
    if kayit <= 0 or not (0 < ornek_pct <= 100):
        raise GecersizGirdi("kayıt sıfırdan büyük, örnek yüzdesi 0 ile 100 arasında olmalı")
    return math.ceil(kayit * ornek_pct / 100)


def hatasiz_ust_sinir(ornek: float) -> float:
    """Örnekte hiç hata bulunmadığında, %95 güvenle gerçek hata oranının üst sınırı (%).

    "Üçlü kural" yaklaşımıdır: yaklaşık 3 / n. Küçük örneklerde (yaklaşık
    30'un altı) kaba bir tahmindir; standart bu hesabı vermez.
    """
    if ornek <= 0:
        raise GecersizGirdi("örnek sıfırdan büyük olmalı")
    return 300 / ornek


# ---------------------------------------------------------------------------
# 2) Tamlık, güncellik, tutarlılık, uygunluk (madde 4.3–4.6)
# ---------------------------------------------------------------------------

def tamlik_orani(dolu: float, beklenen: float) -> float:
    """Tamlık (%) = dolu zorunlu alan / beklenen zorunlu alan × 100."""
    return _oran(dolu, beklenen, "dolu alan")


def zamaninda_orani(zamaninda: float, olay: float) -> float:
    """Güncellik (%): hedef süre içinde kaydedilen olayların oranı."""
    return _oran(zamaninda, olay, "zamanında kayıt")


def ortalama_gecikme(toplam_gun: float, olay: float) -> float:
    """Olay ile kayıt arasındaki ortalama gecikme (gün)."""
    if toplam_gun < 0:
        raise GecersizGirdi("toplam gecikme negatif olamaz")
    return _bol(toplam_gun, olay, "olay sayısı")


def tutarlilik_orani(karsilastirilan: float, tutarsiz: float) -> float:
    """Tutarlılık (%) = (1 − tutarsız / karşılaştırılan) × 100.

    Aynı bilginin iki sistemde, iki dönemde ya da iki biçimde (tarih, unvan,
    departman adı, çalışan numarası) çelişip çelişmediğine bakılır.
    """
    return 100 - _oran(tutarsiz, karsilastirilan, "tutarsız")


def uygunluk_orani(ilgili: float, toplanan: float) -> float:
    """Uygunluk (%): toplanan veri noktalarından amaca hizmet edenlerin oranı."""
    return _oran(ilgili, toplanan, "ilgili veri noktası")


# ---------------------------------------------------------------------------
# 3) Belge teyidi, temizlik iş yükü, skor kartı
# ---------------------------------------------------------------------------

def belge_teyit_orani(teyitli: float, toplam: float) -> float:
    """Zorunlu belge, yetki ve vize kayıtlarında bitiş tarihi teyitli olanların oranı (%).

    Tablo 4 bu veri grupları için tüm bitiş tarihlerinin teyidini ve %100
    düzeyini örnek verir.
    """
    return _oran(teyitli, toplam, "teyitli")


def temizlik_is_yuku(kayit: float, hata_pct: float, dk_kayit: float, saat_ucret: float) -> dict:
    """Tarihsel veri temizliğinin kaba iş yükü ve maliyeti.

    Standart maliyetin işgücü verisinin karmaşıklığına göre değiştiğini
    söyler (madde 6.3.3); bu hesap yalnızca büyüklük mertebesi vermek için
    türetilmiştir.
    """
    if kayit <= 0 or dk_kayit < 0 or saat_ucret < 0:
        raise GecersizGirdi("temizlik girdileri geçersiz")
    hatali = kayit * _yuzde(hata_pct, "hata yüzdesi") / 100
    saat = hatali * dk_kayit / 60
    return {"hatali": hatali, "saat": saat, "maliyet": saat * saat_ucret}


BOYUTLAR = ("Doğruluk", "Güncellik", "Tamlık", "Tutarlılık", "Uygunluk")


def zayif_halka(degerler: list) -> tuple:
    """Beş boyuttan en düşüğü (ad, değer). Bileşik skor standartta yoktur; türetilmiştir."""
    if len(degerler) != 5:
        raise GecersizGirdi("beş boyut değeri gerekir")
    for d in degerler:
        _yuzde(d, "boyut değeri")
    i = min(range(5), key=lambda k: degerler[k])
    return BOYUTLAR[i], degerler[i]


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar: Tablo 4 denetim tablosu
# ---------------------------------------------------------------------------

# (veri grubu, önerilen asgari gözden geçirme sıklığı, örnek hacmi, asgari örnek %, gerekli düzey %)
TABLO4 = [
    ("Kişisel bilgi",                          "Yılda en az bir",       "%1–5 (ilk sonuçlara göre)", 1, 96),
    ("Pozisyon bilgisi (kritik pozisyon dahil)", "Yılda en az bir",     "%1–5",                      1, 95),
    ("Organizasyon şeması",                    "Yılda iki ila dört",    "%5",                        5, 95),
    ("Öğrenme ve gelişim kayıtları",           "Yılda en az bir",       "%3–5",                      3, 95),
    ("Personel işe alım",                      "Yılda en az bir",       "%3–5",                      3, 95),
    ("Uyum (onboarding)",                      "Yılda iki ila dört",    "%2",                        2, 98),
    ("İK veri sözlüğü",                        "Yılda en az bir",       "%3–5",                      3, 95),
    ("İK analitiği (özellikle FTE, kadro)",    "Yılda iki ila dört",    "%5",                        5, 98),
    ("İK ana veri seti (kullanıcı tanımlı)",   "Yılda en az bir",       "%3–5",                      3, 95),
    ("İK maaş verisi",                         "Yılda iki ila dört",    "%3",                        3, 99),
    ("İşgücü performans derecelendirmeleri",   "Yılda en az bir",       "%2",                        2, 99),
    ("Vize bilgisi (çalışma hakkı)",           "Bitişten önce (örn. 2 ay)", "Tüm bitiş tarihlerinin teyidi", 100, 100),
    ("Fazla mesai durumu — muaf",              "Yılda en az bir",       "%2",                        2, 100),
    ("Prim ödemeleri",                         "Yılda en az bir",       "%2",                        2, 100),
    ("Zorunlu yetki belgeleri",                "Yılda en az bir",       "%2",                        2, 100),
    ("Anket verisi",                           "Yılda en az bir",       "%2",                        2, 95),
    ("İş sağlığı ve güvenliği verisi",         "Yılda en az bir",       "%5",                        5, 100),
]


@dataclass
class VeriGrubu:
    """Tek bir veri grubunun gözden geçirme kaydı."""
    ad: str
    kayit: float = 0      # gruptaki toplam kayıt
    ornek: float = 0      # gözden geçirilen kayıt
    hatali: float = 0     # hatalı bulunan kayıt
    gerekli: float = 95   # gerekli doğruluk/tamlık düzeyi (%)
    min_pct: float = 1    # Tablo 4'teki asgari örnek yüzdesi

    @property
    def dogruluk(self):
        return round(dogruluk_orani(self.ornek, self.hatali), 1) if self.ornek > 0 else None

    @property
    def karsilandi(self):
        return None if self.dogruluk is None else self.dogruluk >= self.gerekli

    @property
    def yeterli_ornek(self):
        return self.kayit <= 0 or self.ornek >= gereken_ornek(self.kayit, self.min_pct)


@dataclass
class DenetimTablosu:
    """Dönemin veri gruplarına göre gözden geçirme sonuçları."""
    gruplar: list = field(default_factory=list)

    def ekle(self, ad, kayit, ornek, hatali, gerekli=95, min_pct=1):
        self.gruplar.append(VeriGrubu(ad, kayit, ornek, hatali, gerekli, min_pct))
        return self

    def ozet(self) -> dict:
        olculen = [g for g in self.gruplar if g.ornek > 0]
        ornek = sum(g.ornek for g in olculen)
        hatali = sum(g.hatali for g in olculen)
        basarisiz = [g.ad for g in olculen if not g.karsilandi]
        en_dusuk = min(olculen, key=lambda g: g.dogruluk)
        return {
            "grup_sayisi": len(olculen),
            "toplam_ornek": ornek,
            "toplam_hatali": hatali,
            "genel_dogruluk": round(dogruluk_orani(ornek, hatali), 1),
            "esigi_karsilamayan": len(basarisiz),
            "karsilamayanlar": basarisiz,
            "yetersiz_ornek": [g.ad for g in olculen if not g.yeterli_ornek],
            "en_dusuk": (en_dusuk.ad, en_dusuk.dogruluk),
        }


def ornek_tablo() -> DenetimTablosu:
    """On yedi veri grubu için örnek gözden geçirme (uydurma veri)."""
    kayit_ornek_hata = [
        (1200, 36, 1), (1200, 36, 2), (300, 15, 0), (4200, 168, 6), (260, 10, 1),
        (96, 3, 0), (180, 6, 0), (480, 24, 1), (1200, 40, 1), (1200, 36, 0),
        (1100, 22, 0), (48, 48, 0), (1200, 24, 1), (800, 16, 0), (150, 3, 0),
        (900, 18, 1), (320, 16, 0),
    ]
    t = DenetimTablosu()
    for (ad, _s, _o, min_pct, gerekli), (k, o, h) in zip(TABLO4, kayit_ornek_hata):
        t.ekle(ad, k, o, h, gerekli, min_pct)
    return t


def veri_denetimi(sahiplik_atandi: bool = False,
                  prosedurler_belgeli: bool = False,
                  yasam_dongusu_cercevesi: bool = False,
                  tolerans_tanimli: bool = False,
                  gozden_gecirme_takvimi: bool = False,
                  yillik_rapor: bool = False,
                  yonetim_guvencesi: bool = False,
                  tarihsel_temizlik_plani: bool = False) -> list:
    """Bir işgücü veri kalitesi sisteminin, standardın "shall" ifadelerine göre eksiklerini sıralar.

    Maddeler ISO 30435'in 5.4, 6, 7 maddelerinden türetilmiştir; bir uygunluk
    sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (sahiplik_atandi, "İşgücü verisinin sahipliği, paydaş gruplarından kişiler atanarak belirlenmemiş (6.1)."),
        (prosedurler_belgeli, "İlk giriş, sürekli güncelleme ve veri bakımı için belgelenmiş prosedür yok (6.1)."),
        (yasam_dongusu_cercevesi, "İşgücü yaşam döngüsü çerçevesi, kurumun faaliyetlerini belgelemek için kullanılmamış (5.3)."),
        (tolerans_tanimli, "Her anahtar veri noktası için kabul edilen asgari hata oranı ve örnek hacmi tanımlı değil (7.4)."),
        (gozden_gecirme_takvimi, "Gözden geçirme ve güncelleme takvimi ile prosedürü geliştirilmemiş (6.1, 7.4)."),
        (yillik_rapor, "Veri kalitesi gözden geçirme sürecinin en az yıllık değerlendirmesi ve raporu yok (7.2)."),
        (yonetim_guvencesi, "Yönetim güvencesi (rutin raporlama, eyleme dönüşen sonuç kanıtı, hesap verebilirlik) kurulmamış (7.3)."),
        (tarihsel_temizlik_plani, "Tarihsel veri temizliği için proje ekibi ve proje planı yok (6.3.4)."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "dogruluk", "ornek", "tamlik", "guncellik", "tutarlilik",
    "uygunluk", "belge_teyit", "temizlik", "skor_karti",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri), varsa durum ("ok" ya da "bad").
    """
    if metrik == "dogruluk":
        d = dogruluk_orani(g["ornek"], g["hatali"])
        ok = esik_karsilandi(d, g["esik"])
        return {"deger": d, "ondalik": 1, "birim": "% doğruluk",
                "ifade": f"(1 − {_g(g['hatali'])} ÷ {_g(g['ornek'])}) × 100",
                "durum": "ok" if ok else "bad",
                "ayrinti": [["Hata oranı (%)", round(hata_orani(g["ornek"], g["hatali"]), 1)],
                            ["Gerekli düzeyden fark (puan)", round(d - g["esik"], 1)],
                            ["Gerekli düzey karşılandı mı", "Evet" if ok else "Hayır"]]}

    if metrik == "ornek":
        n = gereken_ornek(g["kayit"], g["ornek_pct"])
        return {"deger": n, "ondalik": 0, "birim": "kayıt (asgari örnek)",
                "ifade": f"⌈{_g(g['kayit'])} × {_g(g['ornek_pct'])} ÷ 100⌉",
                "ayrinti": [["Örneklenmeyen kayıt", g["kayit"] - n],
                            ["Fiili örnek payı (%)", round(100 * n / g["kayit"], 1)],
                            ["Hatasız örnekte %95 güvenle hata üst sınırı (%)", round(hatasiz_ust_sinir(n), 1)]]}

    if metrik == "tamlik":
        d = tamlik_orani(g["dolu"], g["beklenen"])
        ok = esik_karsilandi(d, g["esik"])
        return {"deger": d, "ondalik": 1, "birim": "% tamlık",
                "ifade": f"({_g(g['dolu'])} ÷ {_g(g['beklenen'])}) × 100",
                "durum": "ok" if ok else "bad",
                "ayrinti": [["Eksik alan", g["beklenen"] - g["dolu"]],
                            ["Eksik payı (%)", round(100 - d, 1)],
                            ["Gerekli düzey karşılandı mı", "Evet" if ok else "Hayır"]]}

    if metrik == "guncellik":
        d = zamaninda_orani(g["zamaninda"], g["olay"])
        gecikme = ortalama_gecikme(g["toplam_gecikme_gun"], g["olay"])
        return {"deger": d, "ondalik": 1, "birim": "% zamanında kayıt",
                "ifade": f"({_g(g['zamaninda'])} ÷ {_g(g['olay'])}) × 100",
                "ayrinti": [["Geç kaydedilen olay", g["olay"] - g["zamaninda"]],
                            ["Ortalama gecikme (gün)", round(gecikme, 1)],
                            ["Ortalama gecikme (hafta)", round(gecikme / 7, 1)]]}

    if metrik == "tutarlilik":
        d = tutarlilik_orani(g["karsilastirilan"], g["tutarsiz"])
        return {"deger": d, "ondalik": 1, "birim": "% tutarlı",
                "ifade": f"(1 − {_g(g['tutarsiz'])} ÷ {_g(g['karsilastirilan'])}) × 100",
                "ayrinti": [["Tutarlı kayıt", g["karsilastirilan"] - g["tutarsiz"]],
                            ["Tutarsız kayıt", g["tutarsiz"]],
                            ["Bin kayıtta tutarsızlık", round(1000 * g["tutarsiz"] / g["karsilastirilan"])]]}

    if metrik == "uygunluk":
        d = uygunluk_orani(g["ilgili"], g["toplanan"])
        return {"deger": d, "ondalik": 1, "birim": "% amaca hizmet eden",
                "ifade": f"({_g(g['ilgili'])} ÷ {_g(g['toplanan'])}) × 100",
                "ayrinti": [["Amaçla ilişkisiz veri noktası", g["toplanan"] - g["ilgili"]],
                            ["İlişkisizin payı (%)", round(100 - d, 1)]]}

    if metrik == "belge_teyit":
        d = belge_teyit_orani(g["teyitli"], g["toplam"])
        if g["yakin"] < 0 or g["dolmus"] < 0 or g["yakin"] + g["dolmus"] > g["toplam"]:
            raise GecersizGirdi("yaklaşan ve dolmuş belgeler toplamdan büyük olamaz")
        ok = d >= 100 and g["dolmus"] == 0
        return {"deger": d, "ondalik": 1, "birim": "% bitiş tarihi teyitli",
                "ifade": f"({_g(g['teyitli'])} ÷ {_g(g['toplam'])}) × 100",
                "durum": "ok" if ok else "bad",
                "ayrinti": [["Bitiş tarihi teyit edilmemiş", g["toplam"] - g["teyitli"]],
                            ["Süresi yaklaşan (uyarı süresi içinde)", g["yakin"]],
                            ["Süresi dolmuş", g["dolmus"]]]}

    if metrik == "temizlik":
        r = temizlik_is_yuku(g["kayit"], g["hata_pct"], g["dk_kayit"], g["saat_ucret"])
        return {"deger": r["maliyet"], "ondalik": 0, "birim": "TL",
                "ifade": f"{_g(g['kayit'])} × {_g(g['hata_pct'])} ÷ 100 × {_g(g['dk_kayit'])} ÷ 60 × {_g(g['saat_ucret'])}",
                "ayrinti": [["Düzeltilecek kayıt", r["hatali"]],
                            ["Gereken iş saati", r["saat"]],
                            ["Gereken iş günü (8 saat)", round(r["saat"] / 8, 1)]]}

    if metrik == "skor_karti":
        degerler = [g["dogruluk"], g["guncellik"], g["tamlik"], g["tutarlilik"], g["uygunluk"]]
        ad, d = zayif_halka(degerler)
        return {"deger": d, "ondalik": 1, "birim": "% (en zayıf boyut)",
                "ifade": "min(" + ", ".join(_g(x) for x in degerler) + ")",
                "ayrinti": [["En zayıf boyut", ad],
                            ["Boyutların ortalaması (%)", round(sum(degerler) / 5, 1)],
                            ["En güçlü ile en zayıf arasındaki fark (puan)", round(max(degerler) - d, 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30435 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Veri gruplarına göre gözden geçirme (Tablo 4 düzeyleri; uydurma veri)")
    print(f"{'Veri grubu':<42}{'Örnek':>6}{'Hata':>5}{'Doğr.%':>8}{'Gerekli':>8}")
    for g in t.gruplar:
        isaret = "✓" if g.karsilandi else "✗"
        print(f"{g.ad:<42}{g.ornek:>6}{g.hatali:>5}{g.dogruluk:>8.1f}{g.gerekli:>8} {isaret}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<20}: {deger}")
    print(cizgi)

    print(f"Gereken örnek (1200, %5) : {gereken_ornek(1200, 5)} kayıt"
          f" (hatasız sınır {hatasiz_ust_sinir(60):.1f} %)")
    print(f"Tamlık                   : {tamlik_orani(5712, 6000):.1f} %")
    print(f"Güncellik                : {zamaninda_orani(410, 500):.1f} %,"
          f" ort. gecikme {ortalama_gecikme(3250, 500):.1f} gün")
    print(f"Tutarlılık               : {tutarlilik_orani(300, 21):.1f} %")
    print(f"Uygunluk                 : {uygunluk_orani(98, 140):.1f} %")
    print(f"Belge teyidi             : {belge_teyit_orani(76, 80):.1f} %")
    t_yuk = temizlik_is_yuku(12000, 8, 6, 350)
    tl = f"{t_yuk['maliyet']:,.0f}".replace(",", ".")
    print(f"Temizlik iş yükü         : {t_yuk['saat']:.0f} saat, {tl} TL")
    print(f"Zayıf halka              : {zayif_halka([97, 82, 95, 93, 70])}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("dogruluk", ornek=200, hatali=6, esik=95))
    print(cizgi)

    print("Sistem denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in veri_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
