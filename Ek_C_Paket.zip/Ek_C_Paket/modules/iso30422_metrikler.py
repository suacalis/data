#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30422_metrikler.py
=====================
ISO 30422:2022 (Human resource management — Learning and development)
rehberindeki öğrenme ve gelişim (L&D) ölçümlerinin Python karşılığı.

Standart bir metrik şartnamesi değil, süreç rehberidir: ihtiyaç belirleme,
planlama, uygulama ve değerlendirme aşamalarını tanımlar; Ek B'de dört
metrik ailesi için ÖRNEK metrikler sıralar (tepki, katılım, maliyet, sonuç)
ve formül vermez. Bu modüldeki formüller, o örnek metriklerin yaygın
uygulama tanımlarıdır; kurumunuzun kendi tanımıyla uyarlanmalıdır.
Modül dört bölümden oluşur:

    1) Katılım — resmi öğrenmeye katılım, kategori, sertifika, eğitim saati
    2) Maliyet — toplam ve çalışan başına maliyet, yatırım getirisi
    3) Tepki ve sonuç — memnuniyet, yetkinlik, yetkinliğe ulaşma süresi,
                        öğrenme kazancı ve kalıcılığı
    4) Yardımcı yapılar — eğitim tablosu, rapor denetimi, dağıtıcı

Kullanım:
    from iso30422_metrikler import katilim_orani, kisi_basi_saat
    katilim_orani(1056, 1200)     ->  88.0
    kisi_basi_saat(28928, 1200)   ->  24.106666...

Doğrudan çalıştırıldığında (python3 iso30422_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları ve sınıflandırma ISO 30422:2022'ye dayanır. Kod,
açıklamalar ve örnek değerler özgün olarak yazılmıştır; standardın kendisi
telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # katılım
    "katilim_orani", "kategori_katilim", "sertifika_orani", "kisi_basi_saat",
    # maliyet
    "toplam_ld_maliyeti", "kisi_basi_maliyet", "saat_basi_maliyet",
    "yatirim_getirisi", "fayda_maliyet_orani", "geri_odeme_ayi",
    # tepki ve sonuç
    "olumlu_orani", "yanit_orani", "ortalama_puan", "hedefe_ulasma",
    "ortalama_sure", "ogrenme_kazanci", "kalicilik",
    # yardımcı
    "Kategori", "EgitimTablosu", "ornek_tablo", "ld_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _oran(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


# ---------------------------------------------------------------------------
# 1) Katılım metrikleri (Ek B: participation metrics)
# ---------------------------------------------------------------------------

def katilim_orani(katilan: float, toplam_calisan: float) -> float:
    """Yılda en az bir resmi öğrenme sürecine katılan çalışan oranı (%).

    Katılan = ölçüm döneminde en az bir resmi öğrenme faaliyetine katılan
    TEKİL çalışan sayısı; aynı kişi birden çok eğitime katılsa da bir kez
    sayılır. Çalışan tanımının (sözleşmeli, stajyer, gönüllü dahil mi?)
    kurum içinde yazılı olması gerekir.
    """
    return _oran(katilan, toplam_calisan, "katılan")


def kategori_katilim(katilan: float, hedef_kitle: float) -> float:
    """Bir kategorideki (liderlik gelişimi, mevzuat eğitimi vb.) katılım (%).

    Payda kategorinin hedef kitlesidir. Toplam çalışana oranı için
    katilim_orani(katilan, toplam_calisan) de kullanılabilir; hangisinin
    raporlandığı yazılı olmalıdır.
    """
    return _oran(katilan, hedef_kitle, "katılan")


def sertifika_orani(sertifikali: float, hedef_kitle: float) -> float:
    """Belirli bir alanda sertifika almış çalışanların hedef kitleye oranı (%)."""
    return _oran(sertifikali, hedef_kitle, "sertifikalı")


def kisi_basi_saat(toplam_saat: float, calisan: float) -> float:
    """Çalışan başına ortalama resmi eğitim saati = toplam saat / çalışan.

    Saat maruz kalmanın ölçüsüdür, öğrenmenin değil; yetkinlik ve öğrenme
    kazancı metrikleriyle birlikte okunur.
    """
    return _bol(toplam_saat, calisan, "çalışan sayısı")


# ---------------------------------------------------------------------------
# 2) Maliyet metrikleri (Ek B: cost metrics)
# ---------------------------------------------------------------------------

def toplam_ld_maliyeti(dis_saglayici: float, ic_kaynak: float,
                       teknoloji: float, diger: float,
                       zaman_maliyeti: float = 0) -> float:
    """Toplam öğrenme ve gelişim maliyeti.

    Kalemler kurumun kendi tanımıdır: dış sağlayıcı ve eğitmen ücreti, iç
    eğitmen ile içerik geliştirme emeği, teknoloji ve platform, materyal ile
    mekân. Öğrenenlerin eğitimde geçirdiği sürenin ücret karşılığı
    (zaman_maliyeti) kapsama dahil edilip edilmeyeceği yazılı karar gerektirir.
    """
    kalemler = (dis_saglayici, ic_kaynak, teknoloji, diger, zaman_maliyeti)
    if any(k < 0 for k in kalemler):
        raise GecersizGirdi("maliyet kalemleri negatif olamaz")
    toplam = sum(kalemler)
    if toplam <= 0:
        raise GecersizGirdi("toplam maliyet sıfırdan büyük olmalı")
    return toplam


def kisi_basi_maliyet(toplam_maliyet: float, calisan: float) -> float:
    """Çalışan başına öğrenme ve gelişim maliyeti = toplam maliyet / çalışan."""
    return _bol(toplam_maliyet, calisan, "çalışan sayısı")


def saat_basi_maliyet(toplam_maliyet: float, toplam_saat: float) -> float:
    """Eğitim saati başına maliyet = toplam maliyet / toplam saat."""
    return _bol(toplam_maliyet, toplam_saat, "toplam saat")


def yatirim_getirisi(fayda: float, maliyet: float) -> float:
    """Belirli bir öğrenme faaliyeti için yatırım getirisi (%).

    ROI = (parasal fayda − maliyet) / maliyet × 100. Standart bu formülü
    vermez; belirli faaliyetler için yatırım getirisinin kestirilebileceğini
    söyler. Faydanın öğrenmeye atfedilmesi kurum varsayımıdır.
    """
    if maliyet <= 0:
        raise GecersizGirdi("maliyet sıfırdan büyük olmalı")
    return 100 * (fayda - maliyet) / maliyet


def fayda_maliyet_orani(fayda: float, maliyet: float) -> float:
    """Fayda / maliyet oranı."""
    return _bol(fayda, maliyet, "maliyet")


def geri_odeme_ayi(fayda: float, maliyet: float, fayda_donemi_ay: float) -> float:
    """Maliyetin geri kazanılma süresi (ay).

    Faydanın fayda_donemi_ay boyunca eşit aktığı varsayılır.
    """
    if fayda <= 0 or fayda_donemi_ay <= 0:
        raise GecersizGirdi("fayda ve fayda dönemi sıfırdan büyük olmalı")
    return maliyet / (fayda / fayda_donemi_ay)


# ---------------------------------------------------------------------------
# 3) Tepki ve sonuç metrikleri (Ek B: reaction, outcome metrics)
# ---------------------------------------------------------------------------

def olumlu_orani(olumlu: float, yanit: float) -> float:
    """Öğrenen tepkisi: olumlu yanıtların tüm yanıtlara oranı (%)."""
    return _oran(olumlu, yanit, "olumlu yanıt")


def yanit_orani(yanit: float, katilan: float) -> float:
    """Geri bildirim anketinin yanıt oranı (%). Düşük oranda tepki temsil etmez."""
    return _oran(yanit, katilan, "yanıt")


def ortalama_puan(toplam_puan: float, degerlendirilen: float) -> float:
    """Çalışan grubu için ortalama yetkinlik derecesi = toplam puan / kişi."""
    return _bol(toplam_puan, degerlendirilen, "değerlendirilen kişi sayısı")


def hedefe_ulasma(deger: float, hedef: float) -> float:
    """Değerin kurumun belirlediği hedefe oranı (%)."""
    return 100 * _bol(deger, hedef, "hedef")


def ortalama_sure(toplam_gun: float, vaka: float) -> float:
    """Yeni başlayanın yetkinliğe ulaşma süresi = toplam gün / yeni başlayan.

    Gün tanımı (takvim ya da iş günü) ve "yetkin" sayılma ölçütü yazılı
    olmalıdır; seriler arasında değiştirilmez.
    """
    return _bol(toplam_gun, vaka, "vaka sayısı")


def ogrenme_kazanci(on_test: float, son_test: float, maks_puan: float) -> float:
    """Normalleştirilmiş öğrenme kazancı (%) = (son − ön) / (maks − ön) × 100.

    Standart (madde 7.2) öğrenmenin faaliyetten önce, hemen sonra ve bir süre
    geçtikten sonra ölçülmesini önerir. Bu kazanç, mümkün olan en yüksek
    gelişmenin ne kadarının gerçekleştiğini gösterir.
    """
    if maks_puan <= on_test:
        raise GecersizGirdi("en yüksek puan ön testten büyük olmalı")
    return 100 * (son_test - on_test) / (maks_puan - on_test)


def kalicilik(on_test: float, son_test: float, gecikmeli_test: float):
    """Zaman geçtikten sonra korunan kazanç (%). Kazanç yoksa tanımsızdır."""
    if son_test <= on_test:
        return None
    return 100 * (gecikmeli_test - on_test) / (son_test - on_test)


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar
# ---------------------------------------------------------------------------

@dataclass
class Kategori:
    """Tek bir öğrenme kategorisinin yıllık kaydı."""
    ad: str
    hedef: float = 0      # kategorideki hedef kitle (çalışan)
    katilan: float = 0    # kategoriye katılan tekil çalışan
    saat: float = 0       # kategoride harcanan toplam eğitim saati
    maliyet: float = 0    # kategorinin toplam maliyeti (TL)
    sertifika: float = 0  # sertifika alan çalışan

    @property
    def katilim(self):
        return round(100 * self.katilan / self.hedef, 1) if self.hedef > 0 else None


@dataclass
class EgitimTablosu:
    """Dönemin kategori bazlı eğitim kayıtları ve kurum geneli bilgileri."""
    kategoriler: list = field(default_factory=list)
    toplam_calisan: float = 0
    tekil_katilan: float = 0

    def ekle(self, ad, hedef, katilan, saat, maliyet, sertifika=0):
        self.kategoriler.append(Kategori(ad, hedef, katilan, saat, maliyet, sertifika))
        return self

    def tutarlilik(self) -> list:
        """Tekil katılımcı sayısı ile kategori kayıtları arasındaki çelişkiler."""
        u = []
        kat = [k.katilan for k in self.kategoriler]
        if self.tekil_katilan > self.toplam_calisan:
            u.append("Tekil katılımcı sayısı toplam çalışandan büyük olamaz.")
        if kat and self.tekil_katilan < max(kat):
            u.append("Tekil katılımcı sayısı en kalabalık kategorinin katılımcısından az olamaz.")
        if kat and self.tekil_katilan > sum(kat):
            u.append("Tekil katılımcı sayısı kategori katılımcıları toplamından büyük olamaz.")
        for k in self.kategoriler:
            if k.katilan > k.hedef:
                u.append(f"{k.ad}: katılan, hedef kitleden büyük.")
        return u

    def ozet(self) -> dict:
        saat = sum(k.saat for k in self.kategoriler)
        maliyet = sum(k.maliyet for k in self.kategoriler)
        oranli = [(k.ad, k.katilim) for k in self.kategoriler if k.katilim is not None]
        return {
            "kategori_sayisi": len(self.kategoriler),
            "toplam_calisan": self.toplam_calisan,
            "tekil_katilan": self.tekil_katilan,
            "katilim_orani": round(katilim_orani(self.tekil_katilan, self.toplam_calisan), 1),
            "toplam_saat": saat,
            "toplam_maliyet": maliyet,
            "kisi_basi_saat": round(kisi_basi_saat(saat, self.toplam_calisan), 2),
            "kisi_basi_maliyet": round(kisi_basi_maliyet(maliyet, self.toplam_calisan)),
            "saat_basi_maliyet": round(saat_basi_maliyet(maliyet, saat), 2),
            "en_yuksek_katilim": max(oranli, key=lambda x: x[1]) if oranli else None,
            "en_dusuk_katilim": min(oranli, key=lambda x: x[1]) if oranli else None,
        }


def ornek_tablo() -> EgitimTablosu:
    """Altı kategorilik örnek yıl (uydurma veri)."""
    t = EgitimTablosu(toplam_calisan=1200, tekil_katilan=1056)
    veri = [
        ("Liderlik gelişimi",        120,   84,  1680,  420000,   0),
        ("Mevzuat ve uyum",         1200, 1008,  2016,  151200, 960),
        ("İş sağlığı ve güvenliği",  640,  602,  4816,  361200, 590),
        ("Teknik ve mesleki",        520,  364, 14560, 1092000, 210),
        ("Dijital beceriler",        900,  540,  4320,  324000,   0),
        ("Yeni başlayan uyum",        96,   96,  1536,  115200,   0),
    ]
    for satir in veri:
        t.ekle(*satir)
    return t


def ld_denetimi(ihtiyac_analizi: bool = False,
                ogrenme_ciktisi_tanimli: bool = False,
                uc_noktada_olcum: bool = False,
                gecerli_guvenilir_adil: bool = False,
                maliyet_kapsami_yazili: bool = False,
                kurumsal_sonuca_bagli: bool = False) -> list:
    """Bir L&D raporunun standardın beklentilerine göre eksiklerini listeler.

    Maddeler ISO 30422'nin 5, 7.2 ve 8. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    uyarilar = []
    if not ihtiyac_analizi:
        uyarilar.append("Öğrenme ihtiyacı kurum, takım ve birey düzeyinde belirlenmemiş: "
                        "L&D'nin uygun çözüm olup olmadığı sınanmamış (madde 5).")
    if not ogrenme_ciktisi_tanimli:
        uyarilar.append("Öğrenme çıktısı ve süresi tanımlı değil: başarı neyle "
                        "ölçüleceği belli değil (madde 5).")
    if not uc_noktada_olcum:
        uyarilar.append("Öğrenme faaliyetten önce, hemen sonra ve bir süre sonra "
                        "ölçülmüyor: kalıcılık görünmez (madde 7.2).")
    if not gecerli_guvenilir_adil:
        uyarilar.append("Ölçmenin geçerliliği, güvenilirliği ve adilliği gözden "
                        "geçirilmemiş (madde 7.2).")
    if not maliyet_kapsami_yazili:
        uyarilar.append("Maliyet ve katılım tanımları yazılı değil: bilgi tutarlı "
                        "ve şeffaf sunulamaz (madde 8).")
    if not kurumsal_sonuca_bagli:
        uyarilar.append("Öğrenmenin kurumsal çıktılara (verimlilik, güvenlik, "
                        "bağlılık, elde tutma) katkısı izlenmiyor (madde 8).")
    return uyarilar


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "katilim", "kategori_katilim", "sertifika", "kisi_basi_saat",
    "toplam_maliyet", "kisi_basi_maliyet", "roi", "memnuniyet",
    "yetkinlik", "yetkinlige_sure", "ogrenme_kazanci",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "katilim":
        d = katilim_orani(g["katilan"], g["toplam_calisan"])
        return {"deger": d, "ondalik": 1, "birim": "% katılım",
                "ifade": f"({_g(g['katilan'])} ÷ {_g(g['toplam_calisan'])}) × 100",
                "ayrinti": [["Katılmayan çalışan", g["toplam_calisan"] - g["katilan"]],
                            ["Katılmayan payı (%)", round(100 - d, 1)]]}

    if metrik == "kategori_katilim":
        d = kategori_katilim(g["katilan"], g["hedef_kitle"])
        return {"deger": d, "ondalik": 1, "birim": "% katılım (kategori)",
                "ifade": f"({_g(g['katilan'])} ÷ {_g(g['hedef_kitle'])}) × 100",
                "ayrinti": [["Hedef kitleden katılmayan", g["hedef_kitle"] - g["katilan"]],
                            ["Toplam çalışana oranı (%)",
                             round(katilim_orani(g["katilan"], g["toplam_calisan"]), 1)],
                            ["Hedef kitlenin toplam çalışana oranı (%)",
                             round(katilim_orani(g["hedef_kitle"], g["toplam_calisan"]), 1)]]}

    if metrik == "sertifika":
        d = sertifika_orani(g["sertifikali"], g["hedef_kitle"])
        return {"deger": d, "ondalik": 1, "birim": "% sertifikalı",
                "ifade": f"({_g(g['sertifikali'])} ÷ {_g(g['hedef_kitle'])}) × 100",
                "ayrinti": [["Sertifikasız çalışan", g["hedef_kitle"] - g["sertifikali"]],
                            ["Önceki döneme göre değişim (puan)", round(d - g["onceki_oran"], 1)]]}

    if metrik == "kisi_basi_saat":
        d = kisi_basi_saat(g["toplam_saat"], g["toplam_calisan"])
        katilim_orani(g["katilan"], g["toplam_calisan"])  # tutarlılık denetimi
        return {"deger": d, "ondalik": 1, "birim": "saat / çalışan",
                "ifade": f"{_g(g['toplam_saat'])} ÷ {_g(g['toplam_calisan'])}",
                "ayrinti": [["Katılan başına saat", round(_bol(g["toplam_saat"], g["katilan"], "katılan"), 1)],
                            ["Katılmayan çalışan", g["toplam_calisan"] - g["katilan"]],
                            ["Çalışan başına iş günü karşılığı (8 saat)", round(d / 8, 1)]]}

    if metrik == "toplam_maliyet":
        d = toplam_ld_maliyeti(g["dis_saglayici"], g["ic_kaynak"], g["teknoloji"],
                               g["diger"], g["zaman_maliyeti"])
        kalemler = [g["dis_saglayici"], g["ic_kaynak"], g["teknoloji"], g["diger"],
                    g["zaman_maliyeti"]]
        return {"deger": d, "ondalik": 0, "birim": "TL",
                "ifade": " + ".join(_g(k) for k in kalemler),
                "ayrinti": [["Dış sağlayıcı payı (%)", round(100 * g["dis_saglayici"] / d, 1)],
                            ["İç kaynak payı (%)", round(100 * g["ic_kaynak"] / d, 1)],
                            ["Teknoloji payı (%)", round(100 * g["teknoloji"] / d, 1)]]}

    if metrik == "kisi_basi_maliyet":
        d = kisi_basi_maliyet(g["toplam_maliyet"], g["toplam_calisan"])
        katilim_orani(g["katilan"], g["toplam_calisan"])  # tutarlılık denetimi
        return {"deger": d, "ondalik": 0, "birim": "TL / çalışan",
                "ifade": f"{_g(g['toplam_maliyet'])} ÷ {_g(g['toplam_calisan'])}",
                "ayrinti": [["Katılan başına maliyet (TL)",
                             round(_bol(g["toplam_maliyet"], g["katilan"], "katılan"))],
                            ["Eğitim saati başına maliyet (TL)",
                             round(saat_basi_maliyet(g["toplam_maliyet"], g["toplam_saat"]), 2)],
                            ["Katılmayan çalışan", g["toplam_calisan"] - g["katilan"]]]}

    if metrik == "roi":
        d = yatirim_getirisi(g["fayda"], g["maliyet"])
        return {"deger": d, "ondalik": 1, "birim": "% yatırım getirisi",
                "ifade": f"(({_g(g['fayda'])} − {_g(g['maliyet'])}) ÷ {_g(g['maliyet'])}) × 100",
                "ayrinti": [["Net fayda (TL)", g["fayda"] - g["maliyet"]],
                            ["Fayda / maliyet oranı",
                             round(fayda_maliyet_orani(g["fayda"], g["maliyet"]), 2)],
                            ["Geri ödeme süresi (ay)",
                             round(geri_odeme_ayi(g["fayda"], g["maliyet"], g["fayda_donemi_ay"]), 1)]]}

    if metrik == "memnuniyet":
        d = olumlu_orani(g["olumlu"], g["yanit"])
        if g["olcek_max"] <= 0 or g["ortalama_puan"] < 0 or g["ortalama_puan"] > g["olcek_max"]:
            raise GecersizGirdi("ortalama puan ölçek içinde olmalı")
        return {"deger": d, "ondalik": 1, "birim": "% olumlu",
                "ifade": f"({_g(g['olumlu'])} ÷ {_g(g['yanit'])}) × 100",
                "ayrinti": [["Yanıt oranı (%)", round(yanit_orani(g["yanit"], g["katilan"]), 1)],
                            ["Ortalama puan (ölçek yüzdesi)",
                             round(100 * g["ortalama_puan"] / g["olcek_max"], 1)],
                            ["Olumlu olmayan yanıt", g["yanit"] - g["olumlu"]]]}

    if metrik == "yetkinlik":
        d = ortalama_puan(g["toplam_puan"], g["degerlendirilen"])
        if g["olcek_max"] <= 0 or d > g["olcek_max"]:
            raise GecersizGirdi("ortalama puan ölçek içinde olmalı")
        return {"deger": d, "ondalik": 2, "birim": "puan",
                "ifade": f"{_g(g['toplam_puan'])} ÷ {_g(g['degerlendirilen'])}",
                "ayrinti": [["Önceki döneme göre değişim (puan)", round(d - g["onceki_ort"], 2)],
                            ["Hedefe ulaşma (%)", round(hedefe_ulasma(d, g["hedef_ort"]), 1)],
                            ["Ölçek yüzdesi (%)", round(100 * d / g["olcek_max"], 1)]]}

    if metrik == "yetkinlige_sure":
        d = ortalama_sure(g["toplam_gun"], g["yeni_baslayan"])
        return {"deger": d, "ondalik": 1, "birim": "gün",
                "ifade": f"{_g(g['toplam_gun'])} ÷ {_g(g['yeni_baslayan'])}",
                "ayrinti": [["Hafta karşılığı", round(d / 7, 1)],
                            ["Önceki döneme göre değişim (gün)", round(d - g["onceki_ort"], 1)],
                            ["Değişim (%)",
                             round(100 * (d - g["onceki_ort"]) / _bol(g["onceki_ort"], 1, "önceki"), 1)]]}

    if metrik == "ogrenme_kazanci":
        d = ogrenme_kazanci(g["on_test"], g["son_test"], g["maks_puan"])
        if min(g["on_test"], g["son_test"], g["gecikmeli_test"]) < 0 or \
           max(g["on_test"], g["son_test"], g["gecikmeli_test"]) > g["maks_puan"]:
            raise GecersizGirdi("puanlar 0 ile en yüksek puan arasında olmalı")
        k = kalicilik(g["on_test"], g["son_test"], g["gecikmeli_test"])
        return {"deger": d, "ondalik": 1, "birim": "% normalleştirilmiş kazanç",
                "ifade": f"(({_g(g['son_test'])} − {_g(g['on_test'])}) ÷ "
                         f"({_g(g['maks_puan'])} − {_g(g['on_test'])})) × 100",
                "ayrinti": [["Mutlak kazanç (puan)", g["son_test"] - g["on_test"]],
                            ["Zaman sonra korunan kazanç (%)", "—" if k is None else round(k, 1)],
                            ["Zamanla kaybedilen (puan)", g["son_test"] - g["gecikmeli_test"]]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30422 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Kategori bazlı yıllık kayıt (uydurma örnek veri)")
    print(f"{'Kategori':<26}{'Hedef':>7}{'Katılan':>9}{'%':>7}{'Saat':>8}{'Maliyet TL':>12}")
    for k in t.kategoriler:
        print(f"{k.ad:<26}{k.hedef:>7}{k.katilan:>9}{k.katilim:>7.1f}"
              f"{k.saat:>8}{_tl(k.maliyet):>12}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<20}: {deger}")
    for u in t.tutarlilik():
        print(" !", u)
    print(cizgi)

    print(f"Sertifika oranı (İSG)    : {sertifika_orani(590, 640):.1f} %")
    print(f"Olumlu tepki             : {olumlu_orani(412, 480):.1f} %")
    print(f"Ortalama yetkinlik       : {ortalama_puan(432, 120):.2f} / 5")
    print(f"Yetkinliğe ulaşma süresi : {ortalama_sure(1350, 18):.1f} gün")
    print(f"Öğrenme kazancı          : {ogrenme_kazanci(52, 78, 100):.1f} %"
          f" (kalıcılık {kalicilik(52, 78, 71):.1f} %)")
    print(f"İSG programı ROI         : {yatirim_getirisi(540000, 361200):.1f} %"
          f" (geri ödeme {geri_odeme_ayi(540000, 361200, 12):.1f} ay)")
    print(f"Toplam maliyet kalemleri : {_tl(toplam_ld_maliyeti(1470000, 520000, 290000, 183600))} TL")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("katilim", katilan=1056, toplam_calisan=1200))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in ld_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
