#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30425_metrikler.py
=====================
ISO/TS 30425:2021 (Human resource management — Workforce availability
metrics cluster) çerçevesindeki işgücü bulunabilirliği metriklerinin Python
karşılığı.

Teknik şartname, ISO 30414'ün "işgücü bulunabilirliği" kümesindeki
metrikleri ayrıntılandırır: çalışan sayısı (kadro), tam zaman eşdeğeri
(FTE), koşullu işgücü ve devamsızlık. Her metrik için genel tanım, amaç,
formül ve kullanım biçimini; devamsızlık için ayrıca hedef kullanıcıları,
bağlam ve öngörü etkenlerini verir. İki metrik için açık formül içerir:
FTE (D = A + B/C) ve devamsızlık oranı (A = B/C × 100). Modül üç bölüme
ayrılmıştır:

    1) Kadro ve FTE      — bütçe–fiili kadro, FTE, yarı zamanlı FTE payı
    2) Koşullu işgücü ve devamsızlık — toplam, pay, devamsızlık oranı, değişim
    3) Yardımcı yapılar  — birim tablosu (Tablo 2), denetim, dağıtıcı

Kullanım:
    from iso30425_metrikler import fte, devamsizlik_orani
    fte(100, 1600, 40)            ->  140.0
    devamsizlik_orani(25, 1200)   ->  2.0833...

Doğrudan çalıştırıldığında (python3 iso30425_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30425:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; şartnamenin kendisi telif
korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # kadro ve FTE
    "kadro_sapmasi", "gerceklesme_orani", "fte", "yari_zamanli_fte",
    "yari_zamanli_fte_payi", "goreli_degisim",
    # koşullu işgücü ve devamsızlık
    "kosullu_isgucu", "devamsizlik_orani",
    # yardımcı
    "Birim", "FTETablosu", "ornek_tablo", "erisilebilirlik_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _oran(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


# ---------------------------------------------------------------------------
# 1) Kadro ve tam zaman eşdeğeri (madde 4 ve 5)
# ---------------------------------------------------------------------------

def kadro_sapmasi(fiili: float, butce: float) -> float:
    """Fiili kadro − bütçelenen kadro (kişi). Negatif değer bütçenin altında kalındığını gösterir.

    Şartname, bütçelenen ile fiili kadro arasında artan bir farkın, ilgili alanda çekme
    veya elde tutma sorunu olabileceğine işaret edebileceğini söyler (madde 4.4).
    """
    if fiili < 0 or butce <= 0:
        raise GecersizGirdi("fiili kadro negatif, bütçe sıfır olamaz")
    return fiili - butce


def gerceklesme_orani(fiili: float, butce: float) -> float:
    """Bütçelenen kadroya göre gerçekleşme (%) = fiili / bütçe × 100."""
    return 100 * _bol(fiili, butce, "bütçelenen kadro")


def fte(tam_zamanli: float, yari_saat: float, haftalik_saat: float) -> float:
    """Tam zaman eşdeğeri D = A + (B / C).

    A tam zamanlı çalışan sayısı, B yarı zamanlıların toplam çalışma saati,
    C ortalama haftalık çalışma saatidir (şartname örneğinde 40 saat).
    """
    if tam_zamanli < 0 or yari_saat < 0:
        raise GecersizGirdi("tam zamanlı çalışan ve yarı zamanlı saat negatif olamaz")
    return tam_zamanli + _bol(yari_saat, haftalik_saat, "haftalık çalışma saati")


def yari_zamanli_fte(yari_saat: float, haftalik_saat: float) -> float:
    """Yarı zamanlı çalışanların FTE karşılığı = B / C."""
    return _bol(yari_saat, haftalik_saat, "haftalık çalışma saati")


def yari_zamanli_fte_payi(yari_fte: float, toplam_fte: float) -> float:
    """Toplam FTE içinde yarı zamanlılardan gelen payın yüzdesi (Tablo 3)."""
    return _oran(yari_fte, toplam_fte, "yarı zamanlı FTE")


def goreli_degisim(onceki: float, cari: float) -> float:
    """Göreli değişim (%) = (cari − önceki) / önceki × 100."""
    if onceki <= 0:
        raise GecersizGirdi("önceki değer sıfırdan büyük olmalı")
    if cari < 0:
        raise GecersizGirdi("cari değer negatif olamaz")
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 2) Koşullu işgücü ve devamsızlık (madde 6 ve 7)
# ---------------------------------------------------------------------------

def kosullu_isgucu(serbest: float, kiralik: float) -> float:
    """Toplam koşullu işgücü = bağımsız yükleniciler + kiralık ve ajans işgücü.

    Bağımsız yüklenici (serbest çalışan, danışman) ile geçici işgücü
    (kiralık, geçici/interim, gözetimli çalışan) ISO 30414:2018, 4.7.12.3
    kırılımındadır; şartname toplamı bunların toplamı olarak verir.
    """
    if serbest < 0 or kiralik < 0:
        raise GecersizGirdi("işgücü bileşenleri negatif olamaz")
    return serbest + kiralik


def devamsizlik_orani(devamsiz_gun: float, mevcut_gun: float) -> float:
    """Devamsızlık oranı A = B / C × 100.

    B ölçüm döneminde devamsız geçirilen gün, C çalışılabilir gün sayısıdır.
    Tatil, resmî tatil ve yetkili izin hesaba dahil değildir (madde 7.2).
    """
    return _oran(devamsiz_gun, mevcut_gun, "devamsız gün")


# ---------------------------------------------------------------------------
# 3) Yardımcı yapılar: birim tablosu (Tablo 2)
# ---------------------------------------------------------------------------

@dataclass
class Birim:
    """Tek bir birimin FTE verisi."""
    ad: str
    yari_saat: float = 0      # yarı zamanlıların toplam çalışma saati
    tam: float = 0            # tam zamanlı çalışan

    def fte(self, haftalik_saat: float = 40) -> float:
        return fte(self.tam, self.yari_saat, haftalik_saat)

    def yari_fte(self, haftalik_saat: float = 40) -> float:
        return yari_zamanli_fte(self.yari_saat, haftalik_saat)


@dataclass
class FTETablosu:
    """Birimlere göre FTE hesap tablosu."""
    birimler: list = field(default_factory=list)
    haftalik_saat: float = 40

    def ekle(self, ad, yari_saat, tam) -> "FTETablosu":
        self.birimler.append(Birim(ad, yari_saat, tam))
        return self

    def ozet(self) -> dict:
        h = self.haftalik_saat
        toplam_saat = sum(b.yari_saat for b in self.birimler)
        tam = sum(b.tam for b in self.birimler)
        yari = yari_zamanli_fte(toplam_saat, h)
        toplam = tam + yari
        en_buyuk = max(self.birimler, key=lambda b: b.fte(h))
        return {
            "birim_sayisi": len(self.birimler),
            "yari_zamanli_saat": toplam_saat,
            "yari_zamanli_fte": yari,
            "tam_zamanli": tam,
            "toplam_fte": toplam,
            "yari_fte_payi": round(yari_zamanli_fte_payi(yari, toplam), 2),
            "en_buyuk_birim": (en_buyuk.ad, en_buyuk.fte(h)),
        }


def ornek_tablo() -> FTETablosu:
    """Altı birimlik örnek FTE tablosu (şartnamenin Tablo 2 örneğiyle aynı sayılar)."""
    t = FTETablosu()
    for satir in [
        ("Merkez işlevler ve idare", 1600, 100),
        ("Lojistik",                 2400, 240),
        ("Üretim",                   3600, 410),
        ("Araştırma ve geliştirme",   400,  40),
        ("BT",                        600,  15),
        ("Satış",                       0,  45),
    ]:
        t.ekle(*satir)
    return t


def erisilebilirlik_denetimi(olcum_noktasi_sabit: bool = False,
                             mali_yil_hizali: bool = False,
                             butce_karsilastirmasi: bool = False,
                             gecmis_donem_karsilastirmasi: bool = False,
                             birim_kirilimi: bool = False,
                             devamsizlik_kapsami_yazili: bool = False,
                             baglam_notlari: bool = False) -> list:
    """Bir işgücü bulunabilirliği raporunun eksiklerini listeler.

    Maddeler ISO/TS 30425'in 4.3, 5.3, 6.3 ve 7.3 maddelerindeki beklentilerden
    türetilmiştir; bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (olcum_noktasi_sabit, "Ölçüm noktası (ay sonu, çeyrek sonu, yıl sonu) sabitlenmemiş; seçilen nokta tutarlı uygulanmalı ve yazılmalı."),
        (mali_yil_hizali, "Hesaplama mali yıl, yıllık bütçe döngüsü ya da ikisiyle hizalı değil."),
        (butce_karsilastirmasi, "Fiili ile bütçelenen değerler karşılaştırılmıyor: yönetim için anlama derinliği eksik kalır."),
        (gecmis_donem_karsilastirmasi, "Önceki dönem ve geçmiş yıllarla karşılaştırma yok; tipik aralık üç ila beş yıldır."),
        (birim_kirilimi, "Birim, ekip, bölüm ya da konum kırılımı yok: toplulaştırılmış rakam sorunları gizler."),
        (devamsizlik_kapsami_yazili, "Devamsızlığın kapsamı yazılı değil: tatil, resmî tatil ve yetkili izin hesap dışıdır."),
        (baglam_notlari, "Sayının yanında bağlam ve öngörü etkenleri (yeniden yapılanma, ekonomi, sendika görüşmeleri) yazılmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "fte", "fte_degisim", "kadro_sapma", "kosullu", "devamsizlik", "devamsizlik_degisim",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "fte":
        d = fte(g["tam_zamanli"], g["yari_saat"], g["haftalik_saat"])
        yari = yari_zamanli_fte(g["yari_saat"], g["haftalik_saat"])
        pay = yari_zamanli_fte_payi(yari, d)
        return {"deger": d, "ondalik": 1, "birim": "FTE",
                "ifade": f"{_g(g['tam_zamanli'])} + ({_g(g['yari_saat'])} ÷ {_g(g['haftalik_saat'])})",
                "ayrinti": [["Yarı zamanlıların FTE karşılığı", yari],
                            ["Yarı zamanlı FTE payı (%)", round(pay, 1)],
                            ["Tam zamanlı çalışanın payı (%)", round(100 - pay, 1)]]}

    if metrik == "fte_degisim":
        if g["fte_onceki"] <= 0 or g["fte_cari"] <= 0:
            raise GecersizGirdi("FTE değerleri sıfırdan büyük olmalı")
        po = yari_zamanli_fte_payi(g["yari_fte_onceki"], g["fte_onceki"])
        pc = yari_zamanli_fte_payi(g["yari_fte_cari"], g["fte_cari"])
        return {"deger": pc - po, "ondalik": 2, "birim": "puan (yarı zamanlı FTE payı değişimi)",
                "ifade": f"({_g(g['yari_fte_cari'])} ÷ {_g(g['fte_cari'])} × 100) − "
                         f"({_g(g['yari_fte_onceki'])} ÷ {_g(g['fte_onceki'])} × 100)",
                "ayrinti": [["Önceki dönem yarı zamanlı FTE payı (%)", round(po, 2)],
                            ["Cari dönem yarı zamanlı FTE payı (%)", round(pc, 2)],
                            ["Toplam FTE değişimi (%)", round(goreli_degisim(g["fte_onceki"], g["fte_cari"]), 1)]]}

    if metrik == "kadro_sapma":
        d = kadro_sapmasi(g["fiili"], g["butce"])
        onceki = kadro_sapmasi(g["fiili_onceki"], g["butce_onceki"])
        return {"deger": d, "ondalik": 0, "birim": "kişi (fiili − bütçe)",
                "ifade": f"{_g(g['fiili'])} − {_g(g['butce'])}",
                "ayrinti": [["Bütçelenen kadroya göre gerçekleşme (%)", round(gerceklesme_orani(g["fiili"], g["butce"]), 1)],
                            ["Önceki dönem sapması (kişi)", onceki],
                            ["Sapmanın önceki döneme göre değişimi (kişi)", d - onceki]]}

    if metrik == "kosullu":
        d = kosullu_isgucu(g["serbest"], g["kiralik"])
        if g["onceki_toplam"] <= 0 or g["calisan"] <= 0:
            raise GecersizGirdi("önceki toplam ve çalışan sayısı sıfırdan büyük olmalı")
        return {"deger": d, "ondalik": 0, "birim": "kişi (koşullu işgücü)",
                "ifade": f"{_g(g['serbest'])} + {_g(g['kiralik'])}",
                "ayrinti": [["Bağımsız yüklenici ve danışman payı (%)", round(100 * _bol(g["serbest"], d, "toplam"), 1)],
                            ["Kiralık ve ajans işgücü payı (%)", round(100 * _bol(g["kiralik"], d, "toplam"), 1)],
                            ["Önceki döneme göre değişim (%)", round(goreli_degisim(g["onceki_toplam"], d), 1)],
                            ["Toplam işgücü içindeki payı (%)", round(100 * d / (g["calisan"] + d), 1)]]}

    if metrik == "devamsizlik":
        d = devamsizlik_orani(g["devamsiz_gun"], g["mevcut_gun"])
        return {"deger": d, "ondalik": 2, "birim": "% devamsızlık",
                "ifade": f"{_g(g['devamsiz_gun'])} ÷ {_g(g['mevcut_gun'])} × 100",
                "ayrinti": [["Devamsızlık dışı gün", g["mevcut_gun"] - g["devamsiz_gun"]],
                            ["Bin çalışma gününde devamsız gün", round(10 * d, 1)],
                            ["Çalışılabilir günlerin devamsızlık dışı payı (%)", round(100 - d, 1)]]}

    if metrik == "devamsizlik_degisim":
        d = goreli_degisim(g["onceki_oran"], g["cari_oran"])
        return {"deger": d, "ondalik": 1, "birim": "% göreli değişim",
                "ifade": f"({_g(g['cari_oran'])} − {_g(g['onceki_oran'])}) ÷ {_g(g['onceki_oran'])} × 100",
                "ayrinti": [["Puan farkı", round(g["cari_oran"] - g["onceki_oran"], 2)],
                            ["Cari oranın öncekine katı", round(g["cari_oran"] / g["onceki_oran"], 2)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30425 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Birimlere göre FTE (şartnamenin Tablo 2 sayıları; 40 saat/hafta)")
    print(f"{'Birim':<28}{'Yarı saat':>10}{'Yarı FTE':>10}{'Tam':>6}{'Toplam':>8}")
    for b in t.birimler:
        print(f"{b.ad:<28}{b.yari_saat:>10}{b.yari_fte():>10.0f}{b.tam:>6}{b.fte():>8.0f}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<20}: {deger}")
    print(cizgi)

    print(f"Bütçe–fiili sapma (Ç4)   : {kadro_sapmasi(18487, 18530)} kişi"
          f" (%{gerceklesme_orani(18487, 18530):.1f})")
    print(f"Yarı zamanlı FTE payı    : %{yari_zamanli_fte_payi(215, 1065):.2f} (2016)"
          f" → %{yari_zamanli_fte_payi(428, 1370):.2f} (2018)")
    print(f"Koşullu işgücü           : {kosullu_isgucu(90, 87):.0f} kişi")
    print(f"Devamsızlık (örnek)      : %{devamsizlik_orani(25, 1200):.2f}")
    print(f"Üretim devamsızlığı      : %{goreli_degisim(2.5, 3.8):.0f} artış (2017 → 2020 Ç4)")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("fte", tam_zamanli=100, yari_saat=1600, haftalik_saat=40))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in erisilebilirlik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
