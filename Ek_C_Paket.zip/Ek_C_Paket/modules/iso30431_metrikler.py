#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30431_metrikler.py
=====================
ISO/TS 30431:2021 (Human resource management — Leadership metrics cluster)
çerçevesindeki liderlik metriklerinin Python karşılığı.

Teknik şartname, ISO 30414'ün "liderlik" kümesindeki üç metriği ayrıntılandırır:
liderlik güveni, kontrol alanı (span of control) ve liderlik gelişimi. Açık
formül verdiği iki yer: kontrol alanı (Formül 1 ve 2) ve liderlik gelişimi
(Tablo 4 ve 5'teki yüzde örnekleri). Modül üç bölüme ayrılmıştır:

    1) Liderlik güveni    — boyut puanlarından toplam indeks, Likert → yüzde
    2) Kontrol alanı      — genel yöntem, özel yöntem, astı olmayan yönetici payı
    3) Liderlik gelişimi  — gelişim programı katılımı, eğitim yüzdesi, değişim

Kullanım:
    from iso30431_metrikler import kontrol_alani_genel, kontrol_alani_ozel
    kontrol_alani_genel(10000, 1000)   ->  10.0
    kontrol_alani_ozel(10000, 800)     ->  12.5

Doğrudan çalıştırıldığında (python3 iso30431_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30431:2021'e dayanır.
Boyut puanlarının eşit ağırlıklı ortalaması ve Likert ölçeğinin doğrusal yüzdeye
çevrilmesi şartnamede açıkça tanımlı değildir; bu modülde türetilmiş hesaplardır.
Kod ve açıklamalar özgün olarak yazılmıştır; şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # liderlik güveni
    "guven_endeksi", "likert_yuzde",
    # kontrol alanı
    "kontrol_alani_genel", "kontrol_alani_ozel", "astsiz_yonetici_payi",
    "kontrol_alani_dagilimi",
    # liderlik gelişimi
    "yuzde", "puan_degisim", "goreli_degisim",
    # yardımcı
    "Birim", "LiderlikTablosu", "ornek_tablo", "liderlik_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def yuzde(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


# ---------------------------------------------------------------------------
# 1) Liderlik güveni (madde 4)
# ---------------------------------------------------------------------------

def guven_endeksi(*boyutlar: float) -> float:
    """Boyut puanlarının (0–100) eşit ağırlıklı ortalaması.

    Şartnamenin Tablo 1'inde toplam liderlik güveni endeksi 0–100 ölçeğindedir ve
    adalet, dürüstlük, tutarlılık satırlarının ortalamasıyla uyumludur (2017:
    73, 75, 81 → 76). Ortalamanın formül olarak yazıldığı bir madde yoktur.
    """
    if not boyutlar:
        raise GecersizGirdi("en az bir boyut puanı gerekir")
    for b in boyutlar:
        if b < 0 or b > 100:
            raise GecersizGirdi("boyut puanı 0 ile 100 arasında olmalı")
    return sum(boyutlar) / len(boyutlar)


def likert_yuzde(ortalama: float, alt: float = 1, ust: float = 5) -> float:
    """Likert ortalamasını 0–100 ölçeğine doğrusal çevirir: (x − alt) / (ust − alt) × 100.

    Şartname "1–5 Likert ölçeğinin yüzdeliğe çevrilmesinden" söz eder ama yöntemi
    vermez; doğrusal dönüşüm bu modülün varsayımıdır.
    """
    if ust <= alt:
        raise GecersizGirdi("ölçek üst sınırı alt sınırdan büyük olmalı")
    if ortalama < alt or ortalama > ust:
        raise GecersizGirdi("ortalama ölçek sınırları içinde olmalı")
    return 100 * (ortalama - alt) / (ust - alt)


# ---------------------------------------------------------------------------
# 2) Kontrol alanı (madde 5)
# ---------------------------------------------------------------------------

def kontrol_alani_genel(toplam_isgucu: float, toplam_yonetici: float) -> float:
    """Formül (1): toplam işgücü ÷ toplam yönetici (astı olmayanlar dahil)."""
    return _bol(toplam_isgucu, toplam_yonetici, "toplam yönetici")


def kontrol_alani_ozel(toplam_isgucu: float, ast_olan_yonetici: float) -> float:
    """Formül (2): toplam işgücü ÷ doğrudan astı olan yönetici."""
    return _bol(toplam_isgucu, ast_olan_yonetici, "astı olan yönetici")


def astsiz_yonetici_payi(toplam_yonetici: float, ast_olan_yonetici: float) -> float:
    """Doğrudan astı olmayan yöneticilerin yönetici içindeki yüzdesi (türetilmiş)."""
    if toplam_yonetici <= 0:
        raise GecersizGirdi("toplam yönetici sıfırdan büyük olmalı")
    if ast_olan_yonetici < 0 or ast_olan_yonetici > toplam_yonetici:
        raise GecersizGirdi("astı olan yönetici 0 ile toplam yönetici arasında olmalı")
    return 100 * (toplam_yonetici - ast_olan_yonetici) / toplam_yonetici


def kontrol_alani_dagilimi(ast_olan: float, tek_ast: float, uzeri_10: float, uzeri_30: float) -> dict:
    """Astı olan yöneticiler içinde 1, >10 ve >30 doğrudan astı olanların payı (%).

    Şartname bu üç eşiği örnek olarak ister (5.3.1, 5.3.2); payların yüzde olarak
    hesaplanması türetilmiştir.
    """
    if ast_olan <= 0:
        raise GecersizGirdi("astı olan yönetici sıfırdan büyük olmalı")
    for ad, v in (("tek astı olan", tek_ast), ("10'dan fazla astı olan", uzeri_10),
                  ("30'dan fazla astı olan", uzeri_30)):
        if v < 0 or v > ast_olan:
            raise GecersizGirdi(f"{ad} yönetici 0 ile astı olan yönetici arasında olmalı")
    if uzeri_30 > uzeri_10:
        raise GecersizGirdi("30'dan fazla astı olanlar 10'dan fazla astı olanların alt kümesidir")
    return {"tek": 100 * tek_ast / ast_olan,
            "uzeri_10": 100 * uzeri_10 / ast_olan,
            "uzeri_30": 100 * uzeri_30 / ast_olan}


# ---------------------------------------------------------------------------
# 3) Liderlik gelişimi (madde 6) ve dönemler arası değişim
# ---------------------------------------------------------------------------

def puan_degisim(onceki: float, cari: float) -> float:
    """Cari − önceki (yüzde puanı)."""
    return cari - onceki


def goreli_degisim(onceki: float, cari: float) -> float:
    """(cari − önceki) ÷ önceki × 100."""
    if onceki <= 0:
        raise GecersizGirdi("önceki değer sıfırdan büyük olmalı")
    if cari < 0:
        raise GecersizGirdi("cari değer negatif olamaz")
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar: birim tablosu
# ---------------------------------------------------------------------------

@dataclass
class Birim:
    """İşlevsel grup (birim) bazında liderlik verisi."""
    ad: str
    isgucu: float = 0          # çalışan + koşullu işgücü
    yonetici: float = 0        # toplam yönetici (astı olmayanlar dahil)
    ast_olan: float = 0        # doğrudan astı olan yönetici
    gelisim: float = 0         # liderlik gelişim programına katılan lider
    egitim: float = 0          # eğitim alan lider

    def genel(self) -> float:
        return kontrol_alani_genel(self.isgucu, self.yonetici)

    def ozel(self) -> float:
        return kontrol_alani_ozel(self.isgucu, self.ast_olan)


@dataclass
class LiderlikTablosu:
    """Birimlere göre liderlik tablosu."""
    birimler: list = field(default_factory=list)

    def ekle(self, ad, isgucu, yonetici, ast_olan, gelisim, egitim) -> "LiderlikTablosu":
        self.birimler.append(Birim(ad, isgucu, yonetici, ast_olan, gelisim, egitim))
        return self

    def ozet(self) -> dict:
        isg = sum(b.isgucu for b in self.birimler)
        yon = sum(b.yonetici for b in self.birimler)
        ast = sum(b.ast_olan for b in self.birimler)
        gel = sum(b.gelisim for b in self.birimler)
        egt = sum(b.egitim for b in self.birimler)
        en_genis = max(self.birimler, key=lambda b: b.ozel())
        return {
            "birim_sayisi": len(self.birimler),
            "toplam_isgucu": isg,
            "toplam_yonetici": yon,
            "ast_olan_yonetici": ast,
            "genel_kontrol_alani": kontrol_alani_genel(isg, yon),
            "ozel_kontrol_alani": kontrol_alani_ozel(isg, ast),
            "astsiz_yonetici_payi": round(astsiz_yonetici_payi(yon, ast), 1),
            "gelisim_yuzdesi": round(yuzde(gel, yon, "gelişim"), 1),
            "egitim_yuzdesi": round(yuzde(egt, yon, "eğitim"), 1),
            "en_genis_birim": (en_genis.ad, round(en_genis.ozel(), 1)),
        }


def ornek_tablo() -> LiderlikTablosu:
    """Beş birimlik örnek tablo.

    Toplamlar şartnamenin 2019 örneğine uyar (işgücü 10 000, yönetici 1 000,
    astı olan 800, gelişim 200, eğitim 800); birimlere dağılım bu sayfaya aittir.
    """
    t = LiderlikTablosu()
    for satir in [
        ("Üretim",              5200, 480, 400, 90, 380),
        ("Satış",               1800, 200, 170, 40, 160),
        ("BT",                  1000, 120,  95, 30, 100),
        ("Merkez işlevler",     1200, 150, 100, 25, 120),
        ("Araştırma ve geliştirme", 800, 50, 35, 15,  40),
    ]:
        t.ekle(*satir)
    return t


def liderlik_denetimi(olcum_noktasi_sabit: bool = False,
                      anket_yontemi_yazili: bool = False,
                      iki_yontem_ayri: bool = False,
                      islevsel_kirilim: bool = False,
                      uc_nokta_dagilimi: bool = False,
                      tanimli_donem: bool = False,
                      liderlik_kirilimi: bool = False,
                      baglam_notlari: bool = False) -> list:
    """Bir liderlik raporunun eksiklerini listeler.

    Maddeler ISO/TS 30431'in 4, 5 ve 6. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (olcum_noktasi_sabit, "Ölçüm noktası ve dönemler sabitlenmemiş; karşılaştırma için aynı noktadan ölçün."),
        (anket_yontemi_yazili, "Liderlik güveni için anket yöntemi (toplam skor, Crawford–LePine–Rich ölçeği ya da Likert dönüşümü) yazılı değil."),
        (iki_yontem_ayri, "Genel ve özel kontrol alanı ayrı raporlanmıyor: astı olmayan yöneticiler oranı çarpıtabilir."),
        (islevsel_kirilim, "Kontrol alanı işlevsel gruplara göre ve en yüksek/en düşük değerlerle raporlanmıyor."),
        (uc_nokta_dagilimi, "Tek, 10'dan fazla ve 30'dan fazla astı olan yönetici sayıları verilmemiş."),
        (tanimli_donem, "Liderlik gelişimi için tanımlı bir dönem (ör. takvim yılı) belirtilmemiş."),
        (liderlik_kirilimi, "Liderlik gelişimi düzey, konum, bölüm ve hizmet yılına göre kırılmamış."),
        (baglam_notlari, "Sayının yanında bağlam ve öngörü etkenleri (FTE değişimi, yeniden yapılanma, satın alma) yazılmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "guven_endeks", "likert_yuzde", "kontrol_genel", "kontrol_ozel",
    "kontrol_dagilim", "gelisim", "egitim", "degisim",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "guven_endeks":
        d = guven_endeksi(g["adalet"], g["durustluk"], g["tutarlilik"])
        boy = {"adalet": g["adalet"], "dürüstlük": g["durustluk"], "tutarlılık": g["tutarlilik"]}
        en_dusuk = min(boy, key=lambda k: boy[k])
        en_yuksek = max(boy, key=lambda k: boy[k])
        return {"deger": d, "ondalik": 1, "birim": "puan (0–100 ölçeği)",
                "ifade": f"({_g(g['adalet'])} + {_g(g['durustluk'])} + {_g(g['tutarlilik'])}) ÷ 3",
                "ayrinti": [["Tabloda raporlanan (yuvarlanmış) endeks", int(d + 0.5)],
                            ["En yüksek boyut", f"{en_yuksek} ({_g(boy[en_yuksek])})"],
                            ["En düşük boyut", f"{en_dusuk} ({_g(boy[en_dusuk])})"]]}

    if metrik == "likert_yuzde":
        d = likert_yuzde(g["ortalama"], g["alt"], g["ust"])
        return {"deger": d, "ondalik": 1, "birim": "puan (0–100 ölçeği)",
                "ifade": f"({_g(g['ortalama'])} − {_g(g['alt'])}) ÷ ({_g(g['ust'])} − {_g(g['alt'])}) × 100",
                "ayrinti": [["Ham ortalama", g["ortalama"]],
                            ["Ölçek aralığı", f"{_g(g['alt'])}–{_g(g['ust'])}"]]}

    if metrik == "kontrol_genel":
        d = kontrol_alani_genel(g["toplam_isgucu"], g["toplam_yonetici"])
        if g["toplam_yonetici"] > g["toplam_isgucu"]:
            raise GecersizGirdi("yönetici sayısı toplam işgücünü aşamaz")
        return {"deger": d, "ondalik": 1, "birim": "çalışan / yönetici",
                "ifade": f"{_g(g['toplam_isgucu'])} ÷ {_g(g['toplam_yonetici'])}",
                "ayrinti": [["Yönetici payı (%)", round(100 * g["toplam_yonetici"] / g["toplam_isgucu"], 1)],
                            ["Yönetici başına yönetici olmayan çalışan",
                             round((g["toplam_isgucu"] - g["toplam_yonetici"]) / g["toplam_yonetici"], 1)]]}

    if metrik == "kontrol_ozel":
        d = kontrol_alani_ozel(g["toplam_isgucu"], g["ast_olan"])
        if g["toplam_yonetici"] <= 0 or g["ast_olan"] > g["toplam_yonetici"]:
            raise GecersizGirdi("astı olan yönetici 0 ile toplam yönetici arasında olmalı")
        if g["toplam_yonetici"] > g["toplam_isgucu"]:
            raise GecersizGirdi("yönetici sayısı toplam işgücünü aşamaz")
        return {"deger": d, "ondalik": 1, "birim": "çalışan / astı olan yönetici",
                "ifade": f"{_g(g['toplam_isgucu'])} ÷ {_g(g['ast_olan'])}",
                "ayrinti": [["Genel yöntemle kontrol alanı", round(kontrol_alani_genel(g["toplam_isgucu"], g["toplam_yonetici"]), 1)],
                            ["Astı olmayan yönetici sayısı", g["toplam_yonetici"] - g["ast_olan"]],
                            ["Astı olmayan yönetici payı (%)", round(astsiz_yonetici_payi(g["toplam_yonetici"], g["ast_olan"]), 1)]]}

    if metrik == "kontrol_dagilim":
        p = kontrol_alani_dagilimi(g["ast_olan"], g["tek_ast"], g["uzeri_10"], g["uzeri_30"])
        return {"deger": p["uzeri_10"], "ondalik": 1, "birim": "% (10'dan fazla astı olan yönetici)",
                "ifade": f"{_g(g['uzeri_10'])} ÷ {_g(g['ast_olan'])} × 100",
                "ayrinti": [["Tek astı olan yönetici payı (%)", round(p["tek"], 1)],
                            ["10'dan fazla astı olan yönetici payı (%)", round(p["uzeri_10"], 1)],
                            ["30'dan fazla astı olan yönetici payı (%)", round(p["uzeri_30"], 1)]]}

    if metrik == "gelisim":
        d = yuzde(g["katilan"], g["toplam_lider"], "katılan lider")
        return {"deger": d, "ondalik": 1, "birim": "% (gelişim programına katılan lider)",
                "ifade": f"{_g(g['katilan'])} ÷ {_g(g['toplam_lider'])} × 100",
                "ayrinti": [["Katılmayan lider sayısı", g["toplam_lider"] - g["katilan"]],
                            ["Katılmayan lider payı (%)", round(100 - d, 1)]]}

    if metrik == "egitim":
        d = yuzde(g["egitim_alan"], g["toplam_lider"], "eğitim alan lider")
        return {"deger": d, "ondalik": 1, "birim": "% (eğitim alan lider)",
                "ifade": f"{_g(g['egitim_alan'])} ÷ {_g(g['toplam_lider'])} × 100",
                "ayrinti": [["Eğitim almayan lider sayısı", g["toplam_lider"] - g["egitim_alan"]],
                            ["Eğitim almayan lider payı (%)", round(100 - d, 1)]]}

    if metrik == "degisim":
        d = puan_degisim(g["onceki"], g["cari"])
        return {"deger": d, "ondalik": 1, "birim": "puan",
                "ifade": f"{_g(g['cari'])} − {_g(g['onceki'])}",
                "ayrinti": [["Göreli değişim (%)", round(goreli_degisim(g["onceki"], g["cari"]), 1)],
                            ["Cari değerin öncekine katı", round(g["cari"] / g["onceki"], 2)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30431 — doğrulama çıktısı")
    print(cizgi)

    print("Liderlik güveni (Tablo 1: adalet, dürüstlük, tutarlılık)")
    for yil, b in ((2017, (73, 75, 81)), (2016, (69, 76, 79)), (2015, (65, 73, 77))):
        print(f"  {yil}: {guven_endeksi(*b):.2f}  -> raporlanan {round(guven_endeksi(*b))}")
    print(f"  Likert 4,2 / 5 -> %{likert_yuzde(4.2):.1f}")
    print(cizgi)

    print(f"Genel kontrol alanı (Tablo 2) : {kontrol_alani_genel(10000, 1000):.1f}")
    print(f"Özel kontrol alanı  (Tablo 3) : {kontrol_alani_ozel(10000, 800):.1f}")
    print(f"Astı olmayan yönetici payı    : %{astsiz_yonetici_payi(1000, 800):.1f}")
    print(cizgi)

    print(f"Liderlik gelişimi (Tablo 4)   : 2019 %{yuzde(200, 1000):.1f}, 2018 %{yuzde(250, 1000):.1f}")
    print(f"Liderlik eğitimi  (Tablo 5)   : 2019 %{yuzde(800, 1000):.1f}, 2018 %{yuzde(500, 1000):.1f}")
    print(f"Gelişim değişimi              : {puan_degisim(25.0, 20.0):+.1f} puan"
          f" (göreli %{goreli_degisim(25.0, 20.0):.0f})")
    print(cizgi)

    t = ornek_tablo()
    print("Birimlere göre kontrol alanı (toplamlar Tablo 2–5'in 2019 sayıları)")
    print(f"{'Birim':<26}{'İşgücü':>8}{'Yön.':>6}{'Astlı':>7}{'Genel':>7}{'Özel':>7}")
    for b in t.birimler:
        print(f"{b.ad:<26}{b.isgucu:>8}{b.yonetici:>6}{b.ast_olan:>7}{b.genel():>7.1f}{b.ozel():>7.1f}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<22}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("kontrol_ozel", toplam_isgucu=10000, ast_olan=800, toplam_yonetici=1000))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in liderlik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
