#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30421_metrikler.py
=====================
ISO/TS 30421:2021 (Human resource management — Turnover and retention metrics)
çerçevesindeki hesaplanabilir işgücü devri ve elde tutma metriklerinin Python karşılığı.

Metrikler standardın yapısına göre dört bölümde toplanmıştır:

    1) Devir      (turnover)   — aylık ve yıllık kaba oran, kırılımlar, kritik pozisyon
    2) Maliyet    (cost)       — ayrılma, işe alım ve hıza erişme kalemleri
    3) Elde tutma (retention)  — basit oran, yüksek devirli oran, pozisyon temelli oran
    4) Kıdem      (tenure)     — ortalama kıdem, istikrar oranı, kohort analizi

Kullanım:
    from iso30421_metrikler import aylik_devir, yillik_devir
    aylik_devir(3, 100, 97)   ->  3.045...

Doğrudan çalıştırıldığında (python3 iso30421_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30421:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

__all__ = [
    # devir
    "ortalama_isgucu", "aylik_devir", "yillik_devir", "kaba_yillik_devir",
    "gonullu_pay", "kritik_devir", "uzucu_devir",
    # maliyet
    "ayrilma_maliyeti", "ise_alim_maliyeti", "hiza_erisme_maliyeti",
    "toplam_devir_maliyeti", "ayrilan_basina_maliyet",
    # elde tutma
    "basit_elde_tutma", "yuksek_devirli_elde_tutma", "pozisyon_elde_tutma",
    # kıdem
    "ortalama_kidem", "istikrar_orani", "kohort_elde_tutma",
    # yardımcı
    "Ay", "DevirTablosu", "ornek_tablo", "metrik_denetimi", "hesapla",
    "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Devir metrikleri
# ---------------------------------------------------------------------------

def ortalama_isgucu(ay_basi: float, ay_sonu: float) -> float:
    """Ay içindeki ortalama işgücü: ay başı ve ay sonu mevcudunun ortalaması.

    Payda olarak ay başı ya da ay sonu tek başına da kullanılabilir; ortalama,
    ay içindeki giriş ve çıkışlara daha az duyarlı olduğu için tercih edilir.
    """
    return (ay_basi + ay_sonu) / 2


def aylik_devir(ayrilan: float, ay_basi: float, ay_sonu: float) -> float:
    """Aylık devir oranı (%) = ayrılan sayısı / o ayın ortalama işgücü."""
    return 100 * ayrilan / ortalama_isgucu(ay_basi, ay_sonu)


def yillik_devir(aylik_oranlar: Sequence[float]) -> float:
    """Yıllık devir oranı (%): on iki aylık oranın toplamı.

    Standardın yöntemi budur; her ay kendi paydasına bölünür, sonra oranlar
    toplanır. İşgücü yıl içinde büyük ölçüde değiştiyse bu yöntem, toplam
    ayrılanı yıllık ortalama işgücüne bölen kaba yönteme göre daha doğrudur.
    """
    return float(sum(aylik_oranlar))


def kaba_yillik_devir(toplam_ayrilan: float, ortalama_yillik_isgucu: float) -> float:
    """Kaba yıllık devir oranı (%) = yıl boyunca ayrılan / yıllık ortalama işgücü.

    Karşılaştırma amacıyla verilir; aylık oranların toplamıyla birebir aynı
    sonucu vermez.
    """
    return 100 * toplam_ayrilan / ortalama_yillik_isgucu


def gonullu_pay(gonullu: float, gonulsuz: float) -> float:
    """Gönüllü ayrılmaların toplam ayrılma içindeki payı (%)."""
    return 100 * gonullu / (gonullu + gonulsuz)


def kritik_devir(kritik_ayrilan: float, kritik_ay_basi: float,
                 kritik_ay_sonu: float) -> float:
    """Kritik pozisyonlarda aylık devir oranı (%).

    Kritik pozisyon, kurumsal sonuçlar üzerinde doğrudan ve belirgin etkisi olan
    roldür; üst düzey olması gerekmez.
    """
    return 100 * kritik_ayrilan / ortalama_isgucu(kritik_ay_basi, kritik_ay_sonu)


def uzucu_devir(uzucu_ayrilan: float, toplam_ayrilan: float,
                ortalama_mevcut: float) -> tuple:
    """Üzücü (regrettable) devir: (toplam ayrılma içindeki pay %, işgücüne oran %).

    Üzücü ayrılma, kurumun elde tutmak istediği kişinin gönüllü ayrılmasıdır;
    işlevsiz (dysfunctional) devirle büyük ölçüde örtüşür.
    """
    pay = 100 * uzucu_ayrilan / toplam_ayrilan
    oran = 100 * uzucu_ayrilan / ortalama_mevcut
    return pay, oran


# ---------------------------------------------------------------------------
# 2) Devir maliyeti
# ---------------------------------------------------------------------------

def ayrilma_maliyeti(gorusme_saat: float, gorusmeci_ucret: float,
                     idari_saat: float, idari_ucret: float,
                     odemeler: float) -> float:
    """Ayrılma (leaving) maliyeti: çıkış görüşmesi + idari işlem + ayrılma ödemeleri.

    Gönülsüz ayrılmada kıdem ve ihbar tazminatı ile hukuki giderler bu kalemdedir;
    tipik gönüllü ayrılmada bu ödemeler doğmayabilir.
    """
    return (gorusme_saat * gorusmeci_ucret
            + idari_saat * idari_ucret
            + odemeler)


def ise_alim_maliyeti(ilan: float, idari_saat: float, idari_ucret: float,
                      pozisyon: float, aday_basina: float, mulakatci: float,
                      mulakat_saat: float, mulakatci_ucret: float,
                      degerlendirme_adet: float, degerlendirme_birim: float,
                      diger: float = 0.0) -> float:
    """İşe alım maliyeti: ilan + idari zaman + mülakat zamanı + değerlendirme + diğer.

    "Diğer" kalemi işe başlama primi, seyahat, taşınma ve sağlık kontrolü gibi
    kalemleri toplar. Kadro kapatıldığında (küçültme) bu kalem doğmaz.
    """
    mulakat = pozisyon * aday_basina * mulakatci * mulakat_saat * mulakatci_ucret
    return (ilan + idari_saat * idari_ucret + mulakat
            + degerlendirme_adet * degerlendirme_birim + diger)


def hiza_erisme_maliyeti(ory_saat: float, ory_kisi: float, ory_ucret: float,
                         oturum: float, yeni_calisan: float, kocluk_saat: float,
                         kocluk_ucret: float, egitim_kisi: float,
                         egitim_birim: float) -> float:
    """Hıza erişme (getting-up-to-speed) maliyeti: oryantasyon + koçluk + biçimsel eğitim.

    Yeni çalışanın tam verime ulaşana kadarki verim kaybı bu tutara dâhil
    değildir; dolaylı maliyet olarak ayrıca raporlanır.
    """
    oryantasyon = ory_saat * ory_kisi * ory_ucret * oturum
    kocluk = yeni_calisan * kocluk_saat * kocluk_ucret
    egitim = egitim_kisi * egitim_birim
    return oryantasyon + kocluk + egitim


def toplam_devir_maliyeti(ayrilma: float, ise_alim: float,
                          hiza_erisme: float) -> float:
    """Devir maliyetinin üç ana bileşeninin toplamı."""
    return ayrilma + ise_alim + hiza_erisme


def ayrilan_basina_maliyet(toplam_maliyet: float, ayrilan: float) -> float:
    """Ayrılan kişi başına devir maliyeti."""
    return toplam_maliyet / ayrilan


# ---------------------------------------------------------------------------
# 3) Elde tutma metrikleri
# ---------------------------------------------------------------------------

def basit_elde_tutma(yillik_devir_orani: float) -> float:
    """Basit elde tutma oranı (%) = 100 − yıllık devir oranı.

    Devir yüksekse ya da aynı pozisyon yıl içinde birden çok kez el değiştiriyorsa
    bu ölçü yanıltır; o durumda yuksek_devirli_elde_tutma kullanılır.
    """
    return 100 - yillik_devir_orani


def yuksek_devirli_elde_tutma(donem_basi: float, toplam_ayrilma: float,
                              yeni_calisan_ayrilmasi: float,
                              yeni_alim: float = 0.0) -> float:
    """Yüksek devirli ortamda elde tutma oranı (%).

        (dönem başı mevcut − toplam ayrılma + yıl içinde alınıp ayrılanlar)
        ------------------------------------------------------------------
                        dönem başı mevcut + yeni alım

    Pay, dönem başındaki kadrodan yıl sonunda hâlâ orada olanları verir: yıl
    içinde alınıp yine yıl içinde ayrılanlar toplam ayrılmadan geri eklenir.

    Uyarı: standardın yayımlanmış örneği paydada yalnızca dönem başı mevcudunu
    (100) kullanarak %59 sonucunu verir; formülün yazılı hâliyle (100 + 124)
    sonuç %26,3 olur. Bu tutarsızlık bilinerek raporlanmalı ve kurum içi tanım
    sabitlenmelidir. Varsayılan yeni_alim=0, standardın örnek sonucunu üretir.
    """
    return 100 * (donem_basi - toplam_ayrilma + yeni_calisan_ayrilmasi) \
        / (donem_basi + yeni_alim)


def pozisyon_elde_tutma(korunan_pozisyon: float, toplam_pozisyon: float) -> float:
    """Pozisyon temelli elde tutma oranı (%) = kadro sahibi değişmeyen pozisyonlar.

    Devir oranı ile elde tutma oranı her zaman birbirinin aynası değildir:
    100 pozisyonun üçü yıl içinde defalarca el değiştirirse devir yüksek çıkar,
    pozisyon temelli elde tutma yine de %97 olur.
    """
    return 100 * korunan_pozisyon / toplam_pozisyon


# ---------------------------------------------------------------------------
# 4) Kıdem ve kohort
# ---------------------------------------------------------------------------

def ortalama_kidem(kumulatif_kidem_ay: float, kisi_sayisi: float) -> float:
    """Ortalama kıdem (ay) = bordrodaki kesintisiz kıdemlerin toplamı / kişi sayısı.

    Yılda bir kez, dönem sonunda (M12) ölçülür.
    """
    return kumulatif_kidem_ay / kisi_sayisi


def istikrar_orani(bir_yildan_kidemli: float, bir_yil_once_mevcut: float) -> float:
    """İstikrar oranı (%) = en az bir yıldır çalışanlar / bir yıl önceki mevcut.

    Kişilerin kurumda ne kadar kaldığını gösterir; kaba devir oranının gizlediği
    "dönen kapı" etkisini ortaya çıkarır.
    """
    return 100 * bir_yildan_kidemli / bir_yil_once_mevcut


def kohort_elde_tutma(kohort_buyuklugu: float, kalan: float) -> float:
    """Kohort elde tutma oranı (%): belirli bir grubun dönem sonunda kalan payı.

    Örneğin bir yılın işe alım kohortu, bir programın mezunları ya da bir
    birimin kadrosu izlenebilir.
    """
    return 100 * kalan / kohort_buyuklugu


# ---------------------------------------------------------------------------
# 5) Yardımcı yapılar
# ---------------------------------------------------------------------------

@dataclass
class Ay:
    """Bir ayın devir verisi."""
    ad: str
    gonullu: float = 0.0
    gonulsuz: float = 0.0
    basi: float = 0.0
    sonu: float = 0.0

    @property
    def ayrilan(self) -> float:
        return self.gonullu + self.gonulsuz

    @property
    def ortalama(self) -> float:
        return ortalama_isgucu(self.basi, self.sonu)

    @property
    def oran(self) -> float:
        return aylik_devir(self.ayrilan, self.basi, self.sonu)


@dataclass
class DevirTablosu:
    """On iki aylık devir tablosu; standardın aylık tablo kalıbının karşılığı."""
    aylar: list = field(default_factory=list)

    def ekle(self, ad: str, gonullu: float, gonulsuz: float,
             basi: float, sonu: float) -> "DevirTablosu":
        self.aylar.append(Ay(ad, gonullu, gonulsuz, basi, sonu))
        return self

    @property
    def toplam_ayrilan(self) -> float:
        return sum(a.ayrilan for a in self.aylar)

    @property
    def toplam_gonullu(self) -> float:
        return sum(a.gonullu for a in self.aylar)

    @property
    def yillik_oran(self) -> float:
        return yillik_devir([a.oran for a in self.aylar])

    @property
    def ortalama_mevcut(self) -> float:
        return sum(a.ortalama for a in self.aylar) / len(self.aylar)

    def ozet(self) -> dict:
        gonulsuz = self.toplam_ayrilan - self.toplam_gonullu
        return {
            "yillik_devir": round(self.yillik_oran, 2),
            "kaba_yillik_devir": round(
                kaba_yillik_devir(self.toplam_ayrilan, self.ortalama_mevcut), 2),
            "gonullu_devir": round(yillik_devir(
                [aylik_devir(a.gonullu, a.basi, a.sonu) for a in self.aylar]), 2),
            "gonullu_pay": round(gonullu_pay(self.toplam_gonullu, gonulsuz), 1),
            "basit_elde_tutma": round(basit_elde_tutma(self.yillik_oran), 2),
            "toplam_ayrilan": self.toplam_ayrilan,
            "ortalama_mevcut": round(self.ortalama_mevcut, 1),
        }


def ornek_tablo() -> DevirTablosu:
    """Yüz kişilik bir kurumun on iki aylık örnek devir verisi."""
    t = DevirTablosu()
    veri = [
        ("M1", 1, 2, 100, 97), ("M2", 0, 2, 100, 96), ("M3", 1, 0, 96, 101),
        ("M4", 0, 0, 103, 105), ("M5", 2, 0, 105, 103), ("M6", 1, 0, 103, 101),
        ("M7", 2, 0, 101, 100), ("M8", 1, 2, 100, 98), ("M9", 1, 0, 102, 100),
        ("M10", 1, 1, 100, 106), ("M11", 3, 0, 106, 99), ("M12", 1, 0, 100, 98),
    ]
    for ad, gon, gons, basi, sonu in veri:
        t.ekle(ad, gon, gons, basi, sonu)
    return t


def metrik_denetimi(gonullu_ayristirildi: bool = False,
                    kritik_kirilim: bool = False,
                    maliyet_hesaplandi: bool = False,
                    dolayli_maliyet_dahil: bool = False,
                    ayrilma_nedeni_toplandi: bool = False,
                    kiyaslama_var: bool = False) -> list:
    """Bir devir raporunun eksiklerini listeler.

    Standardın mantığı: tek bir kaba oran karar aldırmaz; oran ancak kırılım,
    maliyet, neden ve kıyaslama ile birlikte yorumlanabilir.
    """
    uyarilar = []
    if not gonullu_ayristirildi:
        uyarilar.append("Gönüllü ve gönülsüz ayrılma ayrıştırılmamış: kaba oran, "
                        "küçültme ile istifayı aynı kefeye koyar.")
    if not kritik_kirilim:
        uyarilar.append("Kritik pozisyon kırılımı yok: toplam oran düşükken bile "
                        "kritik kadrodaki kayıp gizlenebilir.")
    if not maliyet_hesaplandi:
        uyarilar.append("Devir maliyeti hesaplanmamış: üst yönetim desteği "
                        "genellikle oranla değil tutarla alınır.")
    if maliyet_hesaplandi and not dolayli_maliyet_dahil:
        uyarilar.append("Maliyet hesabında verim kaybı (dolaylı maliyet) yok: "
                        "tutar sistematik olarak düşük çıkar.")
    if not ayrilma_nedeni_toplandi:
        uyarilar.append("Ayrılma nedeni toplanmamış: kaçınılabilir ve kaçınılamaz "
                        "ayrılma ayrılamaz, müdahale hedefsiz kalır.")
    if not kiyaslama_var:
        uyarilar.append("İç ya da dış kıyaslama yok: oranın yüksek mi düşük mü "
                        "olduğu söylenemez.")
    return uyarilar


# ---------------------------------------------------------------------------
# 6) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "aylik_devir", "yillik_devir", "gonullu_gonulsuz", "kritik_devir",
    "uzucu_devir", "ayrilma_maliyeti", "ise_alim_maliyeti",
    "hiza_erisme_maliyeti", "toplam_maliyet", "basit_elde_tutma",
    "yuksek_devirli_elde_tutma", "pozisyon_elde_tutma", "ortalama_kidem",
    "istikrar_orani", "kohort",
]


def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "aylik_devir":
        ort = ortalama_isgucu(g["ay_basi"], g["ay_sonu"])
        d = aylik_devir(g["ayrilan"], g["ay_basi"], g["ay_sonu"])
        return {"deger": d, "ondalik": 2, "birim": "% / ay",
                "ifade": f"({g['ayrilan']:g} ÷ {ort:g}) × 100",
                "ayrinti": [["Ayın ortalama işgücü", round(ort, 1)],
                            ["Yıllık eşdeğeri (×12)", round(d * 12, 1)]]}

    if metrik == "yillik_devir":
        d = float(g["oran_toplami"])
        kaba = kaba_yillik_devir(g["toplam_ayrilan"], g["ortalama_mevcut"])
        return {"deger": d, "ondalik": 2, "birim": "% / yıl",
                "ifade": f"Σ aylık oranlar = {d:g}",
                "ayrinti": [["Kaba yöntem (toplam ayrılan ÷ ortalama işgücü)", round(kaba, 2)],
                            ["İki yöntem arasındaki fark (puan)", round(d - kaba, 2)],
                            ["Elde tutma karşılığı (%)", round(basit_elde_tutma(d), 2)]]}

    if metrik == "gonullu_gonulsuz":
        ort = g["ortalama_mevcut"]
        gon = 100 * g["gonullu"] / ort
        gons = 100 * g["gonulsuz"] / ort
        return {"deger": gon, "ondalik": 2, "birim": "% gönüllü devir",
                "ifade": f"({g['gonullu']:g} ÷ {ort:g}) × 100",
                "ayrinti": [["Gönülsüz devir (%)", round(gons, 2)],
                            ["Toplam devir (%)", round(gon + gons, 2)],
                            ["Gönüllünün toplam ayrılmadaki payı (%)",
                             round(gonullu_pay(g["gonullu"], g["gonulsuz"]), 1)]]}

    if metrik == "kritik_devir":
        ort = ortalama_isgucu(g["kritik_basi"], g["kritik_sonu"])
        d = kritik_devir(g["kritik_ayrilan"], g["kritik_basi"], g["kritik_sonu"])
        genel = 100 * g["kritik_ayrilan"] / g["toplam_isgucu"]
        return {"deger": d, "ondalik": 2, "birim": "% / ay (kritik)",
                "ifade": f"({g['kritik_ayrilan']:g} ÷ {ort:g}) × 100",
                "ayrinti": [["Kritik kadronun ortalaması", round(ort, 1)],
                            ["Aynı kayıp, toplam işgücüne göre (%)", round(genel, 2)],
                            ["Kritik kadronun işgücü içindeki payı (%)",
                             round(100 * ort / g["toplam_isgucu"], 1)]]}

    if metrik == "uzucu_devir":
        pay, oran = uzucu_devir(g["uzucu"], g["toplam_ayrilan"], g["ortalama_mevcut"])
        return {"deger": oran, "ondalik": 2, "birim": "% üzücü devir",
                "ifade": f"({g['uzucu']:g} ÷ {g['ortalama_mevcut']:g}) × 100",
                "ayrinti": [["Üzücü ayrılmanın toplam içindeki payı (%)", round(pay, 1)],
                            ["Üzücü olmayan ayrılma", g["toplam_ayrilan"] - g["uzucu"]]]}

    if metrik == "ayrilma_maliyeti":
        t = ayrilma_maliyeti(g["gorusme_saat"], g["gorusmeci_ucret"],
                             g["idari_saat"], g["idari_ucret"], g["odemeler"])
        return {"deger": t, "ondalik": 0, "birim": "TL",
                "ifade": (f"({g['gorusme_saat']:g}×{g['gorusmeci_ucret']:g}) + "
                          f"({g['idari_saat']:g}×{g['idari_ucret']:g}) + {g['odemeler']:g}"),
                "ayrinti": [["Çıkış görüşmesi (TL)", g["gorusme_saat"] * g["gorusmeci_ucret"]],
                            ["İdari işlem (TL)", g["idari_saat"] * g["idari_ucret"]],
                            ["Ayrılma ödemeleri (TL)", g["odemeler"]]]}

    if metrik == "ise_alim_maliyeti":
        mulakat = (g["pozisyon"] * g["aday_basina"] * g["mulakatci"]
                   * g["mulakat_saat"] * g["mulakatci_ucret"])
        t = ise_alim_maliyeti(g["ilan"], g["idari_saat"], g["idari_ucret"],
                              g["pozisyon"], g["aday_basina"], g["mulakatci"],
                              g["mulakat_saat"], g["mulakatci_ucret"],
                              g["degerlendirme_adet"], g["degerlendirme_birim"],
                              g["diger"])
        return {"deger": t, "ondalik": 0, "birim": "TL",
                "ifade": (f"{g['ilan']:g} + ({g['idari_saat']:g}×{g['idari_ucret']:g}) + "
                          f"{mulakat:g} + ({g['degerlendirme_adet']:g}×"
                          f"{g['degerlendirme_birim']:g}) + {g['diger']:g}"),
                "ayrinti": [["Mülakat zamanı (TL)", round(mulakat)],
                            ["İdari zaman (TL)", g["idari_saat"] * g["idari_ucret"]],
                            ["Pozisyon başına işe alım (TL)", round(t / g["pozisyon"])]]}

    if metrik == "hiza_erisme_maliyeti":
        ory = g["ory_saat"] * g["ory_kisi"] * g["ory_ucret"] * g["oturum"]
        koc = g["yeni_calisan"] * g["kocluk_saat"] * g["kocluk_ucret"]
        egt = g["egitim_kisi"] * g["egitim_birim"]
        t = ory + koc + egt
        return {"deger": t, "ondalik": 0, "birim": "TL",
                "ifade": f"{ory:g} + {koc:g} + {egt:g}",
                "ayrinti": [["Oryantasyon (TL)", round(ory)],
                            ["Koçluk ve iş başı destek (TL)", round(koc)],
                            ["Biçimsel eğitim (TL)", round(egt)],
                            ["Yeni çalışan başına (TL)", round(t / g["yeni_calisan"])]]}

    if metrik == "toplam_maliyet":
        t = toplam_devir_maliyeti(g["ayrilma"], g["ise_alim"], g["hiza_erisme"])
        return {"deger": t, "ondalik": 0, "birim": "TL",
                "ifade": f"{g['ayrilma']:g} + {g['ise_alim']:g} + {g['hiza_erisme']:g}",
                "ayrinti": [["Ayrılan başına maliyet (TL)",
                             round(ayrilan_basina_maliyet(t, g["ayrilan"]))],
                            ["Yıllık ücret giderine oranı (%)",
                             round(100 * t / g["yillik_ucret_gideri"], 2)],
                            ["Ayrılma kaleminin payı (%)", round(100 * g["ayrilma"] / t, 1)],
                            ["İşe alım kaleminin payı (%)", round(100 * g["ise_alim"] / t, 1)],
                            ["Hıza erişme kaleminin payı (%)",
                             round(100 * g["hiza_erisme"] / t, 1)]]}

    if metrik == "basit_elde_tutma":
        r = basit_elde_tutma(g["yillik_devir"])
        return {"deger": r, "ondalik": 2, "birim": "%",
                "ifade": f"100 − {g['yillik_devir']:g}",
                "ayrinti": [["Yıllık devir oranı (%)", g["yillik_devir"]],
                            ["Yıl sonunda beklenen kalan (kişi)",
                             round(g["donem_basi"] * r / 100, 1)],
                            ["Yenilenmesi gereken kadro (kişi)",
                             round(g["donem_basi"] * g["yillik_devir"] / 100, 1)]]}

    if metrik == "yuksek_devirli_elde_tutma":
        std = yuksek_devirli_elde_tutma(g["donem_basi"], g["toplam_ayrilma"],
                                        g["yeni_calisan_ayrilmasi"], 0)
        formul = yuksek_devirli_elde_tutma(g["donem_basi"], g["toplam_ayrilma"],
                                           g["yeni_calisan_ayrilmasi"], g["yeni_alim"])
        kalan = g["donem_basi"] - g["toplam_ayrilma"] + g["yeni_calisan_ayrilmasi"]
        return {"deger": std, "ondalik": 1, "birim": "% (dönem başı kadrosu)",
                "ifade": (f"({g['donem_basi']:g} − {g['toplam_ayrilma']:g} + "
                          f"{g['yeni_calisan_ayrilmasi']:g}) ÷ {g['donem_basi']:g} × 100"),
                "ayrinti": [["Dönem başı kadrosundan kalan (kişi)", kalan],
                            ["Paydaya yeni alımlar eklenirse (%)", round(formul, 1)],
                            ["Ayrılmaların kaçı yeni çalışan (%)",
                             round(100 * g["yeni_calisan_ayrilmasi"] / g["toplam_ayrilma"], 1)]]}

    if metrik == "pozisyon_elde_tutma":
        r = pozisyon_elde_tutma(g["korunan_pozisyon"], g["toplam_pozisyon"])
        oynak = g["toplam_pozisyon"] - g["korunan_pozisyon"]
        return {"deger": r, "ondalik": 1, "birim": "% pozisyon",
                "ifade": f"({g['korunan_pozisyon']:g} ÷ {g['toplam_pozisyon']:g}) × 100",
                "ayrinti": [["Oynak pozisyon sayısı", oynak],
                            ["Oynak pozisyon başına devir sayısı",
                             round(g["toplam_ayrilma"] / oynak, 2) if oynak else "—"],
                            ["Kadro temelli devir oranı (%)",
                             round(100 * g["toplam_ayrilma"] / g["toplam_pozisyon"], 1)]]}

    if metrik == "ortalama_kidem":
        ay = ortalama_kidem(g["kumulatif_kidem_ay"], g["kisi_sayisi"])
        return {"deger": ay, "ondalik": 1, "birim": "ay",
                "ifade": f"{g['kumulatif_kidem_ay']:g} ÷ {g['kisi_sayisi']:g}",
                "ayrinti": [["Yıl karşılığı", round(ay / 12, 2)],
                            ["Yıl ve ay olarak",
                             f"{int(ay // 12)} yıl {int(round(ay % 12))} ay"]]}

    if metrik == "istikrar_orani":
        r = istikrar_orani(g["bir_yildan_kidemli"], g["bir_yil_once_mevcut"])
        return {"deger": r, "ondalik": 1, "birim": "% istikrar",
                "ifade": f"({g['bir_yildan_kidemli']:g} ÷ {g['bir_yil_once_mevcut']:g}) × 100",
                "ayrinti": [["Bir yıl içinde ayrılan (kişi)",
                             g["bir_yil_once_mevcut"] - g["bir_yildan_kidemli"]],
                            ["Bugünkü mevcutta kıdemsizlerin payı (%)",
                             round(100 * (g["bugunku_mevcut"] - g["bir_yildan_kidemli"])
                                   / g["bugunku_mevcut"], 1)]]}

    if metrik == "kohort":
        r = kohort_elde_tutma(g["kohort"], g["kalan"])
        return {"deger": r, "ondalik": 1, "birim": "% kohort",
                "ifade": f"({g['kalan']:g} ÷ {g['kohort']:g}) × 100",
                "ayrinti": [["Ayrılan (kişi)", g["kohort"] - g["kalan"]],
                            ["İlk yıl devri (%)",
                             round(100 * (g["kohort"] - g["kalan"]) / g["kohort"], 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 7) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 62
    print("ISO/TS 30421 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Aylık devir tablosu")
    print(f"{'Ay':<5}{'Ayrılan':>9}{'Ortalama':>11}{'Oran %':>9}")
    for a in t.aylar:
        print(f"{a.ad:<5}{a.ayrilan:>9.0f}{a.ortalama:>11.1f}{a.oran:>9.2f}")
    print(cizgi)
    for k, v in t.ozet().items():
        print(f"{k:<20}: {v}")
    print(cizgi)

    print(f"Kritik pozisyon devri : {kritik_devir(3, 35, 32):.2f} % (ay)")
    print(f"Üzücü devir payı      : {uzucu_devir(20, 21, 100)[0]:.1f} %")
    ayr = ayrilma_maliyeti(1, 2500, 0.75, 1200, 15000)
    isa = ise_alim_maliyeti(20000, 1.5, 1200, 1, 4, 3, 1, 3500, 1.5, 4000, 5000)
    hiz = hiza_erisme_maliyeti(7, 3, 1200, 2, 1, 10, 3000, 1, 12000)
    top = toplam_devir_maliyeti(ayr, isa, hiz)
    print(f"Ayrılma maliyeti      : {_tl(ayr)} TL")
    print(f"İşe alım maliyeti     : {_tl(isa)} TL")
    print(f"Hıza erişme maliyeti  : {_tl(hiz)} TL")
    print(f"Kişi başına toplam    : {_tl(top)} TL")
    print(f"20 üzücü ayrılma için : {_tl(top * 20)} TL")
    print(cizgi)

    print(f"Basit elde tutma      : {basit_elde_tutma(t.yillik_oran):.2f} %")
    print(f"Yüksek devirli oran   : {yuksek_devirli_elde_tutma(100, 131, 90):.1f} %")
    print(f"  (payda 100+124 ise) : {yuksek_devirli_elde_tutma(100, 131, 90, 124):.1f} %")
    print(f"Pozisyon temelli oran : {pozisyon_elde_tutma(97, 100):.1f} %")
    ok = ortalama_kidem(14566, 100)
    print(f"Ortalama kıdem        : {ok:.2f} ay ({ok/12:.2f} yıl)")
    print(f"İstikrar oranı        : {istikrar_orani(78, 100):.1f} %")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("basit_elde_tutma", yillik_devir=20.89, donem_basi=100))
    print(cizgi)

    print("Rapor denetimi (hiçbir kırılımı olmayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
