#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30415_metrikler.py
=====================
BS ISO 30415:2021 (Human resource management — Diversity and inclusion) çerçevesindeki
çeşitlilik ve kapsayıcılık (Ç&K) ölçüm örneklerinin ve Ek A öz değerlendirme listesinin
Python karşılığı.

Standart bir rehberdir: her madde için eylemler, "bütünleşik ve bölümlenmiş çeşitlilik
boyutuna göre analiz edilebilecek" ölçü örnekleri ve olası çıktılar verir; formül, eşik
ya da hedef vermez. Bu modüldeki tüm oranlar bu ölçü örneklerini sayıya dökmek için
TÜRETİLMİŞTİR. Modül üç bölüme ayrılmıştır:

    1) Ölçüler    — katılım, olumlu yanıt, temsil, geçiş (etki) oranı, ücret farkı, kabul,
                    ayrılma, şikâyet, yedekleme, tedarikçi çeşitliliği
    2) Yapılar    — Ek A öz değerlendirme tablosu, grup (segment) tablosu, ön koşul denetimi
    3) Dağıtıcı   — hesaplayıcının kullandığı tek giriş noktası

Kullanım:
    from iso30415_metrikler import temsil_endeksi, gecis_orani
    temsil_endeksi(30, 200, 48)            ->  31.25
    gecis_orani(18, 60, 40, 100)           ->  0.75

Doğrudan çalıştırıldığında (python3 iso30415_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Kavramlar ve ölçü örnekleri ISO 30415:2021'e dayanır. Oranlar, endeksler, kapsama
puanlaması ve denetim kuralları bu modülde türetilmiştir. Kod ve açıklamalar özgün olarak
yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi", "ALANLAR",
    "katilim_orani", "olumlu_oran", "temsil_endeksi", "gecis_orani", "ucret_farki",
    "kabul_orani", "ayrilma_orani", "sikayet_orani", "yedekleme", "tedarikci_cesitliligi", "kapsama",
    "Alan", "OzDegerlendirme", "ornek_tablo", "Grup", "GrupTablosu", "ornek_gruplar",
    "on_kosul_denetimi", "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, negatif değer, parça bütünü aşıyor vb."""


# Ek A (Tablo A.1): her madde için eylem sayısı (standarttaki "organizations should" eylemleri)
ALANLAR = [
    ("5.2", "Kurumsal yönetişim", 4),
    ("5.3", "Kurumsal liderlik", 8),
    ("5.4", "Devredilen Ç&K sorumlulukları", 15),
    ("5.5", "Bireysel sorumluluklar", 4),
    ("6", "Ç&K çerçevesi", 13),
    ("7", "Kapsayıcı kültür", 11),
    ("8.2", "İşgücü planlaması", 7),
    ("8.3", "Ücretlendirme", 9),
    ("8.4", "İşe alım", 14),
    ("8.5", "İşe başlama", 10),
    ("8.6", "Öğrenme ve gelişim", 11),
    ("8.7", "Performans yönetimi", 12),
    ("8.8", "Yedekleme planlaması", 9),
    ("8.9", "İşgücü hareketliliği", 11),
    ("8.10", "İstihdamın sona ermesi", 11),
    ("9", "Ürün ve hizmetler", 9),
    ("10", "Tedarik ve tedarik zinciri", 9),
    ("11", "Dış paydaş ilişkileri", 10),
]


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


def _parca(parca: float, butun: float, ad: str) -> None:
    if parca > butun:
        raise GecersizGirdi(f"{ad} bütünü aşamaz")


# ---------------------------------------------------------------------------
# 1) Ölçüler (madde 6.3, 7.3, 8.2.3–8.10.3, 9.3, 10.3)
# ---------------------------------------------------------------------------

def katilim_orani(katilan: float, hedef_kitle: float) -> float:
    """Katılım, paylaşım ya da tamamlama oranı: katılan ÷ hedef kitle × 100 (%)."""
    _negatif_yok(katilan=katilan)
    _parca(katilan, hedef_kitle, "katılan sayısı hedef kitleyi")
    return 100 * _bol(katilan, hedef_kitle, "hedef kitle")


def olumlu_oran(olumlu: float, yanit: float) -> float:
    """Olumlu yanıt oranı (ör. 'değerli hissediyorum'): olumlu ÷ yanıt × 100 (%)."""
    _negatif_yok(olumlu=olumlu)
    _parca(olumlu, yanit, "olumlu yanıt sayısı toplam yanıtı")
    return 100 * _bol(olumlu, yanit, "toplam yanıt")


def temsil_endeksi(grup: float, toplam: float, ref_pay: float) -> float:
    """Temsil endeksi: gruptaki işgücü payı ÷ referans nüfus payı × 100 (100 = eşit temsil)."""
    _negatif_yok(grup=grup, ref_pay=ref_pay)
    _parca(grup, toplam, "grup kadrosu toplam kadroyu")
    if ref_pay > 100:
        raise GecersizGirdi("referans pay yüzde 100'ü aşamaz")
    return 100 * _bol(grup / _pozitif(toplam, "toplam kadro"), ref_pay / 100, "referans pay")


def _pozitif(x: float, ad: str) -> float:
    if x <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return x


def gecis_orani(grup_gecen: float, grup_basvuran: float, ref_gecen: float, ref_basvuran: float) -> float:
    """Etki (geçiş) oranı: grubun aşama geçiş oranı ÷ referans grubun aşama geçiş oranı."""
    _negatif_yok(grup_gecen=grup_gecen, ref_gecen=ref_gecen)
    _parca(grup_gecen, grup_basvuran, "geçen sayısı başvuran sayısını")
    _parca(ref_gecen, ref_basvuran, "referans geçen sayısı referans başvuranı")
    g = _bol(grup_gecen, grup_basvuran, "grup başvuran sayısı")
    r = _bol(ref_gecen, ref_basvuran, "referans başvuran sayısı")
    return _bol(g, r, "referans geçiş oranı")


def ucret_farki(ref_ort: float, grup_ort: float) -> float:
    """Ücret farkı (%): (referans ortalama − grup ortalaması) ÷ referans ortalama × 100."""
    _negatif_yok(grup_ort=grup_ort)
    return 100 * _bol(ref_ort - grup_ort, ref_ort, "referans ortalama ücret")


def kabul_orani(teklif: float, kabul: float) -> float:
    """Teklif ya da görevlendirme kabul oranı: kabul ÷ teklif × 100 (%)."""
    _negatif_yok(kabul=kabul)
    _parca(kabul, teklif, "kabul sayısı teklif sayısını")
    return 100 * _bol(kabul, teklif, "teklif sayısı")


def ayrilma_orani(ayrilan: float, kadro: float) -> float:
    """Ayrılma (devir) oranı: ayrılan ÷ ortalama kadro × 100 (%)."""
    _negatif_yok(ayrilan=ayrilan)
    return 100 * _bol(ayrilan, kadro, "ortalama kadro")


def sikayet_orani(sikayet: float, calisan: float) -> float:
    """Her 1000 çalışan için şikâyet, olay ya da iddia sayısı."""
    _negatif_yok(sikayet=sikayet)
    return 1000 * _bol(sikayet, calisan, "çalışan sayısı")


def yedekleme(kadro: float, aday: float, yerlesen: float) -> dict:
    """Yedek adayı payı, yerleştirilen payı ve adaylardan yerleştirilen payı (%)."""
    _negatif_yok(aday=aday, yerlesen=yerlesen)
    _parca(aday, kadro, "yedek adayı sayısı kadroyu")
    _parca(yerlesen, aday, "yerleştirilen sayısı aday sayısını")
    return {"aday_payi": 100 * _bol(aday, kadro, "kadro"),
            "yerlesen_payi": 100 * yerlesen / kadro,
            "adaydan_yerlesen": 100 * _bol(yerlesen, aday, "yedek adayı sayısı")}


def tedarikci_cesitliligi(ayrik_harcama: float, toplam_harcama: float) -> float:
    """Temsil edilmeyen gruplara ait işletmelere yapılan harcamanın toplam harcamadaki payı (%)."""
    _negatif_yok(ayrik_harcama=ayrik_harcama)
    _parca(ayrik_harcama, toplam_harcama, "ayrılan harcama toplam harcamayı")
    return 100 * _bol(ayrik_harcama, toplam_harcama, "toplam harcama")


def kapsama(toplam: float, uygulanan: float, kismen: float = 0) -> float:
    """Eylemlerin uygulama kapsaması (%): (uygulanan + 0,5 × kısmen) ÷ toplam × 100."""
    _negatif_yok(uygulanan=uygulanan, kismen=kismen)
    if uygulanan + kismen > toplam:
        raise GecersizGirdi("uygulanan ve kısmen uygulanan toplamı eylem sayısını aşamaz")
    return 100 * _bol(uygulanan + 0.5 * kismen, toplam, "eylem sayısı")


# ---------------------------------------------------------------------------
# 2) Yapılar: Ek A öz değerlendirme tablosu, grup tablosu, ön koşul denetimi
# ---------------------------------------------------------------------------

@dataclass
class Alan:
    """Ek A'daki bir madde için öz değerlendirme satırı."""
    kod: str
    ad: str
    toplam: int
    uygulanan: float = 0
    kismen: float = 0

    def kapsama(self) -> float:
        return kapsama(self.toplam, self.uygulanan, self.kismen)


@dataclass
class OzDegerlendirme:
    """Tablo A.1 öz değerlendirme tablosu. Hedef kapsama kurumca belirlenir (varsayılan %70)."""
    alanlar: list = field(default_factory=lambda: [Alan(k, a, n) for k, a, n in ALANLAR])
    hedef: float = 70.0

    def gir(self, kod: str, uygulanan: float, kismen: float = 0) -> "OzDegerlendirme":
        for a in self.alanlar:
            if a.kod == kod:
                a.uygulanan, a.kismen = uygulanan, kismen
                a.kapsama()  # doğrulama
                return self
        raise GecersizGirdi(f"bilinmeyen madde: {kod}")

    def ozet(self) -> dict:
        toplam = sum(a.toplam for a in self.alanlar)
        uyg = sum(a.uygulanan for a in self.alanlar)
        kis = sum(a.kismen for a in self.alanlar)
        oranlar = [(a.kapsama(), a.kod) for a in self.alanlar]
        en_zayif = oranlar[0]
        for o in oranlar[1:]:
            if o[0] < en_zayif[0]:
                en_zayif = o
        return {
            "alan_sayisi": len(self.alanlar),
            "toplam_eylem": toplam,
            "genel_kapsama": round(kapsama(toplam, uyg, kis), 1),
            "hedef_alti": [k for o, k in oranlar if o < self.hedef],
            "en_zayif": en_zayif[1],
        }


def ornek_tablo() -> OzDegerlendirme:
    """Örnek amaçlı doldurulmuş tablo (standart bu sayıları vermez)."""
    t = OzDegerlendirme()
    for kod, u, k in [("5.2", 3, 1), ("5.3", 5, 2), ("5.4", 8, 4), ("5.5", 3, 1), ("6", 8, 3), ("7", 6, 3),
                      ("8.2", 3, 2), ("8.3", 5, 2), ("8.4", 7, 4), ("8.5", 5, 3), ("8.6", 6, 3), ("8.7", 6, 3),
                      ("8.8", 3, 3), ("8.9", 4, 3), ("8.10", 5, 3), ("9", 4, 2), ("10", 3, 2), ("11", 4, 3)]:
        t.gir(kod, u, k)
    return t


@dataclass
class Grup:
    """Bir çeşitlilik boyutundaki grup (ör. kadın/erkek, yaş bandı). İlk grup referans alınır."""
    ad: str
    kadro: float
    ref_pay: float
    basvuran: float
    secilen: float
    ort_ucret: float
    ayrilan: float


@dataclass
class GrupTablosu:
    """Gruplara göre temsil, geçiş, ücret ve ayrılma karşılaştırması (ilk satır referans)."""
    gruplar: list = field(default_factory=list)

    def ekle(self, ad, kadro, ref_pay, basvuran, secilen, ort_ucret, ayrilan) -> "GrupTablosu":
        self.gruplar.append(Grup(ad, kadro, ref_pay, basvuran, secilen, ort_ucret, ayrilan))
        return self

    def ozet(self) -> dict:
        toplam = sum(g.kadro for g in self.gruplar)
        ref = self.gruplar[0]
        satirlar = {}
        for g in self.gruplar:
            satirlar[g.ad] = {
                "temsil": round(temsil_endeksi(g.kadro, toplam, g.ref_pay), 1),
                "gecis": round(gecis_orani(g.secilen, g.basvuran, ref.secilen, ref.basvuran), 2),
                "ucret_farki": round(ucret_farki(ref.ort_ucret, g.ort_ucret), 1),
                "ayrilma": round(ayrilma_orani(g.ayrilan, g.kadro), 1),
            }
        return {"referans": ref.ad, "toplam_kadro": toplam, "gruplar": satirlar}


def ornek_gruplar() -> GrupTablosu:
    """Örnek amaçlı üç grup (standart bu sayıları vermez)."""
    t = GrupTablosu()
    t.ekle("Grup A (referans)", 120, 50, 100, 30, 5000, 12)
    t.ekle("Grup B", 70, 48, 90, 18, 4600, 9)
    t.ekle("Grup C", 10, 2, 10, 2, 4900, 2)
    return t


def on_kosul_denetimi(cesitliligi_taniyor: bool = False,
                      etkin_yonetisim: bool = False,
                      hesap_verebilir_davraniyor: bool = False,
                      kapsayici_calisiyor: bool = False,
                      kapsayici_iletisim: bool = False,
                      savunuculuk_yapiyor: bool = False) -> list:
    """Madde 4'teki altı ön koşula göre eksikleri listeler (hazırlık kontrol listesi, uygunluk sınaması değil)."""
    kontroller = [
        (cesitliligi_taniyor, "Çeşitliliğin tanınması: tüm insanlar bireysel ve grup olarak değerli sayılmıyor, boyutların kesişimi gözetilmiyor."),
        (etkin_yonetisim, "Etkin yönetişim: liderlik taahhüdü kapsayıcı yönetişim sistemleri, politika ve uygulamalarla gösterilmiyor."),
        (hesap_verebilir_davraniyor, "Hesap verebilir davranış: etik, sosyal sorumlu ve herkes için insana yakışır işi destekleyen yaklaşım yok."),
        (kapsayici_calisiyor, "Kapsayıcı çalışma: erişilebilir ve saygılı, aidiyet duygusunu besleyen çalışma ortamı sağlanmıyor."),
        (kapsayici_iletisim, "Kapsayıcı iletişim: iletişime farklı biçimlerde erişen ve onu farklı anlayan insanların ihtiyaçları karşılanmıyor."),
        (savunuculuk_yapiyor, "Savunuculuk: kapsayıcı uygulamaları ve paydaş ilişkilerini etkin biçimde teşvik eden bir çaba yok."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 3) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["katilim", "olumlu", "temsil", "gecis", "ucret", "kabul",
                  "devir", "sikayet", "yedek", "tedarik", "kapsama"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "katilim":
        d = katilim_orani(g["katilan"], g["hedef_kitle"])
        return {"deger": d, "ondalik": 1, "birim": "% (katılan ÷ hedef kitle)",
                "ifade": f"{_g(g['katilan'])} ÷ {_g(g['hedef_kitle'])} × 100",
                "ayrinti": [["Katılmayan", round(g["hedef_kitle"] - g["katilan"], 2)],
                            ["Katılmayanların payı (%)", round(100 - d, 1)]]}

    if metrik == "olumlu":
        d = olumlu_oran(g["olumlu"], g["yanit"])
        return {"deger": d, "ondalik": 1, "birim": "% (olumlu ÷ yanıt)",
                "ifade": f"{_g(g['olumlu'])} ÷ {_g(g['yanit'])} × 100",
                "ayrinti": [["Olumlu olmayan yanıt", round(g["yanit"] - g["olumlu"], 2)],
                            ["Olumlu olmayanların payı (%)", round(100 - d, 1)]]}

    if metrik == "temsil":
        d = temsil_endeksi(g["grup"], g["toplam"], g["ref_pay"])
        pay = 100 * g["grup"] / g["toplam"]
        return {"deger": d, "ondalik": 1, "birim": "endeks (100 = eşit temsil)",
                "ifade": f"({_g(g['grup'])} ÷ {_g(g['toplam'])}) ÷ ({_g(g['ref_pay'])} ÷ 100) × 100",
                "ayrinti": [["Gruptaki işgücü payı (%)", round(pay, 1)],
                            ["Referans paya göre fark (puan)", round(pay - g["ref_pay"], 1)]]}

    if metrik == "gecis":
        d = gecis_orani(g["grup_gecen"], g["grup_basvuran"], g["ref_gecen"], g["ref_basvuran"])
        return {"deger": d, "ondalik": 2, "birim": "oran (grup ÷ referans)",
                "ifade": f"({_g(g['grup_gecen'])} ÷ {_g(g['grup_basvuran'])}) ÷ ({_g(g['ref_gecen'])} ÷ {_g(g['ref_basvuran'])})",
                "ayrinti": [["Grubun geçiş oranı (%)", round(100 * g["grup_gecen"] / g["grup_basvuran"], 1)],
                            ["Referansın geçiş oranı (%)", round(100 * g["ref_gecen"] / g["ref_basvuran"], 1)]]}

    if metrik == "ucret":
        d = ucret_farki(g["ref_ort"], g["grup_ort"])
        return {"deger": d, "ondalik": 1, "birim": "% (referansa göre fark)",
                "ifade": f"({_g(g['ref_ort'])} − {_g(g['grup_ort'])}) ÷ {_g(g['ref_ort'])} × 100",
                "ayrinti": [["Mutlak fark", round(g["ref_ort"] - g["grup_ort"], 2)],
                            ["Grup ücreti / referans ücret (%)", round(100 * g["grup_ort"] / g["ref_ort"], 1)]]}

    if metrik == "kabul":
        d = kabul_orani(g["teklif"], g["kabul"])
        return {"deger": d, "ondalik": 1, "birim": "% (kabul ÷ teklif)",
                "ifade": f"{_g(g['kabul'])} ÷ {_g(g['teklif'])} × 100",
                "ayrinti": [["Kabul edilmeyen teklif", round(g["teklif"] - g["kabul"], 2)]]}

    if metrik == "devir":
        d = ayrilma_orani(g["ayrilan"], g["kadro"])
        return {"deger": d, "ondalik": 1, "birim": "% (ayrılan ÷ kadro)",
                "ifade": f"{_g(g['ayrilan'])} ÷ {_g(g['kadro'])} × 100",
                "ayrinti": [["Referans orana göre (kat)", round(_bol(d, g["ref_oran"], "referans oran"), 2)]]}

    if metrik == "sikayet":
        d = sikayet_orani(g["sikayet"], g["calisan"])
        return {"deger": d, "ondalik": 1, "birim": "her 1000 çalışan için",
                "ifade": f"{_g(g['sikayet'])} ÷ {_g(g['calisan'])} × 1000",
                "ayrinti": [["Çalışan başına yüzde", round(100 * g["sikayet"] / g["calisan"], 2)]]}

    if metrik == "yedek":
        h = yedekleme(g["kadro"], g["aday"], g["yerlesen"])
        return {"deger": h["aday_payi"], "ondalik": 1, "birim": "% (yedek adayı ÷ kadro)",
                "ifade": f"{_g(g['aday'])} ÷ {_g(g['kadro'])} × 100",
                "ayrinti": [["Yerleştirilenlerin kadroya payı (%)", round(h["yerlesen_payi"], 1)],
                            ["Adaylardan yerleştirilen (%)", round(h["adaydan_yerlesen"], 1)]]}

    if metrik == "tedarik":
        d = tedarikci_cesitliligi(g["ayrik_harcama"], g["toplam_harcama"])
        return {"deger": d, "ondalik": 1, "birim": "% (ayrılan harcama ÷ toplam)",
                "ifade": f"{_g(g['ayrik_harcama'])} ÷ {_g(g['toplam_harcama'])} × 100",
                "ayrinti": [["Diğer harcama", round(g["toplam_harcama"] - g["ayrik_harcama"], 2)]]}

    if metrik == "kapsama":
        d = kapsama(g["toplam"], g["uygulanan"], g["kismen"])
        return {"deger": d, "ondalik": 1, "birim": "% (kapsama)",
                "ifade": f"({_g(g['uygulanan'])} + 0,5 × {_g(g['kismen'])}) ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Hiç uygulanmayan eylem", round(g["toplam"] - g["uygulanan"] - g["kismen"], 2)],
                            ["Yalnızca tam uygulananların payı (%)", round(100 * g["uygulanan"] / g["toplam"], 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 4) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30415 — doğrulama çıktısı")
    print(cizgi)
    print(f"Paylaşım (360/600)       : %{katilim_orani(360, 600):.1f}")
    print(f"Değerli hissedenler      : %{olumlu_oran(310, 420):.1f}")
    print(f"Temsil endeksi (30/200)  : {temsil_endeksi(30, 200, 48):.1f}")
    print(f"Etki oranı               : {gecis_orani(18, 60, 40, 100):.2f}")
    print(f"Ücret farkı              : %{ucret_farki(5000, 4600):.1f}")
    print(f"Teklif kabulü (40/50)    : %{kabul_orani(50, 40):.1f}")
    print(f"Ayrılma                  : %{ayrilma_orani(9, 70):.1f}")
    print(f"Şikâyet (6/600)          : {sikayet_orani(6, 600):.1f} / 1000")
    print(f"Yedekleme                : {yedekleme(600, 60, 24)}")
    print(f"Tedarikçi çeşitliliği    : %{tedarikci_cesitliligi(1.2, 12):.1f}")
    print(f"Kapsama (13, 8, 3)       : %{kapsama(13, 8, 3):.1f}")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<14}: {deger}")
    print(cizgi)
    for anahtar, deger in ornek_gruplar().ozet().items():
        print(f"{anahtar:<14}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("katilim", katilan=360, hedef_kitle=600))
    print(cizgi)

    print("Ön koşul denetimi (hiçbirini sağlamayan bir kurum için):")
    for u in on_kosul_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
