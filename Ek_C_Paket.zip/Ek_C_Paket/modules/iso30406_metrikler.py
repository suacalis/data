#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30406_metrikler.py
=====================
ISO/TR 30406:2017 (Human resource management — Sustainable employability
management for organizations) için kendi kendini değerlendirme araçları.

Teknik rapor, formül ya da metrik tanımlamaz; kurumların sürdürülebilir
istihdam edilebilirlik politikasını geliştirmesi ve uygulaması için yol gösterici
ilkeler, üç faktör kümesi (20 faktör) ve bir uygulama süreci (Ek A) verir.
Kurumun 'mevcut' ve 'istenen' durumunu Tablo A.1'deki dört fazla (tepkisel,
planlı, proaktif, bütünleşik) belirleyip öncelik vermesi önerilir. Bu modül,
o değerlendirmeyi sayıya döker. Fazların 1–4 sayısal karşılığı, açık, ilerleme,
öncelik puanı ve küme ortalaması şartnamede yoktur; hepsi bu modülde türetilmiştir.

    1) Fazlar ve açık   — faz adları, mevcut–istenen açığı, ilerleme
    2) Öncelik ve küme  — öncelik puanı, küme ortalaması, madde uygulama yüzdesi
    3) Yapılar          — 20 faktörlü değerlendirme tablosu, denetim, dağıtıcı

Kullanım:
    from iso30406_metrikler import faz_acigi, oncelik_puani
    faz_acigi(2, 4)         ->  2
    oncelik_puani(2, 3)     ->  6

Doğrudan çalıştırıldığında (python3 iso30406_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Faktör adları ve kümeler ISO/TR 30406:2017'ye dayanır. Kod ve açıklamalar
özgün olarak yazılmıştır; teknik raporun kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi", "FAZLAR", "KUMELER", "FAKTORLER",
    "faz_adi", "faz_acigi", "ilerleme_yuzde", "oncelik_puani",
    "kume_ortalamasi", "uygulama_yuzdesi", "yanit_orani",
    "Faktor", "DegerlendirmeTablosu", "ornek_tablo", "uygulama_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: faz ölçek dışında, payda sıfır vb."""


FAZLAR = ["Tepkisel", "Planlı", "Proaktif", "Bütünleşik"]   # Tablo A.1: reactive, planned, proactive, integral
KUMELER = {1: "Politikaya bütünleştirme", 2: "İş yetkinlikleri, içerik, karmaşıklık, ilişkiler ve koşullar", 3: "Canlılık ve sağlık"}

# (küme, madde, ad)
FAKTORLER = [
    (1, "6.2", "Misyon / vizyon / sürdürülebilir istihdam edilebilirlik hedefleri"),
    (1, "6.3", "Liderlik"),
    (1, "6.4", "Sahiplenme"),
    (1, "6.5", "İşgücü planlaması"),
    (1, "6.6", "Uygulama"),
    (1, "6.7", "İletişim"),
    (1, "6.8", "Kültür"),
    (2, "7.2", "İşgücü yetkinlikleriyle ilgili vizyon ve politika"),
    (2, "7.3", "İş içeriği"),
    (2, "7.4", "Karmaşıklık"),
    (2, "7.5", "Beceri gelişimi"),
    (2, "7.6", "İşyeri ilişkileri"),
    (2, "7.7", "Çalışma koşulları"),
    (3, "8.2", "Sağlık yönetimi"),
    (3, "8.3", "Sağlıklı ve güvenli çalışma ortamı"),
    (3, "8.4", "Sağlıklı yaşam biçimleri"),
    (3, "8.5", "Fiziksel sağlık"),
    (3, "8.6", "Ruh sağlığı"),
    (3, "8.7", "İyi oluş (well-being)"),
    (3, "8.8", "İş–yaşam dengesi (bakım rolleri / kendine bakım)"),
]


def _faz_kontrol(deger: float, ad: str = "faz") -> None:
    if deger < 1 or deger > 4:
        raise GecersizGirdi(f"{ad} 1 (tepkisel) ile 4 (bütünleşik) arasında olmalı")


def faz_adi(deger: float) -> str:
    """1–4 arası fazın adı (en yakın tamsayıya yuvarlanır)."""
    _faz_kontrol(deger)
    return FAZLAR[int(deger + 0.5) - 1]


# ---------------------------------------------------------------------------
# 1) Fazlar ve açık
# ---------------------------------------------------------------------------

def faz_acigi(mevcut: float, istenen: float) -> float:
    """İstenen − mevcut faz (adım): pozitif değer, hedefe ulaşmak için gereken ilerlemeyi gösterir."""
    _faz_kontrol(mevcut, "mevcut faz")
    _faz_kontrol(istenen, "istenen faz")
    return istenen - mevcut


def ilerleme_yuzde(mevcut: float, istenen: float) -> float:
    """Mevcut ÷ istenen × 100: hedef faza göre ulaşılan düzey (türetilmiş)."""
    _faz_kontrol(mevcut, "mevcut faz")
    _faz_kontrol(istenen, "istenen faz")
    return 100 * mevcut / istenen


# ---------------------------------------------------------------------------
# 2) Öncelik, küme ve uygulama
# ---------------------------------------------------------------------------

def oncelik_puani(acik: float, oncelik: float) -> float:
    """Açık × öncelik ağırlığı (1 düşük, 2 orta, 3 yüksek): sıralama için basit bir puan (türetilmiş)."""
    if oncelik < 1 or oncelik > 3:
        raise GecersizGirdi("öncelik 1 (düşük) ile 3 (yüksek) arasında olmalı")
    if acik < 0:
        raise GecersizGirdi("açık negatif olamaz")
    return acik * oncelik


def kume_ortalamasi(toplam_faz: float, faktor_sayisi: float) -> float:
    """Bir kümedeki faktörlerin faz ortalaması (1–4)."""
    if faktor_sayisi <= 0:
        raise GecersizGirdi("faktör sayısı sıfırdan büyük olmalı")
    ort = toplam_faz / faktor_sayisi
    _faz_kontrol(ort, "ortalama faz")
    return ort


def uygulama_yuzdesi(uygulanan: float, toplam: float) -> float:
    """Bir madde (ör. 6.3) altındaki ifadelerden uygulananların yüzdesi (türetilmiş)."""
    if toplam <= 0:
        raise GecersizGirdi("toplam ifade sayısı sıfırdan büyük olmalı")
    if uygulanan < 0 or uygulanan > toplam:
        raise GecersizGirdi("uygulanan 0 ile toplam arasında olmalı")
    return 100 * uygulanan / toplam


def yanit_orani(davetli: float, yanit: float) -> float:
    """Ek A.3: anket yanıt oranı (%) = yanıt ÷ davetli × 100 (çalışma grubu yanıt oranını izler)."""
    if davetli <= 0:
        raise GecersizGirdi("davetli sayısı sıfırdan büyük olmalı")
    if yanit < 0 or yanit > davetli:
        raise GecersizGirdi("yanıt sayısı 0 ile davetli sayısı arasında olmalı")
    return 100 * yanit / davetli


# ---------------------------------------------------------------------------
# 3) Yapılar: değerlendirme tablosu (Tablo A.1 modeli)
# ---------------------------------------------------------------------------

@dataclass
class Faktor:
    """Tek bir faktörün mevcut/istenen fazı ve önceliği."""
    kume: int
    madde: str
    ad: str
    mevcut: float | None = None
    istenen: float | None = None
    oncelik: float | None = None

    def acik(self) -> float:
        return faz_acigi(self.mevcut, self.istenen)

    def puan(self) -> float:
        return oncelik_puani(max(self.acik(), 0), self.oncelik)


@dataclass
class DegerlendirmeTablosu:
    """20 faktörlü değerlendirme tablosu."""
    faktorler: list = field(default_factory=lambda: [Faktor(k, m, a) for k, m, a in FAKTORLER])

    def ata(self, madde: str, mevcut: float, istenen: float, oncelik: float) -> "DegerlendirmeTablosu":
        for f in self.faktorler:
            if f.madde == madde:
                _faz_kontrol(mevcut, "mevcut faz"); _faz_kontrol(istenen, "istenen faz")
                f.mevcut, f.istenen, f.oncelik = mevcut, istenen, oncelik
                return self
        raise GecersizGirdi(f"bilinmeyen madde: {madde}")

    def ozet(self) -> dict:
        dolu = [f for f in self.faktorler if f.mevcut is not None and f.istenen is not None]
        if not dolu:
            raise GecersizGirdi("en az bir faktör değerlendirilmeli")
        out = {"degerlendirilen": len(dolu)}
        for k in (1, 2, 3):
            kd = [f for f in dolu if f.kume == k]
            if kd:
                out[f"kume{k}_mevcut"] = round(kume_ortalamasi(sum(f.mevcut for f in kd), len(kd)), 2)
                out[f"kume{k}_istenen"] = round(kume_ortalamasi(sum(f.istenen for f in kd), len(kd)), 2)
        oncelikli = sorted((f for f in dolu if f.oncelik), key=lambda f: -f.puan())[:3]
        out["ilk_oncelikler"] = [(f.madde, f.ad, f.puan()) for f in oncelikli]
        return out


def ornek_tablo() -> DegerlendirmeTablosu:
    """Örnek amaçlı değerlendirme (teknik rapor sayı vermez): çoğu faktör 'planlı', hedef 'proaktif'."""
    t = DegerlendirmeTablosu()
    ornek = {"6.2": (2, 3, 2), "6.3": (2, 4, 3), "6.5": (2, 3, 3), "7.5": (3, 4, 2), "8.6": (1, 3, 3), "8.3": (3, 3, 1)}
    for f in t.faktorler:
        m, i, o = ornek.get(f.madde, (2, 3, 1))
        t.ata(f.madde, m, i, o)
    return t


def uygulama_denetimi(onem_belirlendi: bool = False,
                      mevcut_durum_olculdu: bool = False,
                      fark_belirlendi: bool = False,
                      iyilestirme_dongusu: bool = False,
                      calisma_grubu_var: bool = False,
                      iletisim_plani_var: bool = False,
                      pilot_yapildi: bool = False,
                      paydas_toplantisi_yapildi: bool = False) -> list:
    """Bir uygulamanın eksiklerini listeler.

    Maddeler ISO/TR 30406'nın 5. maddesindeki dört adımdan ve Ek A süreçlerinden
    türetilmiştir; bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (onem_belirlendi, "Adım 1: faktörlerin kurum için önemi belirlenmemiş (sektöre ve kuruma göre değişir)."),
        (mevcut_durum_olculdu, "Adım 2: faktörlerin uygulanma düzeyi (mevcut durum) ölçülmemiş."),
        (fark_belirlendi, "Adım 3: mevcut durum ile istenen durum arasındaki fark belirlenmemiş."),
        (iyilestirme_dongusu, "Adım 4: sürekli iyileştirme döngüsü kurulmamış; sorun odaklı yönetimden sistematik yaklaşıma geçilmemiş."),
        (calisma_grubu_var, "Ek A.2: sürdürülebilir istihdam edilebilirlik çalışma grubu kurulmamış."),
        (iletisim_plani_var, "Ek A.2: iletişim planı ve bölüm şampiyonları belirlenmemiş."),
        (pilot_yapildi, "Ek A.2: faktörleri ve ek unsurları sınamak için pilot uygulama yapılmamış."),
        (paydas_toplantisi_yapildi, "Ek A.5: paydaşlarla sonuçları tartışan ve öncelikleri uzlaştıran toplantı yapılmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["acik", "oncelik", "kume", "uygulama", "yanit"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "acik":
        d = faz_acigi(g["mevcut"], g["istenen"])
        return {"deger": d, "ondalik": 1, "birim": "faz adımı (istenen − mevcut)",
                "ifade": f"{_g(g['istenen'])} − {_g(g['mevcut'])}",
                "ayrinti": [["Mevcut faz", faz_adi(g["mevcut"])],
                            ["İstenen faz", faz_adi(g["istenen"])],
                            ["İlerleme (mevcut ÷ istenen, %)", round(ilerleme_yuzde(g["mevcut"], g["istenen"]), 1)]]}

    if metrik == "oncelik":
        a = faz_acigi(g["mevcut"], g["istenen"])
        d = oncelik_puani(max(a, 0), g["oncelik"])
        return {"deger": d, "ondalik": 1, "birim": "öncelik puanı (açık × ağırlık)",
                "ifade": f"maks({_g(g['istenen'])} − {_g(g['mevcut'])}, 0) × {_g(g['oncelik'])}",
                "ayrinti": [["Faz açığı", a],
                            ["En yüksek olası puan (açık 3 × ağırlık 3)", 9]]}

    if metrik == "kume":
        d = kume_ortalamasi(g["toplam_faz"], g["faktor_sayisi"])
        return {"deger": d, "ondalik": 2, "birim": "ortalama faz (1–4)",
                "ifade": f"{_g(g['toplam_faz'])} ÷ {_g(g['faktor_sayisi'])}",
                "ayrinti": [["En yakın faz", faz_adi(d)],
                            ["Bütünleşik faza uzaklık (adım)", round(4 - d, 2)]]}

    if metrik == "uygulama":
        d = uygulama_yuzdesi(g["uygulanan"], g["toplam"])
        return {"deger": d, "ondalik": 1, "birim": "% (uygulanan ifade)",
                "ifade": f"{_g(g['uygulanan'])} ÷ {_g(g['toplam'])} × 100",
                "ayrinti": [["Uygulanmayan ifade sayısı", g["toplam"] - g["uygulanan"]],
                            ["Uygulanmayan pay (%)", round(100 - d, 1)]]}

    if metrik == "yanit":
        d = yanit_orani(g["davetli"], g["yanit"])
        return {"deger": d, "ondalik": 1, "birim": "% (yanıt oranı)",
                "ifade": f"{_g(g['yanit'])} ÷ {_g(g['davetli'])} × 100",
                "ayrinti": [["Yanıt vermeyen sayısı", g["davetli"] - g["yanit"]],
                            ["Yanıt vermeyen pay (%)", round(100 - d, 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TR 30406 — doğrulama çıktısı")
    print(cizgi)

    print("Fazlar: " + " → ".join(f"{i + 1}={f}" for i, f in enumerate(FAZLAR)))
    print(f"Açık (mevcut 2, istenen 4)  : {faz_acigi(2, 4)} adım, ilerleme %{ilerleme_yuzde(2, 4):.0f}")
    print(f"Öncelik puanı (açık 2, yüksek): {oncelik_puani(2, 3)}")
    print(f"Anket yanıt oranı (84/120)  : %{yanit_orani(120, 84):.0f}")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<18}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("acik", mevcut=2, istenen=4))
    print(cizgi)

    print("Uygulama denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in uygulama_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
