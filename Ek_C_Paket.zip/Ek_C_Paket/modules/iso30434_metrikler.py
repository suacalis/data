#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30434_metrikler.py
=====================
ISO 30434:2023 (Human resource management — Workforce allocation) çerçevesindeki
işgücü tahsisi doğrulama ve sistem ölçümlerinin Python karşılığı.

Standart, işin çalışanlara tahsisini dört adımda (hazırla, ata, bilgilendir, yanıtla)
tanımlar. Atama adımında tahmin edilen sonuçların hedef sonuçlar için kabul
edilebilir toleranslar içinde olduğu doğrulanır (7.6.2.4):
  - iş teslim edilecek mi?      toplam talep ile toplam tahsis edilen işin karşılaştırılması
  - çalışanlar kullanılacak mı? toplam tahsis edilen iş ile toplam kapasitenin karşılaştırılması
  - iş yükü aşırı mı?           tahsis edilen iş ile çalışanın uygunluğunun karşılaştırılması
Madde 8 beş sistem ölçümü örneği verir. Standart bu karşılaştırmaların yüzde
formülünü tanımlamaz; oranlar bu modülde türetilmiştir. Modül üç bölüme ayrılmıştır:

    1) Doğrulama    — teslimat, kullanım, iş yükü, hedef farkı, tolerans sapması
    2) Kapasite ve ölçümler — kapasite, plan uyumu, plan performansı, tahmin doğruluğu, geçmiş kullanım
    3) Yapılar      — birim tablosu, önleyici eylem önerileri (Tablo B.1), denetim, dağıtıcı

Kullanım:
    from iso30434_metrikler import kullanim_orani, hedef_farki
    kullanim_orani(68, 100)      ->  68.0
    hedef_farki(68, 85)          ->  -17.0

Doğrudan çalıştırıldığında (python3 iso30434_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Standardın terimleri ve kavramları ISO 30434:2023'e dayanır. Oranlar,
tolerans eşleştirmesi ve önleyici eylem önerisi kuralları bu modülde türetilmiştir.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi", "ONLEYICI_EYLEMLER",
    "teslimat_orani", "kullanim_orani", "is_yuku_orani", "hedef_farki", "tolerans_sapmasi",
    "kapasite", "plan_uyumu", "plan_performansi", "tahmin_orani", "tahmin_hatasi", "gecmis_kullanim",
    "onleyici_eylemler", "Birim", "TahsisTablosu", "ornek_tablo", "tahsis_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, negatif değer, tolerans aralığı ters vb."""


# Tablo B.1: olası önleyici eylemler (numaralar standarttaki gibi)
ONLEYICI_EYLEMLER = {
    1: "Fazla tahsis edilen çalışanlardan eksik tahsis edilenlere işi yeniden dağıt",
    2: "İşi kişiler arasında böl (birden fazla kişi, resmî iş paylaşımı)",
    3: "Tahsis edilen çalışma saatlerini artır (fazla mesai sınırları içinde)",
    4: "Tahsis edilen çalışma saatlerini azalt (kullanım hedefleri içinde)",
    5: "İşi ve çalışanları birimler arasında paylaş ya da kaydır (geçici iç transfer vb.)",
    6: "Toplam talebi azalt (işgücü planlaması türü eylem)",
    7: "Kapasiteyi artır ve yeni çalışan ata: işe al ya da sözleşmeli çalıştır (işgücü planlaması türü)",
    8: "Toplam talebi artır ve kullanılmayan çalışanları ata (işgücü planlaması türü)",
    9: "Kapasiteyi azalt: izin ya da işten çıkarma, yüklenici kullanımını durdur (işgücü planlaması türü)",
}


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


# ---------------------------------------------------------------------------
# 1) Doğrulama (madde 7.6.2.4, 5.10)
# ---------------------------------------------------------------------------

def teslimat_orani(talep: float, tahsis: float) -> float:
    """İş teslim edilecek mi: tahsis edilen iş ÷ toplam talep × 100 (%)."""
    _negatif_yok(tahsis=tahsis)
    return 100 * _bol(tahsis, talep, "toplam talep")


def kullanim_orani(tahsis: float, kapasite_toplam: float) -> float:
    """Çalışanlar kullanılacak mı: tahsis edilen iş ÷ toplam kapasite × 100 (%)."""
    _negatif_yok(tahsis=tahsis)
    return 100 * _bol(tahsis, kapasite_toplam, "toplam kapasite")


def is_yuku_orani(tahsis: float, uygunluk: float) -> float:
    """İş yükü aşırı mı: bir çalışana tahsis edilen iş ÷ çalışanın uygunluğu × 100 (%)."""
    _negatif_yok(tahsis=tahsis)
    return 100 * _bol(tahsis, uygunluk, "çalışanın uygunluğu")


def hedef_farki(tahmin: float, hedef: float) -> float:
    """Tahmin − hedef (yüzde puanı): negatif değer hedefin altında kalındığını gösterir.

    Standart örneği: tahmin edilen kullanım %68, hedef kullanım %85 → istenmeyen sonuç.
    """
    _negatif_yok(tahmin=tahmin, hedef=hedef)
    return tahmin - hedef


def tolerans_sapmasi(tahmin: float, alt: float, ust: float) -> float:
    """Tahminin tolerans aralığının dışına çıkma miktarı: aralık içindeyse 0, altında negatif, üstünde pozitif."""
    if alt > ust:
        raise GecersizGirdi("tolerans alt sınırı üst sınırdan büyük olamaz")
    _negatif_yok(tahmin=tahmin, alt=alt)
    if tahmin < alt:
        return tahmin - alt
    if tahmin > ust:
        return tahmin - ust
    return 0.0


# ---------------------------------------------------------------------------
# 2) Kapasite ve sistem ölçümleri (madde 7.6.1.5 ve 8)
# ---------------------------------------------------------------------------

def kapasite(kisi: float, saat: float, izin: float, ek: float) -> dict:
    """Düzenli ve ek kapasite (saat): düzenli = kişi × (sözleşme saati − planlı izin); ek = kişi × ek uygunluk."""
    _negatif_yok(kisi=kisi, saat=saat, izin=izin, ek=ek)
    if izin > saat:
        raise GecersizGirdi("planlı izin sözleşme saatini aşamaz")
    duzenli = kisi * (saat - izin)
    ek_kap = kisi * ek
    return {"duzenli": duzenli, "ek": ek_kap, "toplam": duzenli + ek_kap}


def plan_uyumu(uretken_sure: float, tahsisli_uretken_sure: float) -> float:
    """Schedule adherence: işyerinde geçirilen üretken süre ÷ toplam tahsis edilen üretken süre × 100."""
    _negatif_yok(uretken_sure=uretken_sure)
    return 100 * _bol(uretken_sure, tahsisli_uretken_sure, "tahsis edilen üretken süre")


def plan_performansi(calisma_ortaminda: float, atanan_sure: float) -> float:
    """Schedule performance: çalışma ortamında geçirilen toplam süre ÷ atanan ya da planlanan süre × 100."""
    _negatif_yok(calisma_ortaminda=calisma_ortaminda)
    return 100 * _bol(calisma_ortaminda, atanan_sure, "atanan süre")


def tahmin_orani(tahmin: float, gercek: float) -> float:
    """Forecast demand accuracy: tahmin edilen talep ÷ fiilen çalışılan süre × 100 (100 = tam isabet)."""
    _negatif_yok(tahmin=tahmin)
    return 100 * _bol(tahmin, gercek, "fiilen çalışılan süre")


def tahmin_hatasi(tahmin: float, gercek: float) -> float:
    """Mutlak yüzde hata: |tahmin − gerçek| ÷ gerçek × 100 (türetilmiş)."""
    _negatif_yok(tahmin=tahmin)
    return 100 * abs(tahmin - gercek) / _pozitif(gercek, "fiilen çalışılan süre")


def _pozitif(x: float, ad: str) -> float:
    if x <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return x


def gecmis_kullanim(fiili: float, kapasite_toplam: float) -> float:
    """Past utilization: fiilen çalışılan süre ÷ çalışanların kapasitesi × 100."""
    _negatif_yok(fiili=fiili)
    return 100 * _bol(fiili, kapasite_toplam, "kapasite")


# ---------------------------------------------------------------------------
# 3) Yapılar: birim tablosu ve önleyici eylemler (Tablo B.1)
# ---------------------------------------------------------------------------

def onleyici_eylemler(teslimat: float, kullanim: float, yuk: float | None, tol: dict) -> list:
    """Tolerans dışı sonuçlara Tablo B.1'den eylem numarası önerir (türetilmiş kural).

    tol: {"teslimat": (alt, ust), "kullanim": (alt, ust), "yuk": ust}
    - teslimat alt sınırın altında (eksik tahsis / işçi açığı): 3, 5, sonra 7 ve 6
    - kullanım alt sınırın altında (işçi fazlası):             4, 5, sonra 8 ve 9
    - iş yükü üst sınırın üstünde (aşırı yüklü çalışan):       1, 2
    """
    out = []
    if teslimat < tol["teslimat"][0]:
        out += [3, 5, 7, 6]
    if kullanim < tol["kullanim"][0]:
        out += [4, 5, 8, 9]
    if yuk is not None and yuk > tol["yuk"]:
        out += [1, 2]
    sirali = []
    for n in out:
        if n not in sirali:
            sirali.append(n)
    return sirali


@dataclass
class Birim:
    """Bir tahsis birimi (rol ve konum)."""
    ad: str
    talep: float
    tahsis: float
    kapasite: float
    en_yuklu_tahsis: float | None = None
    en_yuklu_uygunluk: float | None = None

    def teslimat(self) -> float:
        return teslimat_orani(self.talep, self.tahsis)

    def kullanim(self) -> float:
        return kullanim_orani(self.tahsis, self.kapasite)

    def yuk(self) -> float | None:
        if self.en_yuklu_tahsis is None or self.en_yuklu_uygunluk is None:
            return None
        return is_yuku_orani(self.en_yuklu_tahsis, self.en_yuklu_uygunluk)


@dataclass
class TahsisTablosu:
    """Birimlere göre doğrulama tablosu; tolerans varsayılanları Ek C.3 örneğindendir."""
    birimler: list = field(default_factory=list)
    tol: dict = field(default_factory=lambda: {"teslimat": (95, 110), "kullanim": (80, 120), "yuk": 120})

    def ekle(self, ad, talep, tahsis, kapasite, en_yuklu_tahsis=None, en_yuklu_uygunluk=None) -> "TahsisTablosu":
        _negatif_yok(talep=talep, tahsis=tahsis, kapasite=kapasite)
        self.birimler.append(Birim(ad, talep, tahsis, kapasite, en_yuklu_tahsis, en_yuklu_uygunluk))
        return self

    def ozet(self) -> dict:
        talep = sum(b.talep for b in self.birimler)
        tahsis = sum(b.tahsis for b in self.birimler)
        kap = sum(b.kapasite for b in self.birimler)
        out = {
            "birim_sayisi": len(self.birimler),
            "toplam_talep": talep, "toplam_tahsis": tahsis, "toplam_kapasite": kap,
            "teslimat": round(teslimat_orani(talep, tahsis), 1),
            "kullanim": round(kullanim_orani(tahsis, kap), 1),
        }
        eylem = {}
        for b in self.birimler:
            e = onleyici_eylemler(b.teslimat(), b.kullanim(), b.yuk(), self.tol)
            if e:
                eylem[b.ad] = e
        out["onleyici_eylemler"] = eylem
        return out


def ornek_tablo() -> TahsisTablosu:
    """Örnek amaçlı üç birim (standart bu sayıları vermez); toleranslar Ek C.3'ten."""
    t = TahsisTablosu()
    t.ekle("Birim A (rol/konum)", 1200, 1100, 1100, 46, 40)
    t.ekle("Birim B", 700, 700, 1000, 38, 40)
    t.ekle("Birim C", 600, 620, 640, 40, 40)
    return t


def tahsis_denetimi(cerceve_belgeli: bool = False,
                    birimler_ve_havuzlar_tanimli: bool = False,
                    asama_ufuk_donem_belgeli: bool = False,
                    hedef_sonuc_tolerans_yazili: bool = False,
                    dogrulama_yapiliyor: bool = False,
                    onleyici_eylemler_belgeli: bool = False,
                    bilgilendirme_ve_yanit_surec_var: bool = False,
                    sistem_olcumleri_var: bool = False) -> list:
    """Bir tahsis sürecinin eksiklerini listeler.

    Maddeler ISO 30434'ün 6–10. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (cerceve_belgeli, "Sorumluluk, hesap verebilirlik, kaynak, liderlik, şeffaflık, iletişim ve sürekli iyileştirmeyi içeren tahsis çerçevesi (madde 6) belgelenmemiş."),
        (birimler_ve_havuzlar_tanimli, "Her işgücü için birimler ve havuzlar (madde 7.2–7.3) tanımlı değil."),
        (asama_ufuk_donem_belgeli, "Tahsis aşamaları, adımları, dönemi ve ufku (madde 7.4) ufku en uzundan en kısaya doğru belgelenmemiş."),
        (hedef_sonuc_tolerans_yazili, "Hedef sonuçlar ve tolerans aralıkları (madde 5.10) yazılı değil."),
        (dogrulama_yapiliyor, "Teslimat, kullanım ve iş yükü doğrulaması (madde 7.6.2.4) dönem dönem yapılmıyor."),
        (onleyici_eylemler_belgeli, "Önleyici eylemler ve uzlaşma kabulü süreçleri (madde 7.6.2.5–7.6.2.6) belgelenmemiş."),
        (bilgilendirme_ve_yanit_surec_var, "Bilgilendirme ufku ve çalışan yanıtı (kabul, ret, sorgu) süreci (madde 7.6.3–7.6.4) tanımlı değil."),
        (sistem_olcumleri_var, "Tahsis sisteminin geçmiş performansı için ölçümler (madde 8) belgelenmemiş."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["teslimat", "kullanim", "is_yuku", "hedef_fark", "tolerans", "kapasite",
                  "plan_uyumu", "plan_performansi", "tahmin", "gecmis"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "teslimat":
        d = teslimat_orani(g["talep"], g["tahsis"])
        return {"deger": d, "ondalik": 1, "birim": "% (tahsis ÷ talep)",
                "ifade": f"{_g(g['tahsis'])} ÷ {_g(g['talep'])} × 100",
                "ayrinti": [["Karşılanmayan talep", round(g["talep"] - g["tahsis"], 2)],
                            ["Talebe göre fark (puan)", round(d - 100, 1)]]}

    if metrik == "kullanim":
        d = kullanim_orani(g["tahsis"], g["kapasite"])
        return {"deger": d, "ondalik": 1, "birim": "% (tahsis ÷ kapasite)",
                "ifade": f"{_g(g['tahsis'])} ÷ {_g(g['kapasite'])} × 100",
                "ayrinti": [["Kullanılmayan kapasite", round(g["kapasite"] - g["tahsis"], 2)],
                            ["Kapasiteye göre fark (puan)", round(d - 100, 1)]]}

    if metrik == "is_yuku":
        d = is_yuku_orani(g["tahsis"], g["uygunluk"])
        return {"deger": d, "ondalik": 1, "birim": "% (tahsis ÷ uygunluk)",
                "ifade": f"{_g(g['tahsis'])} ÷ {_g(g['uygunluk'])} × 100",
                "ayrinti": [["Uygunluğun üstünde (+) ya da altında (−) saat", round(g["tahsis"] - g["uygunluk"], 2)]]}

    if metrik == "hedef_fark":
        d = hedef_farki(g["tahmin"], g["hedef"])
        return {"deger": d, "ondalik": 1, "birim": "puan (tahmin − hedef)",
                "ifade": f"{_g(g['tahmin'])} − {_g(g['hedef'])}",
                "ayrinti": [["Hedefe göre oran", round(_bol(g["tahmin"], g["hedef"], "hedef"), 3)],
                            ["Hedefin yüzdesi olarak (%)", round(100 * g["tahmin"] / g["hedef"], 1)]]}

    if metrik == "tolerans":
        d = tolerans_sapmasi(g["tahmin"], g["alt"], g["ust"])
        durum = "aralık içinde" if d == 0 else ("aralığın altında" if d < 0 else "aralığın üstünde")
        return {"deger": d, "ondalik": 1, "birim": "puan (aralık dışı sapma)",
                "ifade": f"{_g(g['tahmin'])} ile [{_g(g['alt'])}, {_g(g['ust'])}] aralığı",
                "ayrinti": [["Durum", durum],
                            ["Aralık genişliği", round(g["ust"] - g["alt"], 2)]]}

    if metrik == "kapasite":
        k = kapasite(g["kisi"], g["saat"], g["izin"], g["ek"])
        return {"deger": k["toplam"], "ondalik": 0, "birim": "saat (toplam kapasite)",
                "ifade": f"{_g(g['kisi'])} × ({_g(g['saat'])} − {_g(g['izin'])} + {_g(g['ek'])})",
                "ayrinti": [["Düzenli kapasite (saat)", k["duzenli"]],
                            ["Ek kapasite (saat)", k["ek"]],
                            ["Ek kapasitenin payı (%)", round(100 * _bol(k["ek"], k["toplam"], "toplam kapasite"), 1)]]}

    if metrik == "plan_uyumu":
        d = plan_uyumu(g["uretken_sure"], g["tahsisli_uretken_sure"])
        return {"deger": d, "ondalik": 1, "birim": "% (plan uyumu)",
                "ifade": f"{_g(g['uretken_sure'])} ÷ {_g(g['tahsisli_uretken_sure'])} × 100",
                "ayrinti": [["Planlanan ile gerçekleşen fark (saat)", round(g["uretken_sure"] - g["tahsisli_uretken_sure"], 2)]]}

    if metrik == "plan_performansi":
        d = plan_performansi(g["calisma_ortaminda"], g["atanan_sure"])
        return {"deger": d, "ondalik": 1, "birim": "% (plan performansı)",
                "ifade": f"{_g(g['calisma_ortaminda'])} ÷ {_g(g['atanan_sure'])} × 100",
                "ayrinti": [["Atanan ile fiili fark (saat)", round(g["calisma_ortaminda"] - g["atanan_sure"], 2)]]}

    if metrik == "tahmin":
        d = tahmin_orani(g["tahmin"], g["gercek"])
        return {"deger": d, "ondalik": 1, "birim": "% (tahmin ÷ gerçek)",
                "ifade": f"{_g(g['tahmin'])} ÷ {_g(g['gercek'])} × 100",
                "ayrinti": [["Mutlak yüzde hata (%)", round(tahmin_hatasi(g["tahmin"], g["gercek"]), 1)],
                            ["Fark (tahmin − gerçek)", round(g["tahmin"] - g["gercek"], 2)]]}

    if metrik == "gecmis":
        d = gecmis_kullanim(g["fiili"], g["kapasite"])
        return {"deger": d, "ondalik": 1, "birim": "% (geçmiş kullanım)",
                "ifade": f"{_g(g['fiili'])} ÷ {_g(g['kapasite'])} × 100",
                "ayrinti": [["Kullanılmayan kapasite", round(g["kapasite"] - g["fiili"], 2)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30434 — doğrulama çıktısı")
    print(cizgi)

    print(f"Standart örneği: tahmin kullanım %68, hedef %85 → fark {hedef_farki(68, 85):+.0f} puan")
    print(f"Teslimat  (1050 / 1000)    : %{teslimat_orani(1000, 1050):.1f}")
    print(f"Kullanım  (700 / 1000)     : %{kullanim_orani(700, 1000):.1f}")
    print(f"Tolerans  (68, [80, 120])  : {tolerans_sapmasi(68, 80, 120):+.1f} puan")
    k = kapasite(10, 160, 16, 20)
    print(f"Kapasite  (10 kişi)        : düzenli {k['duzenli']:.0f} + ek {k['ek']:.0f} = {k['toplam']:.0f} saat")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<18}: {deger}")
    print("Eylem numaraları (Tablo B.1):")
    for n in sorted({n for e in t.ozet()["onleyici_eylemler"].values() for n in e}):
        print(f"  {n}: {ONLEYICI_EYLEMLER[n]}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("kullanim", tahsis=68, kapasite=100))
    print(cizgi)

    print("Süreç denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in tahsis_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
