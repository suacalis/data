#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30407_metrikler.py
=====================
ISO/TS 30407:2017 (Human resource management — Cost-Per-Hire) çerçevesindeki
işe alım başına maliyet metriklerinin Python karşılığı.

Teknik şartname üç formül ailesi tanımlar:
  CPHI  — kuruma özgü işe alım başına maliyet:  (Σ dış + Σ iç maliyet) ÷ işe alım sayısı
  CPHC  — kurumlar arası karşılaştırılabilir:    aynı formül, daha dar maliyet kapsamı
  HCR   — işe alım maliyet oranı:                (Σ dış + Σ iç) ÷ ilk yıl toplam ücret × 100
ayrıca bölümlenmiş (segment) CPH ve lise/üniversite (zorunlu ve zorunlu sonrası
eğitim) işe alımları için özel bir CPH (Formül 5) içerir. Modül üç bölüme ayrılmıştır:

    1) Formüller   — CPHI, CPHC, HCR, segment, kampüs
    2) Yardımcılar — paylaştırma, dönem sapması, toplam ile ortalama farkı
    3) Yapılar     — maliyet kalemleri tablosu, denetim, dağıtıcı

Kullanım:
    from iso30407_metrikler import cph, hcr
    cph(100000, 100000, 40)           ->  5000.0
    hcr(100000, 100000, 2000000)      ->  10.0

Doğrudan çalıştırıldığında (python3 iso30407_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30407:2017'ye dayanır.
Paylaştırma ve dönem sapması hesapları ile kalem dağılımı örnek verisi bu
modülde türetilmiş ya da örnek amaçlıdır. Kod ve açıklamalar özgün olarak
yazılmıştır; şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # formüller
    "cph", "hcr", "segment_cph", "kampus_cph",
    # yardımcılar
    "toplam_ve_ortalama", "paylastir", "donem_sapmasi",
    # yapılar
    "Kalem", "MaliyetTablosu", "KALEMLER", "ornek_tablo", "cph_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, maliyet negatif vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


# ---------------------------------------------------------------------------
# 1) Formüller (madde 4–7)
# ---------------------------------------------------------------------------

def cph(dis: float, ic: float, isealim: float) -> float:
    """Formül (1) ve (2): CPHI ve CPHC = (Σ dış maliyet + Σ iç maliyet) ÷ işe alım sayısı."""
    _negatif_yok(dis=dis, ic=ic)
    return _bol(dis + ic, isealim, "işe alım sayısı")


def hcr(dis: float, ic: float, ilk_yil_ucret: float) -> float:
    """Formül (3): HCR = (Σ dış + Σ iç) ÷ ilk yıl toplam ücret × 100 (yüzde)."""
    _negatif_yok(dis=dis, ic=ic)
    return 100 * _bol(dis + ic, ilk_yil_ucret, "ilk yıl toplam ücret")


def segment_cph(dis_alt: float, ic_alt: float, isealim_alt: float) -> float:
    """Formül (4): yalnızca ilgili alt kümenin maliyet ve işe alımları (aynı formül)."""
    return cph(dis_alt, ic_alt, isealim_alt)


def kampus_cph(dis_kampus: float, ic_zorunlu: float, isealim_zorunlu: float) -> float:
    """Formül (5): zorunlu ve zorunlu sonrası eğitim işe alımları için CPH."""
    return cph(dis_kampus, ic_zorunlu, isealim_zorunlu)


# ---------------------------------------------------------------------------
# 2) Yardımcılar
# ---------------------------------------------------------------------------

def toplam_ve_ortalama(segmentler: list) -> dict:
    """Segmentlerin (dis, ic, isealim) toplamından CPH ile segment CPH'lerinin basit ortalaması.

    Şartnamenin Tablo 10'u "Toplam/Ortalama" satırında segment CPH'lerinin basit
    ortalamasını (3 838,35) verir; toplam maliyetin toplam işe alıma bölünmesi ise 3 828,43'tür.
    """
    if not segmentler:
        raise GecersizGirdi("en az bir segment gerekir")
    dis = sum(s[0] for s in segmentler)
    ic = sum(s[1] for s in segmentler)
    n = sum(s[2] for s in segmentler)
    cphler = [cph(*s) for s in segmentler]
    agirlikli = cph(dis, ic, n)
    ortalama = sum(cphler) / len(cphler)
    return {"agirlikli": agirlikli, "ortalama": ortalama, "fark": ortalama - agirlikli,
            "maliyet": dis + ic, "isealim": n}


def paylastir(ucret: float, pay_yuzde: float) -> float:
    """Karma işe alımcının ücretinden kampüs işe alımına ayrılan pay (madde 7.3.6.5; yüzde olarak)."""
    _negatif_yok(ucret=ucret)
    if pay_yuzde < 0 or pay_yuzde > 100:
        raise GecersizGirdi("pay 0 ile 100 arasında olmalı")
    return ucret * pay_yuzde / 100


def donem_sapmasi(onceki: float, cari: float) -> float:
    """(cari − önceki) ÷ önceki × 100: bir maliyet kaleminin dönemler arası değişimi (madde 7.2.1)."""
    if onceki <= 0:
        raise GecersizGirdi("önceki değer sıfırdan büyük olmalı")
    if cari < 0:
        raise GecersizGirdi("cari değer negatif olamaz")
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 3) Yapılar: maliyet kalemleri tablosu (Tablo 2, 3, 5, 6)
# ---------------------------------------------------------------------------

# (ad, tür, CPHC kapsamında mı)  tür: "dis" ya da "ic"
KALEMLER = [
    ("Reklam ve pazarlama", "dis", True),
    ("Sabıka, eğitim, kredi ve referans kontrolleri", "dis", True),
    ("Zorunlu ve zorunlu sonrası eğitim kurumlarından işe alım", "dis", True),
    ("Danışmanlık hizmetleri", "dis", False),
    ("Koşullu işçinin kadroya geçiş ücretleri", "dis", False),
    ("Tıbbi ya da sağlık testleri", "dis", True),
    ("Çalışan tavsiye ödülleri (dış)", "dis", True),
    ("Göç ve çalışma izni giderleri", "dis", False),
    ("İş fuarı ve işe alım etkinliği", "dis", True),
    ("Ön eleme ücretleri", "dis", False),
    ("İşe alım süreci dış kaynak (RPO) ücretleri", "dis", True),
    ("Yer değiştirme (taşınma) ücretleri", "dis", False),
    ("Kaynak bulma maliyetleri", "dis", True),
    ("Seyahat ve giderler, aday", "dis", True),
    ("Seyahat ve giderler, işe alım uzmanı", "dis", True),
    ("Teknoloji maliyetleri", "dis", True),
    ("Üçüncü taraf ajans ücretleri", "dis", True),
    ("İşe alım personeli maliyeti", "ic", True),
    ("Kaynak bulma personeli maliyeti", "ic", False),
    ("Hükümet uyumu için iç yük", "ic", False),
    ("Emek dışı ofis maliyetleri", "ic", True),
    ("İşe alım öğrenme ve gelişim", "ic", True),
    ("Tavsiye ücretleri (iç)", "ic", True),
    ("İkincil yönetim süresi: etkinlikler", "ic", False),
    ("İkincil yönetim süresi: işe alım görüşmeleri", "ic", False),
]


@dataclass
class Kalem:
    """Tek bir maliyet kalemi; tur 'dis' ya da 'ic'."""
    ad: str
    tur: str
    tutar: float = 0
    cphc: bool = True


@dataclass
class MaliyetTablosu:
    """Maliyet kalemleri tablosu: CPHI tüm kalemleri, CPHC yalnızca işaretlileri toplar."""
    kalemler: list = field(default_factory=list)

    def ekle(self, ad, tur, tutar, cphc=True) -> "MaliyetTablosu":
        if tur not in ("dis", "ic"):
            raise GecersizGirdi("tür 'dis' ya da 'ic' olmalı")
        _negatif_yok(tutar=tutar)
        self.kalemler.append(Kalem(ad, tur, tutar, cphc))
        return self

    def _topla(self, tur: str, yalniz_cphc: bool = False) -> float:
        return sum(k.tutar for k in self.kalemler
                   if k.tur == tur and (k.cphc or not yalniz_cphc))

    def ozet(self, basladi: float, ilk_yil_ucret: float, cphi_isealim: float | None = None) -> dict:
        dis, ic = self._topla("dis"), self._topla("ic")
        dis_c, ic_c = self._topla("dis", True), self._topla("ic", True)
        n_i = basladi if cphi_isealim is None else cphi_isealim
        return {
            "dis_cphi": dis, "ic_cphi": ic,
            "cphi": round(cph(dis, ic, n_i), 2),
            "dis_cphc": dis_c, "ic_cphc": ic_c,
            "cphc": round(cph(dis_c, ic_c, basladi), 2),
            "hcr_yuzde": round(hcr(dis, ic, ilk_yil_ucret), 2),
        }


def _ornek_dagilim() -> list:
    """Örnek amaçlı kalem dağılımı: dış 100 000, iç 100 000 (HCR örneğinin toplamları)."""
    dis = {"Reklam ve pazarlama": 20000,
           "Sabıka, eğitim, kredi ve referans kontrolleri": 6000,
           "İş fuarı ve işe alım etkinliği": 10000,
           "Yer değiştirme (taşınma) ücretleri": 10000,
           "Seyahat ve giderler, aday": 7000,
           "Seyahat ve giderler, işe alım uzmanı": 5000,
           "Teknoloji maliyetleri": 12000,
           "Üçüncü taraf ajans ücretleri": 30000}
    ic = {"İşe alım personeli maliyeti": 70000,
          "Hükümet uyumu için iç yük": 5000,
          "Emek dışı ofis maliyetleri": 12000,
          "İşe alım öğrenme ve gelişim": 3000,
          "İkincil yönetim süresi: işe alım görüşmeleri": 10000}
    return [(ad, tur, dis.get(ad, 0) if tur == "dis" else ic.get(ad, 0), cphc)
            for ad, tur, cphc in KALEMLER]


def ornek_tablo() -> MaliyetTablosu:
    """Örnek tablo. Toplamlar şartnamenin HCR örneğine uyar (dış 100 000, iç 100 000);
    kalem dağılımı, işe alım sayısı (40) bu sayfaya aittir, şartnamede yoktur."""
    t = MaliyetTablosu()
    for ad, tur, tutar, cphc in _ornek_dagilim():
        t.ekle(ad, tur, tutar, cphc)
    return t


def cph_denetimi(sistem_kaydi_secildi: bool = False,
                 hire_tanimi_yazili: bool = False,
                 tarih_yontemi_sabit: bool = False,
                 kapsam_belgeli: bool = False,
                 donemsel_varyans_testi: bool = False,
                 surec_gozden_gecirme: bool = False,
                 hcr_ile_birlikte: bool = False,
                 tavsiye_yontemi_yazili: bool = False) -> list:
    """Bir CPH raporunun eksiklerini listeler.

    Maddeler ISO/TS 30407'nin 4–7. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (sistem_kaydi_secildi, "Maliyet ve işe alım sayısı için tutarlı kullanılan bir kayıt sistemi (genel muhasebe, yetenek kazanım sistemi) seçilmemiş."),
        (hire_tanimi_yazili, "Hangi işe alımların sayıldığı (başlayanlar mı, kabul edilen teklifler mi) ve dahil/dışlama kuralları yazılı değil."),
        (tarih_yontemi_sabit, "Gider tarihi yöntemi (fatura tarihi mi, işe alıma tahakkuk mu) bir kez belirlenip tüm raporlarda tutarlı uygulanmamış."),
        (kapsam_belgeli, "Maliyet kapsamı (CPHI/CPHC kalemleri) belgelenmemiş; hangi kalemlerin dahil olduğu görünmüyor."),
        (donemsel_varyans_testi, "Maliyet kalemlerinin dönemler arası varyansı sınanmıyor; ani sapmalar gözden kaçabilir."),
        (surec_gozden_gecirme, "Veriyi üreten süreçler düzenli gözden geçirilmiyor; sürekli iyileştirme taahhüdü yok."),
        (hcr_ile_birlikte, "CPH tek başına değerlendiriliyor; farklı işe alım türleri için HCR ile birlikte okunmalı."),
        (tavsiye_yontemi_yazili, "Çalışan tavsiye ödüllerinin gerçek ödeme mi, tahakkuk mu olarak sayıldığı yazılı değil."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["cphi", "cphc", "hcr", "segment", "kampus", "paylasim", "sapma"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik in ("cphi", "cphc"):
        n = g["isealim"] if metrik == "cphi" else g["basladi"]
        d = cph(g["dis"], g["ic"], n)
        toplam = g["dis"] + g["ic"]
        return {"deger": d, "ondalik": 2, "birim": "para birimi / işe alım",
                "ifade": f"({_g(g['dis'])} + {_g(g['ic'])}) ÷ {_g(n)}",
                "ayrinti": [["Toplam maliyet", toplam],
                            ["Dış maliyet payı (%)", round(100 * _bol(g["dis"], toplam, "toplam maliyet"), 1)],
                            ["İç maliyet payı (%)", round(100 * g["ic"] / toplam, 1)]]}

    if metrik == "hcr":
        d = hcr(g["dis"], g["ic"], g["ilk_yil_ucret"])
        return {"deger": d, "ondalik": 2, "birim": "% (maliyetin ilk yıl ücretine oranı)",
                "ifade": f"({_g(g['dis'])} + {_g(g['ic'])}) ÷ {_g(g['ilk_yil_ucret'])} × 100",
                "ayrinti": [["Toplam maliyet", g["dis"] + g["ic"]],
                            ["Her 1 birim ilk yıl ücretine düşen maliyet", round((g["dis"] + g["ic"]) / g["ilk_yil_ucret"], 3)]]}

    if metrik == "segment":
        s = [(g["e1"], g["i1"], g["n1"]), (g["e2"], g["i2"], g["n2"]), (g["e3"], g["i3"], g["n3"])]
        r = toplam_ve_ortalama(s)
        return {"deger": r["agirlikli"], "ondalik": 2, "birim": "para birimi / işe alım (toplam maliyet ÷ toplam işe alım)",
                "ifade": f"({_g(r['maliyet'])}) ÷ {_g(r['isealim'])}",
                "ayrinti": [["Segment CPH'lerinin basit ortalaması (Tablo 10'daki 'Toplam/Ortalama')", round(r["ortalama"], 2)],
                            ["Ortalama − ağırlıklı fark", round(r["fark"], 2)],
                            ["Toplam maliyet", r["maliyet"]],
                            ["Toplam işe alım", r["isealim"]]]}

    if metrik == "kampus":
        d = kampus_cph(g["dis_kampus"], g["ic_zorunlu"], g["isealim_zorunlu"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi / zorunlu ve zorunlu sonrası eğitim işe alımı",
                "ifade": f"({_g(g['dis_kampus'])} + {_g(g['ic_zorunlu'])}) ÷ {_g(g['isealim_zorunlu'])}",
                "ayrinti": [["Toplam kampüs maliyeti", g["dis_kampus"] + g["ic_zorunlu"]]]}

    if metrik == "paylasim":
        d = paylastir(g["ucret"], g["pay"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi (kampüs işe alımına ayrılan)",
                "ifade": f"{_g(g['ucret'])} × {_g(g['pay'])} ÷ 100",
                "ayrinti": [["Deneyimli işe alıma kalan pay (%)", round(100 - g["pay"], 1)],
                            ["Deneyimli işe alıma kalan tutar", round(g["ucret"] - d, 2)]]}

    if metrik == "sapma":
        d = donem_sapmasi(g["onceki"], g["cari"])
        return {"deger": d, "ondalik": 1, "birim": "% değişim",
                "ifade": f"({_g(g['cari'])} − {_g(g['onceki'])}) ÷ {_g(g['onceki'])} × 100",
                "ayrinti": [["Mutlak fark", g["cari"] - g["onceki"]],
                            ["Cari değerin öncekine katı", round(g["cari"] / g["onceki"], 2)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30407 — doğrulama çıktısı")
    print(cizgi)

    print(f"HCR (şartname örneği)      : %{hcr(100000, 100000, 2000000):.0f}")
    print(f"Tablo 10 bölgesel CPH      : Americas {cph(201600, 127432, 84):.2f}, "
          f"EMEA {cph(154794.5, 66340.5, 47):.2f}, APAC {cph(111322.64, 39113.36, 52):.2f}")
    r = toplam_ve_ortalama([(201600, 127432, 84), (154794.5, 66340.5, 47), (111322.64, 39113.36, 52)])
    print(f"Toplam maliyet ÷ işe alım  : {r['agirlikli']:.2f}  (700 603 ÷ 183)")
    print(f"Segment CPH ortalaması     : {r['ortalama']:.2f}  (şartnamedeki 'Toplam/Ortalama')")
    print(f"Karma işe alımcı payı      : {paylastir(100000, 20):.0f} (ücret 100 000'in %20'si; tutar örnek)")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet(basladi=40, ilk_yil_ucret=2000000).items():
        print(f"{anahtar:<12}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("hcr", dis=100000, ic=100000, ilk_yil_ucret=2000000))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in cph_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
