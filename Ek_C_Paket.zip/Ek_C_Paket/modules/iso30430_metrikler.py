#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30430_metrikler.py
=====================
ISO/TS 30430:2021 (Human resource management — Recruitment metrics cluster)
çerçevesindeki işe alım metriklerinin Python karşılığı.

Standart, ISO 30414'ün "işe alım, hareketlilik ve devir" kümesinin işe alım
ayağını iki ana metrik üzerinden tanımlar ve bunları dört ek süre metriğiyle
genişletir. Modül üç bölüme ayrılmıştır:

    1) Aday havuzu — pozisyon başına nitelikli aday (AQC), nitelik oranı
    2) Süre        — ortalama doldurma süresi (TD/TP) ve genişletilmiş süreler
    3) Plan        — plana göre gerçekleşen işe alım, boş pozisyonun karşılığı

Kullanım:
    from iso30430_metrikler import aqc, ortalama_doldurma
    aqc(420, 300)              ->  1.4
    ortalama_doldurma(225, 6)  ->  37.5

Doğrudan çalıştırıldığında (python3 iso30430_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30430:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from statistics import mean, median
from typing import Sequence

__all__ = [
    # aday havuzu
    "aqc", "nitelik_orani", "aday_yogunlugu",
    # süre
    "gun_farki", "ortalama_doldurma", "sure_ozeti", "acik_talep_orani",
    "ortalama_sure", "toplam_bosluk_suresi", "isgunu_takvim",
    # plan ve karşılık
    "plan_gerceklesme", "bosluk_maliyeti",
    # yardımcı
    "Pozisyon", "DoldurmaTablosu", "ornek_tablo", "metrik_denetimi",
    "hesapla", "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Aday havuzu metrikleri
# ---------------------------------------------------------------------------

def aqc(nitelikli: float, pozisyon: float) -> float:
    """Pozisyon başına ortalama nitelikli aday (AQC) = QC / TP.

    Nitelikli aday, ölçüm döneminde ilan edilen açık pozisyonlara başvuran ve
    işin gereklerini karşılayan adaydır. Hangi adayın nitelikli sayılacağına
    ilişkin ölçütü her kurum kendi pozisyon kategorileri için tanımlar,
    belgeler ve düzenli olarak günceller.
    """
    return nitelikli / pozisyon


def nitelik_orani(nitelikli: float, toplam_aday: float) -> float:
    """Nitelikli aday oranı (%) = QC / TC.

    Uygun olmayan aday payının yüksek olması ilanın hedefinin gözden
    geçirilmesi gerektiğine; nitelikli aday payının düşük olması ise
    yararlanılan yetenek havuzunun daraldığına işaret eder.
    """
    return 100 * nitelikli / toplam_aday


def aday_yogunlugu(toplam_aday: float, pozisyon: float) -> float:
    """Pozisyon başına toplam aday (TC / TP).

    AQC ile birlikte okunur: yüksek aday yoğunluğu ama düşük AQC, çekim
    stratejisinin çok geniş hedeflediğini gösterir.
    """
    return toplam_aday / pozisyon


# ---------------------------------------------------------------------------
# 2) Süre metrikleri
# ---------------------------------------------------------------------------

def gun_farki(baslangic: str, bitis: str) -> int:
    """İki tarih arasındaki gün sayısı. Tarihler ISO biçimindedir (YYYY-AA-GG)."""
    return (date.fromisoformat(bitis) - date.fromisoformat(baslangic)).days


def ortalama_doldurma(toplam_gun: float, pozisyon: float) -> float:
    """Ortalama doldurma süresi (gün) = TD / TP.

    TD, dönemde doldurulan tüm pozisyonlar için D1 ile D2 arasındaki günlerin
    toplamıdır: D1 onaylı kadro talebinin verildiği tarih, D2 adayın teklifi
    kabul ettiği tarihtir. Aynı formül hem tüm pozisyonlar hem de yalnızca
    kritik pozisyonlar için kullanılır.
    """
    return toplam_gun / pozisyon


def sure_ozeti(gunler: Sequence[float]) -> dict:
    """Doldurma sürelerinin dağılımı: ortalama, ortanca, en kısa, en uzun.

    Ortalama tek başına yanıltır: birkaç çok uzun süreç ortalamayı yukarı
    çeker. Ortanca ile birlikte raporlanması önerilir.
    """
    return {
        "adet": len(gunler),
        "toplam": float(sum(gunler)),
        "ortalama": float(mean(gunler)),
        "ortanca": float(median(gunler)),
        "en_kisa": float(min(gunler)),
        "en_uzun": float(max(gunler)),
    }


def acik_talep_orani(doldurulamayan: float, onaylanan: float) -> float:
    """Doldurulamayan onaylı kadro talebi oranı (%).

    Standart, dönem sonunda hâlâ açık olan onaylı taleplerin sayısının ayrı
    bir satır olarak raporlanmasını ister: ortalama süre yalnızca doldurulan
    pozisyonları sayar ve kapanmayan süreçleri görünmez kılar.
    """
    return 100 * doldurulamayan / onaylanan


def ortalama_sure(toplam_gun: float, vaka: float) -> float:
    """Genişletilmiş süre metriklerinin ortak formülü: toplam gün / vaka sayısı.

    Ölçüm noktaları değişir, formül değişmez:
      - boşluğun bilinmesinden onaylı kadro talebine
      - boşluğun bilinmesinden teklifin kabulüne
      - ayrılıştan yeni çalışanın işe başlamasına
      - ayrılıştan uyum sürecinin bitişine
    """
    return toplam_gun / vaka


def toplam_bosluk_suresi(bosluk_talep_gun: float, talep_kabul_gun: float) -> float:
    """Boşluğun bilinmesinden teklifin kabulüne kadar geçen toplam süre.

    Bu metrik kapsayıcıdır: gecikmenin İK sürecinden mi yoksa talebin geç
    açılmasından mı kaynaklandığını görmek için iki bileşen ayrı ayrı da
    raporlanır.
    """
    return bosluk_talep_gun + talep_kabul_gun


def isgunu_takvim(isgunu: float, haftalik_calisma_gunu: float = 5) -> float:
    """İş gününü yaklaşık takvim gününe çevirir.

    Ayrılış sonrası metrikler iş günü üzerinden tanımlıdır; boşluk ve talep
    metrikleri örneklerde takvim tarihleriyle verilir. İki seriyi yan yana
    koyarken birim farkı açıkça belirtilmelidir.
    """
    return isgunu * 7 / haftalik_calisma_gunu


# ---------------------------------------------------------------------------
# 3) Plan ve boş pozisyonun karşılığı
# ---------------------------------------------------------------------------

def plan_gerceklesme(gerceklesen: float, planlanan: float) -> float:
    """Plana göre gerçekleşen işe alım (%).

    Onaylı işgücü planı ya da bütçelenmiş işe alım takvimi ile fiilen yapılan
    işe alımın karşılaştırılmasıdır.
    """
    return 100 * gerceklesen / planlanan


def bosluk_maliyeti(gun: float, gunluk_katki: float, pozisyon: float = 1) -> float:
    """Boş geçen sürenin parasal karşılığı (türetilmiş).

    Standart bu hesabı formül olarak vermez; gecikmelerin gizli maliyet ve
    verimlilik kaybı ürettiğini belirtir. Buradaki hesap, süreyi tartışılabilir
    bir tutara çevirmek için eklenmiştir: günlük katkı, pozisyonun bir günlük
    net katkısına ilişkin kurum varsayımıdır.
    """
    return gun * gunluk_katki * pozisyon


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar
# ---------------------------------------------------------------------------

@dataclass
class Pozisyon:
    """Doldurulan tek bir pozisyonun süre verisi."""
    kod: str
    d1: str = ""          # onaylı kadro talebi tarihi
    d2: str = ""          # adayın teklifi kabul ettiği tarih
    kritik: bool = False

    @property
    def gun(self) -> int:
        return gun_farki(self.d1, self.d2)


@dataclass
class DoldurmaTablosu:
    """Dönemde doldurulan pozisyonların tablosu."""
    pozisyonlar: list = field(default_factory=list)
    doldurulamayan: int = 0

    def ekle(self, kod: str, d1: str, d2: str, kritik: bool = False) -> "DoldurmaTablosu":
        self.pozisyonlar.append(Pozisyon(kod, d1, d2, kritik))
        return self

    @property
    def gunler(self) -> list:
        return [p.gun for p in self.pozisyonlar]

    @property
    def kritik_gunler(self) -> list:
        return [p.gun for p in self.pozisyonlar if p.kritik]

    def ozet(self) -> dict:
        o = sure_ozeti(self.gunler)
        kritik = self.kritik_gunler
        o["kritik_adet"] = len(kritik)
        o["kritik_ortalama"] = round(mean(kritik), 2) if kritik else None
        o["doldurulamayan"] = self.doldurulamayan
        o["acik_talep_orani"] = round(
            acik_talep_orani(self.doldurulamayan,
                             len(self.pozisyonlar) + self.doldurulamayan), 1)
        for k in ("toplam", "ortalama", "ortanca", "en_kisa", "en_uzun"):
            o[k] = round(o[k], 2)
        return o


def ornek_tablo() -> DoldurmaTablosu:
    """Altı pozisyonluk örnek ölçüm dönemi."""
    t = DoldurmaTablosu(doldurulamayan=2)
    veri = [
        ("V1", "2019-01-20", "2019-02-28", True),
        ("V2", "2019-01-20", "2019-02-21", False),
        ("V3", "2019-01-20", "2019-02-21", False),
        ("V4", "2019-01-20", "2019-02-27", True),
        ("V5", "2019-01-20", "2019-02-27", False),
        ("V6", "2019-01-20", "2019-03-06", False),
    ]
    for kod, d1, d2, kritik in veri:
        t.ekle(kod, d1, d2, kritik)
    return t


def metrik_denetimi(nitelik_olcutu_tanimli: bool = False,
                    olcum_noktasi_sabit: bool = False,
                    kritik_ayri: bool = False,
                    acik_talep_raporlaniyor: bool = False,
                    onceki_donem_var: bool = False,
                    bosluk_suresi_olculuyor: bool = False) -> list:
    """Bir işe alım raporunun eksiklerini listeler.

    Standardın mantığı: iki metrik (AQC ve doldurma süresi) tek başına
    yorumlanamaz; ölçütün tanımı, ölçüm noktası, kırılım ve karşılaştırma
    tabanı olmadan sayı kıyaslanabilir değildir.
    """
    uyarilar = []
    if not nitelik_olcutu_tanimli:
        uyarilar.append("Nitelikli adayın ölçütü yazılı değil: AQC kurumlar ve "
                        "dönemler arasında karşılaştırılamaz.")
    if not olcum_noktasi_sabit:
        uyarilar.append("Ölçüm noktası sabitlenmemiş: dönem sonu yerine farklı "
                        "kesitler kullanılırsa eğilim kırılır.")
    if not kritik_ayri:
        uyarilar.append("Kritik pozisyonlar ayrı ölçülmüyor: genel ortalama, "
                        "kritik kadrodaki gecikmeyi gizler.")
    if not acik_talep_raporlaniyor:
        uyarilar.append("Doldurulamayan onaylı talepler raporlanmıyor: ortalama "
                        "süre yalnızca kapanan süreçleri sayar.")
    if not onceki_donem_var:
        uyarilar.append("Önceki dönem ve yıl karşılaştırması yok: standardın "
                        "önerdiği karşılaştırma aralığı üç ilâ beş yıldır.")
    if not bosluk_suresi_olculuyor:
        uyarilar.append("Boşluğun bilinmesinden talebe geçen süre ölçülmüyor: "
                        "gecikmenin İK sürecinde mi yoksa talep açmada mı "
                        "olduğu ayrılamaz.")
    return uyarilar


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "aqc", "nitelik_orani", "aday_yogunlugu", "time_to_fill",
    "kritik_time_to_fill", "acik_talep", "bosluk_talep", "bosluk_kabul",
    "ayrilis_baslangic", "ayrilis_uyum", "plan_gerceklesme", "bosluk_maliyeti",
]


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "aqc":
        d = aqc(g["nitelikli"], g["pozisyon"])
        return {"deger": d, "ondalik": 2, "birim": "nitelikli aday / pozisyon",
                "ifade": f"{g['nitelikli']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Pozisyon başına toplam aday",
                             round(aday_yogunlugu(g["toplam_aday"], g["pozisyon"]), 2)],
                            ["Nitelikli aday oranı (%)",
                             round(nitelik_orani(g["nitelikli"], g["toplam_aday"]), 1)],
                            ["Ölçütü karşılamayan aday", g["toplam_aday"] - g["nitelikli"]]]}

    if metrik == "nitelik_orani":
        d = nitelik_orani(g["nitelikli"], g["toplam_aday"])
        return {"deger": d, "ondalik": 1, "birim": "% nitelikli",
                "ifade": f"({g['nitelikli']:g} ÷ {g['toplam_aday']:g}) × 100",
                "ayrinti": [["Ölçütü karşılamayan aday", g["toplam_aday"] - g["nitelikli"]],
                            ["Pozisyon başına nitelikli aday",
                             round(aqc(g["nitelikli"], g["pozisyon"]), 2)],
                            ["Pozisyon başına elenen aday",
                             round((g["toplam_aday"] - g["nitelikli"]) / g["pozisyon"], 2)]]}

    if metrik == "aday_yogunlugu":
        d = aday_yogunlugu(g["toplam_aday"], g["pozisyon"])
        return {"deger": d, "ondalik": 2, "birim": "aday / pozisyon",
                "ifade": f"{g['toplam_aday']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Pozisyon başına nitelikli aday",
                             round(aqc(g["nitelikli"], g["pozisyon"]), 2)],
                            ["Nitelikli aday oranı (%)",
                             round(nitelik_orani(g["nitelikli"], g["toplam_aday"]), 1)]]}

    if metrik == "time_to_fill":
        d = ortalama_doldurma(g["toplam_gun"], g["pozisyon"])
        return {"deger": d, "ondalik": 1, "birim": "gün",
                "ifade": f"{g['toplam_gun']:g} ÷ {g['pozisyon']:g}",
                "ayrinti": [["Hafta karşılığı", round(d / 7, 1)],
                            ["Doldurulamayan onaylı talep", g["doldurulamayan"]],
                            ["Doldurulamayan talep oranı (%)",
                             round(acik_talep_orani(g["doldurulamayan"],
                                                    g["pozisyon"] + g["doldurulamayan"]), 1)]]}

    if metrik == "kritik_time_to_fill":
        kritik = ortalama_doldurma(g["kritik_gun"], g["kritik_pozisyon"])
        genel = ortalama_doldurma(g["genel_gun"], g["genel_pozisyon"])
        return {"deger": kritik, "ondalik": 1, "birim": "gün (kritik)",
                "ifade": f"{g['kritik_gun']:g} ÷ {g['kritik_pozisyon']:g}",
                "ayrinti": [["Tüm pozisyonlarda ortalama (gün)", round(genel, 1)],
                            ["Kritik pozisyonların farkı (gün)", round(kritik - genel, 1)],
                            ["Kritik pozisyonların payı (%)",
                             round(100 * g["kritik_pozisyon"] / g["genel_pozisyon"], 1)]]}

    if metrik == "acik_talep":
        d = acik_talep_orani(g["doldurulamayan"], g["onaylanan"])
        return {"deger": d, "ondalik": 1, "birim": "% açık talep",
                "ifade": f"({g['doldurulamayan']:g} ÷ {g['onaylanan']:g}) × 100",
                "ayrinti": [["Doldurulan talep", g["onaylanan"] - g["doldurulamayan"]],
                            ["Açık talebin taşıdığı boş gün",
                             round(g["doldurulamayan"] * g["ortalama_acik_gun"])],
                            ["Doldurulan talep oranı (%)",
                             round(100 - d, 1)]]}

    if metrik == "bosluk_talep":
        d = ortalama_sure(g["toplam_gun"], g["vaka"])
        return {"deger": d, "ondalik": 1, "birim": "gün",
                "ifade": f"{g['toplam_gun']:g} ÷ {g['vaka']:g}",
                "ayrinti": [["Hafta karşılığı", round(d / 7, 1)],
                            ["Doldurma süresine oranı (%)",
                             round(100 * d / g["doldurma_suresi"], 1)],
                            ["Toplam süreye katkısı (gün)", round(d, 1)]]}

    if metrik == "bosluk_kabul":
        d = toplam_bosluk_suresi(g["bosluk_talep_gun"], g["talep_kabul_gun"])
        return {"deger": d, "ondalik": 1, "birim": "gün (toplam)",
                "ifade": f"{g['bosluk_talep_gun']:g} + {g['talep_kabul_gun']:g}",
                "ayrinti": [["Talep açma gecikmesinin payı (%)",
                             round(100 * g["bosluk_talep_gun"] / d, 1)],
                            ["İşe alım sürecinin payı (%)",
                             round(100 * g["talep_kabul_gun"] / d, 1)],
                            ["Hafta karşılığı", round(d / 7, 1)]]}

    if metrik == "ayrilis_baslangic":
        d = ortalama_sure(g["toplam_isgunu"], g["vaka"])
        return {"deger": d, "ondalik": 1, "birim": "iş günü",
                "ifade": f"{g['toplam_isgunu']:g} ÷ {g['vaka']:g}",
                "ayrinti": [["Yaklaşık takvim günü", round(isgunu_takvim(d), 1)],
                            ["Ay karşılığı (takvim)", round(isgunu_takvim(d) / 30, 1)],
                            ["Kişi başı boş geçen iş günü", round(d, 1)]]}

    if metrik == "ayrilis_uyum":
        d = g["ayrilis_baslangic_gun"] + g["uyum_gun"]
        return {"deger": d, "ondalik": 1, "birim": "iş günü (toplam)",
                "ifade": f"{g['ayrilis_baslangic_gun']:g} + {g['uyum_gun']:g}",
                "ayrinti": [["Boşluk döneminin payı (%)",
                             round(100 * g["ayrilis_baslangic_gun"] / d, 1)],
                            ["Uyum döneminin payı (%)", round(100 * g["uyum_gun"] / d, 1)],
                            ["Yaklaşık takvim günü", round(isgunu_takvim(d), 1)]]}

    if metrik == "plan_gerceklesme":
        d = plan_gerceklesme(g["gerceklesen"], g["planlanan"])
        return {"deger": d, "ondalik": 1, "birim": "% plana göre",
                "ifade": f"({g['gerceklesen']:g} ÷ {g['planlanan']:g}) × 100",
                "ayrinti": [["Plandan sapma (pozisyon)", g["gerceklesen"] - g["planlanan"]],
                            ["Kalan işe alım hedefi",
                             max(g["planlanan"] - g["gerceklesen"], 0)],
                            ["Dönem sonuna kalan ay", g["kalan_ay"]]]}

    if metrik == "bosluk_maliyeti":
        d = bosluk_maliyeti(g["gun"], g["gunluk_katki"], g["pozisyon"])
        return {"deger": d, "ondalik": 0, "birim": "TL",
                "ifade": f"{g['gun']:g} × {g['gunluk_katki']:g} × {g['pozisyon']:g}",
                "ayrinti": [["Pozisyon başına (TL)",
                             round(bosluk_maliyeti(g["gun"], g["gunluk_katki"]))],
                            ["Süre bir hafta kısalırsa kazanç (TL)",
                             round(bosluk_maliyeti(7, g["gunluk_katki"], g["pozisyon"]))],
                            ["Toplam boş gün", round(g["gun"] * g["pozisyon"])]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30430 — doğrulama çıktısı")
    print(cizgi)

    print("Aday havuzu (dört dönemlik karşılaştırma)")
    print(f"{'Dönem':<10}{'TP':>6}{'TC':>7}{'QC':>7}{'AQC':>7}{'QC/TC %':>10}")
    donemler = [("Cari", 300, 600, 420), ("Önceki", 280, 560, 364),
                ("2 yıl", 400, 600, 440), ("3 yıl", 200, 400, 300)]
    for ad, tp, tc, qc in donemler:
        print(f"{ad:<10}{tp:>6}{tc:>7}{qc:>7}{aqc(qc, tp):>7.2f}"
              f"{nitelik_orani(qc, tc):>10.1f}")
    print(cizgi)

    t = ornek_tablo()
    print("Doldurulan pozisyonlar")
    print(f"{'Kod':<6}{'D1':<12}{'D2':<12}{'Gün':>5}{'Kritik':>8}")
    for p in t.pozisyonlar:
        print(f"{p.kod:<6}{p.d1:<12}{p.d2:<12}{p.gun:>5}{'evet' if p.kritik else '—':>8}")
    print(cizgi)
    for k, v in t.ozet().items():
        print(f"{k:<20}: {v}")
    print(cizgi)

    print(f"Boşluk → onaylı talep    : {ortalama_sure(122, 2):.1f} gün")
    print(f"Boşluk → teklif kabulü   : {toplam_bosluk_suresi(61, 37.5):.1f} gün")
    print(f"Ayrılış → işe başlama    : {ortalama_sure(240, 3):.1f} iş günü "
          f"(≈ {isgunu_takvim(ortalama_sure(240, 3)):.0f} takvim günü)")
    print(f"Ayrılış → uyumun bitişi  : {80 + 15:.1f} iş günü")
    print(f"Plana göre gerçekleşme   : {plan_gerceklesme(42, 60):.1f} %")
    print(f"Boş pozisyonun karşılığı : {_tl(bosluk_maliyeti(37.5, 4500, 6))} TL")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("aqc", nitelikli=420, pozisyon=300, toplam_aday=600))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
