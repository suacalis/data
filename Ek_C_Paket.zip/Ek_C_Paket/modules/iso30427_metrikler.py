#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30427_metrikler.py
=====================
ISO/TS 30427:2021 (Human resource management — Costs metrics cluster)
çerçevesindeki işgücü maliyeti metriklerinin Python karşılığı.

Teknik şartname, ISO 30414'ün "maliyetler" kümesinden dört metriği ayrıntılandırır:
toplam işgücü maliyeti, dış işgücü maliyeti, temel maaş ve ücret oranı ve toplam
istihdam maliyeti. (İşe alım başına maliyet ISO/TS 30407'de, işe alım ve devir
maliyetleri ISO/TS 30421'de ele alınır.) Modül üç bölüme ayrılmıştır:

    1) Maliyet toplamları — istihdam, dış işgücü, toplam işgücü maliyeti
    2) Oranlar            — ücret oranı, maliyetin gelire oranı, FTE başına maliyet, değişim
    3) Yardımcı yapılar   — maliyet kalemleri tablosu (Tablo 1), denetim, dağıtıcı

Kullanım:
    from iso30427_metrikler import toplam_istihdam_maliyeti, ucret_orani
    toplam_istihdam_maliyeti(510, 75, 170, 1)   ->  756
    ucret_orani(70, 140)                        ->  0.5

Doğrudan çalıştırıldığında (python3 iso30427_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30427:2021'e dayanır.
Maliyetin gelire oranı ve FTE başına maliyet şartnamede formül olarak verilmez;
bu modülde türetilmiş hesaplardır. Kod ve açıklamalar özgün olarak yazılmıştır;
şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # maliyet toplamları
    "toplam_istihdam_maliyeti", "dis_isgucu_maliyeti", "toplam_isgucu_maliyeti",
    # oranlar
    "ucret_orani", "ters_ucret_orani", "maliyet_orani", "fte_basi_maliyet",
    "yuzde_degisim",
    # yardımcı
    "Kalem", "MaliyetTablosu", "ornek_tablo", "maliyet_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, negatif maliyet vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _negatif_yok(**degerler: float) -> None:
    for ad, v in degerler.items():
        if v < 0:
            raise GecersizGirdi(f"{ad} negatif olamaz")


# ---------------------------------------------------------------------------
# 1) Maliyet toplamları (madde 4, 5 ve 7)
# ---------------------------------------------------------------------------

def toplam_istihdam_maliyeti(maas: float, ikramiye: float, yan_hak: float, diger: float) -> float:
    """Madde 7.3: ücret/ikramiye + yan haklar + diğer istihdam maliyetleri."""
    _negatif_yok(maas=maas, ikramiye=ikramiye, yan_hak=yan_hak, diger=diger)
    return maas + ikramiye + yan_hak + diger


def dis_isgucu_maliyeti(bagimsiz: float, kosullu: float, gecici: float, fason: float) -> float:
    """Madde 5.3 / Tablo 2: bağımsız yükleniciler + koşullu + geçici işçiler + dış kaynaklı işgücü."""
    _negatif_yok(bagimsiz=bagimsiz, kosullu=kosullu, gecici=gecici, fason=fason)
    return bagimsiz + kosullu + gecici + fason


def toplam_isgucu_maliyeti(istihdam: float, dis: float) -> float:
    """Madde 4.3: toplam istihdam maliyeti + dış işgücü maliyeti (her biri bir kez sayılır)."""
    _negatif_yok(istihdam=istihdam, dis=dis)
    return istihdam + dis


# ---------------------------------------------------------------------------
# 2) Oranlar ve değişim
# ---------------------------------------------------------------------------

def ucret_orani(ortalama_tum: float, kategori: float) -> float:
    """Madde 6.3: tüm çalışanların ortalama toplam ücreti ÷ tanımlı kategorinin yıllık toplam ücreti."""
    return _bol(ortalama_tum, kategori, "kategori ücreti")


def ters_ucret_orani(ortalama_tum: float, kategori: float) -> float:
    """Madde 6.4.3 (alternatif): kategorinin ortalama ücreti ÷ tüm çalışanların ortalaması."""
    return _bol(kategori, ortalama_tum, "tüm çalışanların ortalaması")


def maliyet_orani(maliyet: float, gelir: float) -> float:
    """İşgücü maliyetinin gelire (ya da işletme giderine) yüzdesi (madde 4.7; türetilmiş)."""
    _negatif_yok(maliyet=maliyet)
    return 100 * _bol(maliyet, gelir, "gelir ya da işletme gideri")


def fte_basi_maliyet(maliyet: float, fte: float) -> float:
    """Toplam maliyetin tam zaman eşdeğeri başına düşen payı (madde 3.1, 6.1; türetilmiş)."""
    _negatif_yok(maliyet=maliyet)
    return _bol(maliyet, fte, "FTE")


def yuzde_degisim(onceki: float, cari: float) -> float:
    """(cari − önceki) ÷ önceki × 100; Tablo 1'deki "yüzde değişim" sütunu."""
    if onceki <= 0:
        raise GecersizGirdi("önceki değer sıfırdan büyük olmalı")
    if cari < 0:
        raise GecersizGirdi("cari değer negatif olamaz")
    return 100 * (cari - onceki) / onceki


# ---------------------------------------------------------------------------
# 3) Yardımcı yapılar: maliyet kalemleri tablosu (Tablo 1)
# ---------------------------------------------------------------------------

@dataclass
class Kalem:
    """Tek bir maliyet kalemi; grup 'istihdam' ya da 'dis' olur."""
    ad: str
    grup: str
    onceki: float = 0
    cari: float = 0

    def degisim(self) -> float:
        return yuzde_degisim(self.onceki, self.cari)


@dataclass
class MaliyetTablosu:
    """Maliyet kalemleri tablosu."""
    kalemler: list = field(default_factory=list)

    def ekle(self, ad, grup, onceki, cari) -> "MaliyetTablosu":
        if grup not in ("istihdam", "dis"):
            raise GecersizGirdi("grup 'istihdam' ya da 'dis' olmalı")
        self.kalemler.append(Kalem(ad, grup, onceki, cari))
        return self

    def _topla(self, grup: str, alan: str) -> float:
        return sum(getattr(k, alan) for k in self.kalemler if k.grup == grup)

    def ozet(self) -> dict:
        ist_c, ist_o = self._topla("istihdam", "cari"), self._topla("istihdam", "onceki")
        dis_c, dis_o = self._topla("dis", "cari"), self._topla("dis", "onceki")
        top_c, top_o = toplam_isgucu_maliyeti(ist_c, dis_c), toplam_isgucu_maliyeti(ist_o, dis_o)
        buyuk = max(self.kalemler, key=lambda k: k.cari)
        return {
            "kalem_sayisi": len(self.kalemler),
            "istihdam_onceki": ist_o,
            "istihdam_cari": ist_c,
            "istihdam_degisim": round(yuzde_degisim(ist_o, ist_c), 1),
            "dis_onceki": dis_o,
            "dis_cari": dis_c,
            "dis_degisim": round(yuzde_degisim(dis_o, dis_c), 1),
            "toplam_onceki": top_o,
            "toplam_cari": top_c,
            "toplam_degisim": round(yuzde_degisim(top_o, top_c), 1),
            "dis_payi": round(100 * dis_c / top_c, 1),
            "en_buyuk_kalem": (buyuk.ad, buyuk.cari),
        }


def ornek_tablo() -> MaliyetTablosu:
    """Şartnamenin Tablo 1 örneği (milyon USD)."""
    t = MaliyetTablosu()
    for satir in [
        ("Çalışan maaşı",          "istihdam", 464, 510),
        ("İkramiye ve teşvik",     "istihdam",  70,  75),
        ("Yan haklar",             "istihdam", 150, 170),
        ("Diğer ücretler",         "istihdam",   1,   1),
        ("Dış işgücü maliyetleri", "dis",       45,  54),
    ]:
        t.ekle(*satir)
    return t


def maliyet_denetimi(olcum_noktasi_sabit: bool = False,
                     mali_yil_hizali: bool = False,
                     gecmis_donem_karsilastirmasi: bool = False,
                     toplam_cift_sayilmiyor: bool = False,
                     dis_isgucu_ayrintili: bool = False,
                     fte_baglami: bool = False,
                     segment_kirilimi: bool = False,
                     baglam_notlari: bool = False) -> list:
    """Bir maliyet raporunun eksiklerini listeler.

    Maddeler ISO/TS 30427'nin 4–7. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (olcum_noktasi_sabit, "Ölçüm noktası (ay sonu, çeyrek sonu, yıl sonu) sabitlenmemiş; seçilen nokta tutarlı uygulanmalı ve belgelenmeli."),
        (mali_yil_hizali, "Hesaplama mali yıl ya da yıllık bütçe döngüsüyle hizalı değil."),
        (gecmis_donem_karsilastirmasi, "Önceki dönem ve geçmiş yıllarla karşılaştırma yok; tipik aralık üç ila beş yıldır."),
        (toplam_cift_sayilmiyor, "Toplam işgücü maliyeti kontrol edilmemiş: istihdam maliyeti alt toplamı ikinci kez eklenmiş olabilir (toplam = istihdam + dış işgücü)."),
        (dis_isgucu_ayrintili, "Dış işgücü maliyeti bileşenlerine (yüklenici, koşullu, geçici, dış kaynaklı) ayrılmamış."),
        (fte_baglami, "Her ölçüm noktasındaki FTE ve kadro sayısı verilmemiş; maliyet değişiminin anlamı belirsiz kalır."),
        (segment_kirilimi, "Maliyetler pozisyon, performans, verimlilik, bağlılık, kıdem ve hareketlilik gibi kesitlere göre karşılaştırılmıyor."),
        (baglam_notlari, "Sayının yanında bağlam ve öngörü etkenleri (yeniden yapılanma, üretim artışı, ekonomik koşullar) yazılmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "istihdam", "dis", "toplam", "oran", "ucret", "degisim", "fte_basi",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "istihdam":
        d = toplam_istihdam_maliyeti(g["maas"], g["ikramiye"], g["yan_hak"], g["diger"])
        return {"deger": d, "ondalik": 1, "birim": "para birimi (girdi birimiyle)",
                "ifade": f"{_g(g['maas'])} + {_g(g['ikramiye'])} + {_g(g['yan_hak'])} + {_g(g['diger'])}",
                "ayrinti": [["Maaş payı (%)", round(100 * _bol(g["maas"], d, "toplam"), 1)],
                            ["İkramiye ve teşvik payı (%)", round(100 * g["ikramiye"] / d, 1)],
                            ["Yan hak payı (%)", round(100 * g["yan_hak"] / d, 1)],
                            ["Önceki döneme göre değişim (%)", round(yuzde_degisim(g["onceki_toplam"], d), 1)]]}

    if metrik == "dis":
        d = dis_isgucu_maliyeti(g["bagimsiz"], g["kosullu"], g["gecici"], g["fason"])
        return {"deger": d, "ondalik": 0, "birim": "bin para birimi (girdi birimiyle)",
                "ifade": f"{_g(g['bagimsiz'])} + {_g(g['kosullu'])} + {_g(g['gecici'])} + {_g(g['fason'])}",
                "ayrinti": [["Bağımsız yüklenici payı (%)", round(100 * _bol(g["bagimsiz"], d, "toplam"), 1)],
                            ["Dış kaynaklı işgücü payı (%)", round(100 * g["fason"] / d, 1)],
                            ["Önceki döneme göre değişim (%)", round(yuzde_degisim(g["onceki_toplam"], d), 1)]]}

    if metrik == "toplam":
        d = toplam_isgucu_maliyeti(g["istihdam"], g["dis"])
        onceki = toplam_isgucu_maliyeti(g["onceki_istihdam"], g["onceki_dis"])
        return {"deger": d, "ondalik": 1, "birim": "para birimi (girdi birimiyle)",
                "ifade": f"{_g(g['istihdam'])} + {_g(g['dis'])}",
                "ayrinti": [["Dış işgücü payı (%)", round(100 * _bol(g["dis"], d, "toplam"), 1)],
                            ["Önceki dönem toplamı", onceki],
                            ["Önceki döneme göre değişim (%)", round(yuzde_degisim(onceki, d), 1)],
                            ["İstihdam iki kez eklenirse (Tablo 1'deki toplam)", 2 * g["istihdam"] + g["dis"]]]}

    if metrik == "oran":
        d = maliyet_orani(g["maliyet"], g["gelir"])
        return {"deger": d, "ondalik": 1, "birim": "% (gelire oranı)",
                "ifade": f"{_g(g['maliyet'])} ÷ {_g(g['gelir'])} × 100",
                "ayrinti": [["Gelirin 1 biriminde işgücü maliyeti", round(g["maliyet"] / g["gelir"], 3)],
                            ["Maliyet dışında kalan pay (%)", round(100 - d, 1)]]}

    if metrik == "ucret":
        d = ucret_orani(g["ortalama_tum"], g["kategori"])
        return {"deger": d, "ondalik": 2, "birim": ": 1 (oran)",
                "ifade": f"{_g(g['ortalama_tum'])} ÷ {_g(g['kategori'])}",
                "ayrinti": [["Alternatif oran (kategori ÷ tüm çalışanlar)", round(ters_ucret_orani(g["ortalama_tum"], g["kategori"]), 2)],
                            ["Kategori ile tüm çalışanlar arasındaki fark", g["kategori"] - g["ortalama_tum"]]]}

    if metrik == "degisim":
        d = yuzde_degisim(g["onceki"], g["cari"])
        return {"deger": d, "ondalik": 1, "birim": "% değişim",
                "ifade": f"({_g(g['cari'])} − {_g(g['onceki'])}) ÷ {_g(g['onceki'])} × 100",
                "ayrinti": [["Mutlak fark", g["cari"] - g["onceki"]],
                            ["Cari değerin öncekine katı", round(g["cari"] / g["onceki"], 2)]]}

    if metrik == "fte_basi":
        d = fte_basi_maliyet(g["maliyet"], g["fte"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi / FTE",
                "ifade": f"{_g(g['maliyet'])} ÷ {_g(g['fte'])}",
                "ayrinti": [["Toplam maliyet", g["maliyet"]],
                            ["Tam zaman eşdeğeri (FTE)", g["fte"]]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30427 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("Maliyet kalemleri (Tablo 1; milyon USD)")
    print(f"{'Kalem':<26}{'Önceki':>8}{'Cari':>8}{'Değişim %':>11}")
    for k in t.kalemler:
        print(f"{k.ad:<26}{k.onceki:>8}{k.cari:>8}{k.degisim():>11.1f}")
    print(cizgi)
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<18}: {deger}")
    print(cizgi)

    print(f"Toplam istihdam maliyeti : {toplam_istihdam_maliyeti(510, 75, 170, 1)} (önceki {toplam_istihdam_maliyeti(464, 70, 150, 1)})")
    print(f"Dış işgücü (Tablo 2)     : {dis_isgucu_maliyeti(300, 600, 420, 600)} bin USD")
    print(f"Toplam işgücü maliyeti   : {toplam_isgucu_maliyeti(756, 54)} (Tablo 1'de yazan 1566, istihdamı iki kez ekler)")
    print(f"Ücret oranı (Tablo 3)    : {ucret_orani(70, 140):.2f}:1  alternatif {ters_ucret_orani(70, 140):.1f}:1")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("toplam", istihdam=756, dis=54, onceki_istihdam=685, onceki_dis=45))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in maliyet_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
