#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30410_metrikler.py
=====================
ISO/TS 30410:2018 (Human resource management — Impact of hire metric)
çerçevesindeki işe alımın etkisi metriklerinin Python karşılığı.

Teknik şartname, kritik pozisyonların kurumun iş değerine etkisini üç formülle ölçer:
  5) kritik pozisyonların etkisi:      IR = SR × B       ve   II = IR / NR
  6) performans değişiminin etkisi:    D  = II × (R − T) / T
  7) boş kritik pozisyonların etkisi:  L  = II × M / 12
Modül üç bölüme ayrılmıştır:

    1) Etki         — pozisyon etkisi (IR), bireysel etki (II), pay (SR)
    2) Değişim ve boşluk — performans farkı (D), boş pozisyon kaybı (L)
    3) Yardımcı yapılar — kritik pozisyon tablosu, denetim, dağıtıcı

Kullanım:
    from iso30410_metrikler import pozisyon_etkisi, birey_etkisi
    pozisyon_etkisi(40, 10)    ->  4.0      (SR = %40, B = 10 milyon)
    birey_etkisi(4, 5)         ->  0.8

Doğrudan çalıştırıldığında (python3 iso30410_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30410:2018'e dayanır.
Pay (SR) hesabının tersine çevrilmesi ve aylık etki şartnamede yoktur; bu
modülde türetilmiş hesaplardır. Kod ve açıklamalar özgün olarak yazılmıştır;
şartnamenin kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # etki
    "pozisyon_etkisi", "birey_etkisi", "pay_yuzde",
    # değişim ve boşluk
    "performans_farki", "bosluk_kaybi",
    # yardımcı
    "Pozisyon", "PozisyonTablosu", "ornek_tablo", "etki_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, pay %100'ü aşıyor vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


# ---------------------------------------------------------------------------
# 1) Kritik pozisyonların etkisi (madde 5)
# ---------------------------------------------------------------------------

def pozisyon_etkisi(sr_yuzde: float, b: float) -> float:
    """IR = SR × B: kritik pozisyonun yıllıklandırılmış iş değerine etkisi.

    sr_yuzde: pozisyonun toplam iş değerindeki payı (0–100); b: yıllıklandırılmış iş değeri.
    """
    if sr_yuzde < 0 or sr_yuzde > 100:
        raise GecersizGirdi("pay 0 ile 100 arasında olmalı")
    if b < 0:
        raise GecersizGirdi("iş değeri negatif olamaz")
    return sr_yuzde / 100 * b


def birey_etkisi(ir: float, nr: float) -> float:
    """II = IR / NR: kritik pozisyondaki bir bireyin yıllık etkisi."""
    if ir < 0:
        raise GecersizGirdi("pozisyon etkisi negatif olamaz")
    return _bol(ir, nr, "pozisyondaki kişi sayısı")


def pay_yuzde(ir: float, b: float) -> float:
    """SR = IR / B × 100: formül (5.3)'ün tersi (türetilmiş)."""
    if ir < 0 or ir > b:
        raise GecersizGirdi("pozisyon etkisi 0 ile iş değeri arasında olmalı")
    return 100 * _bol(ir, b, "iş değeri")


# ---------------------------------------------------------------------------
# 2) Performans değişimi (madde 6) ve boş pozisyon (madde 7)
# ---------------------------------------------------------------------------

def performans_farki(ii: float, r: float, t: float) -> float:
    """D = II × (R − T) / T: performans puanı R'nin hedef T'den sapmasının değere etkisi.

    Pozitif D, hedefin üstünde performansın ek değerini; negatif D kaybı gösterir.
    """
    if ii < 0:
        raise GecersizGirdi("bireysel etki negatif olamaz")
    if r < 0:
        raise GecersizGirdi("performans puanı negatif olamaz")
    return ii * (r - t) / _hedef(t)


def _hedef(t: float) -> float:
    if t <= 0:
        raise GecersizGirdi("hedef puan sıfırdan büyük olmalı")
    return t


def bosluk_kaybi(ii: float, m: float) -> float:
    """L = II × M / 12: pozisyon M ay boş kalırsa kaybedilen iş değeri."""
    if ii < 0:
        raise GecersizGirdi("bireysel etki negatif olamaz")
    if m < 0:
        raise GecersizGirdi("yedekleme süresi negatif olamaz")
    return ii * m / 12


# ---------------------------------------------------------------------------
# 3) Yardımcı yapılar: kritik pozisyon tablosu
# ---------------------------------------------------------------------------

@dataclass
class Pozisyon:
    """Tek bir kritik pozisyon."""
    ad: str
    sr: float                    # toplam iş değerindeki pay (%)
    nr: float                    # pozisyondaki kişi sayısı
    r: float | None = None       # bir sahibin performans puanı
    m: float | None = None       # yedekleme süresi (ay)

    def ir(self, b: float) -> float:
        return pozisyon_etkisi(self.sr, b)

    def ii(self, b: float) -> float:
        return birey_etkisi(self.ir(b), self.nr)


@dataclass
class PozisyonTablosu:
    """Kritik pozisyonlar tablosu."""
    b: float = 10
    t: float = 4
    pozisyonlar: list = field(default_factory=list)

    def ekle(self, ad, sr, nr, r=None, m=None) -> "PozisyonTablosu":
        self.pozisyonlar.append(Pozisyon(ad, sr, nr, r, m))
        return self

    def ozet(self) -> dict:
        ir = sum(p.ir(self.b) for p in self.pozisyonlar)
        d = sum(performans_farki(p.ii(self.b), p.r, self.t) for p in self.pozisyonlar if p.r is not None)
        l = sum(bosluk_kaybi(p.ii(self.b), p.m) for p in self.pozisyonlar if p.m is not None)
        sr = sum(p.sr for p in self.pozisyonlar)
        return {
            "pozisyon_sayisi": len(self.pozisyonlar),
            "toplam_pay_yuzde": sr,
            "toplam_ir": round(ir, 3),
            "toplam_d": round(d, 3),
            "toplam_l": round(l, 3),
            "pay_uyarisi": "Payların toplamı %100'ü aşıyor: etkiler örtüşüyor olabilir" if sr > 100 else "yok",
        }


def ornek_tablo() -> PozisyonTablosu:
    """Şartnamenin örneği: SR = %40, B = 10 milyon $, NR = 5; R = 5, T = 4; M = 6 ay."""
    t = PozisyonTablosu(b=10, t=4)
    t.ekle("Örnek kritik pozisyon", 40, 5, 5, 6)
    return t


def etki_denetimi(kritik_pozisyonlar_belirlendi: bool = False,
                  segmentasyon_yazili: bool = False,
                  is_degeri_tanimli: bool = False,
                  pay_belirlendi: bool = False,
                  olcek_ve_hedef_yazili: bool = False,
                  yedekleme_suresi_olculuyor: bool = False,
                  yetenek_hatti_var: bool = False,
                  baglam_notlari: bool = False) -> list:
    """Bir işe alımın etkisi raporunun eksiklerini listeler.

    Maddeler ISO/TS 30410'un 4–7. maddelerindeki beklentilerden türetilmiştir;
    bir uygunluk sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (kritik_pozisyonlar_belirlendi, "Kritik pozisyonlar (kurumun sonuçlarına doğrudan ve önemli etkisi olan roller) belirlenmemiş."),
        (segmentasyon_yazili, "İşgücü segmentasyonu yaklaşımı (rol temelli ya da çalışan temelli) yazılı değil."),
        (is_degeri_tanimli, "Yıllıklandırılmış iş değeri (B) ve kapsamı (finansal ve finansal olmayan) tanımlanmamış."),
        (pay_belirlendi, "Kritik pozisyonların toplam iş değerindeki yüzde payı (SR) belirlenmemiş."),
        (olcek_ve_hedef_yazili, "Performans ölçeği ve hedef puan (T) yazılı değil; ölçek doğrusal değilse (D) yorumu yanıltır."),
        (yedekleme_suresi_olculuyor, "Yedekleme süresi (bulma + işe başlatma + performansı hedefe çıkarma) ölçülmüyor."),
        (yetenek_hatti_var, "Kritik pozisyonlar için iç yetenek hattı yok; özel bilgi ve beceri kıt ise dışarıdan bulmaya güvenilmemeli."),
        (baglam_notlari, "Bağlam (kurum büyüklüğü, türü, sektörü, büyüme evresi; ticari açıdan hassas veri) yazılmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 4) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = ["etki_pozisyon", "etki_birey", "pay", "fark", "bosluk"]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "etki_pozisyon":
        d = pozisyon_etkisi(g["sr"], g["b"])
        ii = birey_etkisi(d, g["nr"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi (girdi birimiyle, ör. milyon $)",
                "ifade": f"{_g(g['sr'])} ÷ 100 × {_g(g['b'])}",
                "ayrinti": [["Bireyin yıllık etkisi (II)", round(ii, 3)],
                            ["Pozisyondaki kişi sayısı", g["nr"]],
                            ["Toplam iş değerinden kalan pay (%)", round(100 - g["sr"], 1)]]}

    if metrik == "etki_birey":
        d = birey_etkisi(g["ir"], g["nr"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi (girdi birimiyle, ör. milyon $)",
                "ifade": f"{_g(g['ir'])} ÷ {_g(g['nr'])}",
                "ayrinti": [["Aylık bireysel etki (II ÷ 12)", round(d / 12, 3)],
                            ["Pozisyonun toplam etkisi (IR)", g["ir"]]]}

    if metrik == "pay":
        d = pay_yuzde(g["ir"], g["b"])
        return {"deger": d, "ondalik": 1, "birim": "% (SR: toplam iş değerindeki pay)",
                "ifade": f"{_g(g['ir'])} ÷ {_g(g['b'])} × 100",
                "ayrinti": [["Toplam iş değerinden kalan pay (%)", round(100 - d, 1)]]}

    if metrik == "fark":
        d = performans_farki(g["ii"], g["r"], g["t"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi (girdi birimiyle, ör. milyon $)",
                "ifade": f"{_g(g['ii'])} × ({_g(g['r'])} − {_g(g['t'])}) ÷ {_g(g['t'])}",
                "ayrinti": [["Göreli sapma (R − T) ÷ T (%)", round(100 * (g["r"] - g["t"]) / g["t"], 1)],
                            ["Performansla ayarlı bireysel etki (II + D)", round(g["ii"] + d, 3)]]}

    if metrik == "bosluk":
        d = bosluk_kaybi(g["ii"], g["m"])
        return {"deger": d, "ondalik": 2, "birim": "para birimi (girdi birimiyle, ör. milyon $)",
                "ifade": f"{_g(g['ii'])} × {_g(g['m'])} ÷ 12",
                "ayrinti": [["Aylık bireysel etki (II ÷ 12)", round(g["ii"] / 12, 3)],
                            ["Yıllık bireysel etkinin yüzdesi (%)", round(100 * g["m"] / 12, 1)]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 5) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO/TS 30410 — doğrulama çıktısı")
    print(cizgi)

    ir = pozisyon_etkisi(40, 10)
    ii = birey_etkisi(ir, 5)
    print(f"IR = 0,4 × 10      : {ir} milyon $")
    print(f"II = IR / 5        : {ii} milyon $")
    for r in (5, 4, 3):
        print(f"D (R={r}, T=4)      : {performans_farki(ii, r, 4):+.2f} milyon $")
    print(f"L (M=6)            : {bosluk_kaybi(ii, 6):.2f} milyon $")
    print(f"SR (ters hesap)    : %{pay_yuzde(ir, 10):.0f}")
    print(cizgi)

    t = ornek_tablo()
    for anahtar, deger in t.ozet().items():
        print(f"{anahtar:<20}: {deger}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("etki_pozisyon", sr=40, b=10, nr=5))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in etki_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
