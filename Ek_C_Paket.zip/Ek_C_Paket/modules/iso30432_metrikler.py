#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30432_metrikler.py
=====================
ISO/TS 30432:2021 (Human resource management — Workforce productivity metrics
cluster) çerçevesindeki işgücü üretkenliği metriklerinin Python karşılığı.

Standart, ISO 30414'ün "üretkenlik" kümesini iki ana metrik ailesi üzerinden
tanımlar ve bunları kurum türüne göre ayrıştırır. Modül dört bölüme ayrılmıştır:

    1) Kâr amaçlı kurumlar — çalışan başına EBIT, gelir (ciro) ve kâr
    2) İnsan sermayesi getirisi — HC RoI ve toplam işgücü maliyeti (TCOW)
    3) STK ve kâr amacı gütmeyen kuruluşlar — bütçe, fon, saha kadrosu, proje
    4) Dönem serisi — üç ilâ beş yıllık karşılaştırma ve eğilim

Kullanım:
    from iso30432_metrikler import ebit_calisan, hc_roi
    ebit_calisan(4_500_000, 3_750_000, 5)      ->  150000.0
    hc_roi(4_500_000, 3_750_000, 1_500_000)    ->  0.5

Doğrudan çalıştırıldığında (python3 iso30432_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Metrik adları, sınıflandırma ve formüller ISO/TS 30432:2021'e dayanır.
Kod ve açıklamalar özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from statistics import mean
from typing import Optional, Sequence

__all__ = [
    # kâr amaçlı kurumlar
    "ebit", "ebit_calisan", "gelir_calisan", "kar_calisan", "ebit_marji",
    # getiri ve işgücü maliyeti
    "tcow", "hc_roi", "isgucu_maliyet_payi", "tze_donusum",
    # STK
    "fon_kullanim_orani", "idari_saha_orani", "egitim_gunu_orani",
    "calisan_basina_proje", "etki_bandi",
    # dönem serisi
    "Donem", "DonemSerisi", "ornek_seri", "metrik_denetimi",
    # dağıtıcı
    "hesapla", "METRIK_LISTESI",
]


# ---------------------------------------------------------------------------
# 1) Kâr amaçlı kurumlar: çalışan başına üretkenlik oranları
# ---------------------------------------------------------------------------

def ebit(gelir: float, giderler: float) -> float:
    """Faiz ve vergi öncesi kâr (EBIT).

    EBIT, faiz ve gelir vergisi giderleri dışındaki tüm giderleri içeren bir
    kâr ölçüsüdür: satılan malın maliyeti ile satış ve idari giderler paya
    değil, gidere yazılır. Kurumun belirli bir dönemde (örneğin bir yıl)
    faaliyetlerinden gelir üretme kabiliyetini gösterir.
    """
    return gelir - giderler


def ebit_calisan(gelir: float, giderler: float, calisan: float) -> float:
    """Çalışan başına EBIT = (Gelir − Giderler) / Toplam çalışan sayısı.

    Kimi kurumlar payda olarak çalışan sayısı yerine tam zaman eşdeğerini
    (TZE) kullanmayı tercih eder. Geçici işgücünün sayısı büyükse hesabın bu
    grubu da kapsayacak biçimde kurulması tercih edilir. Hangi payda seçilirse
    seçilsin, tercih dönemler boyunca korunmalı ve raporda yazılmalıdır.
    """
    return ebit(gelir, giderler) / calisan


def gelir_calisan(net_gelir: float, ortalama_calisan: float) -> float:
    """Çalışan başına gelir = Toplam net gelir / Dönemin ortalama çalışan sayısı.

    Gelir, kimi ülke ve kültürlerde ciro (turnover) olarak anılır. Kısmi ve
    esnek çalışma saatlerini ortak bir tam zamanlı çalışma dönemine (hafta,
    ay, yıl) standartlaştırmak için TZE bazında da hesaplanabilir.
    """
    return net_gelir / ortalama_calisan


def kar_calisan(net_faaliyet_kari: float, ortalama_calisan: float) -> float:
    """Çalışan başına kâr = Net faaliyet kârı / Ortalama çalışan sayısı.

    Çalışan başına düşen net faaliyet kârının ortalaması olarak kaba bir
    üretkenlik ölçüsüdür.
    """
    return net_faaliyet_kari / ortalama_calisan


def ebit_marji(ebit_tutari: float, gelir: float) -> float:
    """EBIT marjı (%) — türetilmiş.

    Çalışan başına EBIT iki bileşene ayrılır: çalışan başına gelir ve marj.
    Çalışan başına gelir artarken çalışan başına EBIT düşüyorsa, sorun
    üretkenlikte değil maliyet yapısındadır.
    """
    return 100 * ebit_tutari / gelir


# ---------------------------------------------------------------------------
# 2) İnsan sermayesi getirisi ve toplam işgücü maliyeti
# ---------------------------------------------------------------------------

def tcow(ucret: float, yan_haklar: float, dis_isgucu: float) -> float:
    """Toplam işgücü maliyeti (TCOW).

    Toplam çalışan ücret maliyeti + toplam yan hak maliyeti + dış işgücü
    maliyeti. Eşdeğer ifadeyle: dış işgücü maliyeti + toplam istihdam maliyeti.
    Kimi ülke ve sektörler biraz farklı tanımlar kullanır; kurum kendi tanımını
    belgelemelidir.
    """
    return ucret + yan_haklar + dis_isgucu


def hc_roi(gelir: float, toplam_gider: float, isgucu_maliyeti: float) -> float:
    """İnsan sermayesi getirisi (HC RoI), oran olarak.

        [Gelir − (Toplam gider − Toplam işgücü maliyeti)] / Toplam işgücü maliyeti − 1

    Sonuç 0,5 ise: işgücüne harcanan her lira geri gelmiş, üstüne 50 kuruş
    vergi öncesi kâr eklenmiştir; bu %50 getiri olarak ifade edilir.
    """
    return (gelir - (toplam_gider - isgucu_maliyeti)) / isgucu_maliyeti - 1


def isgucu_maliyet_payi(isgucu_maliyeti: float, toplam_gider: float) -> float:
    """İşgücü maliyetinin toplam gider içindeki payı (%).

    Standart, kurumsal işgücü maliyetlerinin toplam maliyetin %25 ile %60'ı
    arasında olabileceğini belirtir; bu ölçünün neden giderek daha çok
    izlendiğini açıklayan gerekçe budur.
    """
    return 100 * isgucu_maliyeti / toplam_gider


def tze_donusum(deger_kisi: float, kisi: float, tze: float) -> float:
    """Kişi başına hesaplanmış bir değeri TZE başına çevirir.

    Kısmi zamanlı çalışmanın yaygın olduğu kurumlarda kişi bazlı oran
    üretkenliği olduğundan düşük gösterir.
    """
    return deger_kisi * kisi / tze


# ---------------------------------------------------------------------------
# 3) STK ve kâr amacı gütmeyen kuruluşlar
# ---------------------------------------------------------------------------

def fon_kullanim_orani(kullanilan_fon: float, yillik_butce: float) -> float:
    """Kullanılan (sahaya aktarılan) fonun yıllık bütçeye oranı (%)."""
    return 100 * kullanilan_fon / yillik_butce


def idari_saha_orani(idari: float, saha: float) -> float:
    """İdari kadronun saha çalışanlarına oranı (%).

    Standart bu oranı hem kadro sayısı hem de ücret maliyeti üzerinden
    ayrı ayrı raporlamayı öngörür.
    """
    return 100 * idari / saha


def egitim_gunu_orani(egitim_gun: float, yararlanilan_gun: float) -> float:
    """Yıllık eğitim günlerinin yararlanılan (kullanılabilir) günlere oranı (%)."""
    return 100 * egitim_gun / yararlanilan_gun


def calisan_basina_proje(proje: float, calisan: float) -> float:
    """Çalışan başına gerçekleştirilen ya da olgunlaşmış proje sayısı."""
    return proje / calisan


def etki_bandi(etkilenen_kisi: float) -> str:
    """Proje etkisinin standarttaki üç bandından hangisine düştüğü.

    Bantlar: 10–100 kişi, 100–1.000 kişi, 1.000'den fazla kişi. Farklı
    ölçekteki projeler tek bir ortalamada toplanmaz.
    """
    if etkilenen_kisi > 1000:
        return "1.000+ kişi"
    if etkilenen_kisi >= 100:
        return "100–1.000 kişi"
    if etkilenen_kisi >= 10:
        return "10–100 kişi"
    return "10 kişiden az"


# ---------------------------------------------------------------------------
# 4) Dönem serisi: üç ilâ beş yıllık karşılaştırma
# ---------------------------------------------------------------------------

@dataclass
class Donem:
    """Tek bir ölçüm döneminin üretkenlik verisi."""
    ad: str
    gelir: float
    gider: float
    isgucu: float
    kisi: float
    tze: Optional[float] = None

    @property
    def ebit(self) -> float:
        return ebit(self.gelir, self.gider)

    @property
    def ebit_kisi(self) -> float:
        return self.ebit / self.kisi

    @property
    def ebit_tze(self) -> Optional[float]:
        return self.ebit / self.tze if self.tze else None

    @property
    def gelir_kisi(self) -> float:
        return self.gelir / self.kisi

    @property
    def roi(self) -> float:
        return hc_roi(self.gelir, self.gider, self.isgucu)

    @property
    def isgucu_payi(self) -> float:
        return isgucu_maliyet_payi(self.isgucu, self.gider)


@dataclass
class DonemSerisi:
    """Karşılaştırma dönemlerinin serisi (tipik olarak üç ilâ beş yıl)."""
    donemler: list = field(default_factory=list)

    def ekle(self, ad: str, gelir: float, gider: float, isgucu: float,
             kisi: float, tze: Optional[float] = None) -> "DonemSerisi":
        self.donemler.append(Donem(ad, gelir, gider, isgucu, kisi, tze))
        return self

    def ozet(self) -> dict:
        son = self.donemler[-1]
        ilk = self.donemler[0]
        return {
            "donem_sayisi": len(self.donemler),
            "son_donem": son.ad,
            "ebit_kisi": round(son.ebit_kisi, 2),
            "ebit_tze": round(son.ebit_tze, 2) if son.ebit_tze else None,
            "gelir_kisi": round(son.gelir_kisi, 2),
            "roi_yuzde": round(100 * son.roi, 1),
            "isgucu_payi_yuzde": round(son.isgucu_payi, 1),
            "ebit_kisi_degisim_yuzde": round(
                100 * (son.ebit_kisi - ilk.ebit_kisi) / ilk.ebit_kisi, 1),
            "roi_degisim_puan": round(100 * (son.roi - ilk.roi), 1),
            "kadro_degisim_yuzde": round(100 * (son.kisi - ilk.kisi) / ilk.kisi, 1),
            "ortalama_roi_yuzde": round(100 * mean([d.roi for d in self.donemler]), 1),
        }

    def tablo(self) -> list:
        """Raporlanabilir satır listesi."""
        return [[d.ad, d.gelir, d.gider, d.isgucu, d.kisi,
                 round(d.ebit_kisi, 2), round(100 * d.roi, 1)]
                for d in self.donemler]


def ornek_seri() -> DonemSerisi:
    """Dört dönemlik örnek seri.

    Son dönem, standardın yayımlanmış insan sermayesi getirisi örneğiyle
    aynı büyüklüktedir: gelir 4,5 milyon, gider 3,75 milyon, işgücü maliyeti
    1,5 milyon; getiri %50, EBIT 750.000, beş çalışanda kişi başı 150.000.
    """
    s = DonemSerisi()
    s.ekle("2023", 3_400_000, 3_000_000, 1_150_000, 4, 3.8)
    s.ekle("2024", 3_900_000, 3_350_000, 1_300_000, 5, 4.4)
    s.ekle("2025", 4_200_000, 3_560_000, 1_400_000, 5, 4.6)
    s.ekle("2026", 4_500_000, 3_750_000, 1_500_000, 5, 4.6)
    return s


def metrik_denetimi(payda_tanimi_yazili: bool = False,
                    gecici_isgucu_karari_var: bool = False,
                    tcow_tanimi_yazili: bool = False,
                    uc_bes_yil_seri: bool = False,
                    baglam_notu_var: bool = False,
                    kurum_turu_dogru: bool = False,
                    istisare_yapildi: bool = False) -> list:
    """Bir üretkenlik raporunun eksiklerini listeler.

    Standardın mantığı: çalışan başına oran ve getiri oranı, payda tanımı,
    maliyet kapsamı, karşılaştırma tabanı ve bağlam yazılmadan kıyaslanabilir
    değildir.
    """
    uyarilar = []
    if not payda_tanimi_yazili:
        uyarilar.append("Payda tanımı yazılı değil: kişi sayısı mı, tam zaman "
                        "eşdeğeri mi kullanıldığı belirtilmeli.")
    if not gecici_isgucu_karari_var:
        uyarilar.append("Geçici işgücünün hesaba dâhil edilip edilmediği "
                        "belirsiz: sayı büyükse oran yapay olarak yükselir.")
    if not tcow_tanimi_yazili:
        uyarilar.append("Toplam işgücü maliyetinin kapsamı yazılı değil: ücret, "
                        "yan haklar ve dış işgücü ayrı ayrı gösterilmeli.")
    if not uc_bes_yil_seri:
        uyarilar.append("Üç ilâ beş yıllık karşılaştırma serisi yok: tek dönem "
                        "eğilim göstermez, hedef belirlemeye de yetmez.")
    if not baglam_notu_var:
        uyarilar.append("Bağlam notu yok: kadro değişimi, yeniden yapılanma, "
                        "üretim artışı ve ekonomik koşullar yazılmalı.")
    if not kurum_turu_dogru:
        uyarilar.append("Kurum türüne uygun metrik seti seçilmemiş: kamu "
                        "kurumlarında üretkenlik oranı yerine memnuniyet ve "
                        "hizmet kalitesi göstergeleri önerilir.")
    if not istisare_yapildi:
        uyarilar.append("Çalışan temsilcileri, iş konseyi ya da sendika "
                        "temsilcileriyle istişare kaydı yok.")
    return uyarilar


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "ebit_calisan", "gelir_calisan", "kar_calisan", "ebit_marji",
    "hc_roi", "tcow", "isgucu_payi", "tze_donusum",
    "stk_fon", "stk_idari", "stk_egitim", "stk_proje",
]


def _s(x: float) -> str:
    """Büyük tutarları bilimsel gösterime kaçmadan, Türkçe biçimde yazar."""
    x = float(x)
    if x == int(x):
        return f"{int(x):,}".replace(",", ".")
    t = f"{x:,.2f}".rstrip("0")
    if t.endswith("."):
        t = t[:-1]
    return t.replace(",", "\u00a0").replace(".", ",").replace("\u00a0", ".")


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "ebit_calisan":
        e = ebit(g["gelir"], g["giderler"])
        d = e / g["calisan"]
        return {"deger": d, "ondalik": 0, "birim": "TL / çalışan",
                "ifade": f"({_s(g['gelir'])} − {_s(g['giderler'])}) ÷ {_s(g['calisan'])}",
                "ayrinti": [["EBIT (TL)", round(e)],
                            ["TZE başına EBIT (TL)", round(e / g["tze"])],
                            ["EBIT marjı (%)", round(ebit_marji(e, g["gelir"]), 1)],
                            ["Çalışan başına gelir (TL)",
                             round(gelir_calisan(g["gelir"], g["calisan"]))]]}

    if metrik == "gelir_calisan":
        d = gelir_calisan(g["net_gelir"], g["ortalama_calisan"])
        return {"deger": d, "ondalik": 0, "birim": "TL / çalışan",
                "ifade": f"{_s(g['net_gelir'])} ÷ {_s(g['ortalama_calisan'])}",
                "ayrinti": [["Çalışan başına işgücü maliyeti (TL)",
                             round(g["isgucu_maliyeti"] / g["ortalama_calisan"])],
                            ["Gelirin işgücü maliyetine oranı",
                             round(g["net_gelir"] / g["isgucu_maliyeti"], 2)],
                            ["İşgücü maliyetinin gelire oranı (%)",
                             round(100 * g["isgucu_maliyeti"] / g["net_gelir"], 1)]]}

    if metrik == "kar_calisan":
        d = kar_calisan(g["net_faaliyet_kari"], g["ortalama_calisan"])
        return {"deger": d, "ondalik": 0, "birim": "TL / çalışan",
                "ifade": f"{_s(g['net_faaliyet_kari'])} ÷ {_s(g['ortalama_calisan'])}",
                "ayrinti": [["Çalışan başına gelir (TL)",
                             round(gelir_calisan(g["net_gelir"], g["ortalama_calisan"]))],
                            ["Net kâr marjı (%)",
                             round(100 * g["net_faaliyet_kari"] / g["net_gelir"], 1)],
                            ["Toplam net faaliyet kârı (TL)", round(g["net_faaliyet_kari"])]]}

    if metrik == "ebit_marji":
        d = ebit_marji(g["ebit_tutari"], g["gelir"])
        return {"deger": d, "ondalik": 1, "birim": "% EBIT marjı",
                "ifade": f"({_s(g['ebit_tutari'])} ÷ {_s(g['gelir'])}) × 100",
                "ayrinti": [["Çalışan başına EBIT (TL)",
                             round(g["ebit_tutari"] / g["calisan"])],
                            ["Çalışan başına gelir (TL)",
                             round(g["gelir"] / g["calisan"])],
                            ["Gelirin gidere giden payı (%)", round(100 - d, 1)]]}

    if metrik == "hc_roi":
        r = hc_roi(g["gelir"], g["toplam_gider"], g["isgucu_maliyeti"])
        return {"deger": 100 * r, "ondalik": 1, "birim": "% getiri",
                "ifade": (f"([{_s(g['gelir'])} − ({_s(g['toplam_gider'])} − "
                          f"{_s(g['isgucu_maliyeti'])})] ÷ {_s(g['isgucu_maliyeti'])}) − 1"),
                "ayrinti": [["Oran olarak getiri", round(r, 3)],
                            ["1 TL işgücü harcamasının dönüşü (TL)", round(1 + r, 2)],
                            ["İşgücü dışı gider (TL)",
                             round(g["toplam_gider"] - g["isgucu_maliyeti"])],
                            ["İşgücü maliyetinin gider içindeki payı (%)",
                             round(isgucu_maliyet_payi(g["isgucu_maliyeti"],
                                                       g["toplam_gider"]), 1)]]}

    if metrik == "tcow":
        d = tcow(g["ucret"], g["yan_haklar"], g["dis_isgucu"])
        return {"deger": d, "ondalik": 0, "birim": "TL",
                "ifade": f"{_s(g['ucret'])} + {_s(g['yan_haklar'])} + {_s(g['dis_isgucu'])}",
                "ayrinti": [["Toplam gider içindeki pay (%)",
                             round(isgucu_maliyet_payi(d, g["toplam_gider"]), 1)],
                            ["Yan hakların payı (%)", round(100 * g["yan_haklar"] / d, 1)],
                            ["Dış işgücünün payı (%)", round(100 * g["dis_isgucu"] / d, 1)],
                            ["Toplam istihdam maliyeti (TL)",
                             round(g["ucret"] + g["yan_haklar"])]]}

    if metrik == "isgucu_payi":
        d = isgucu_maliyet_payi(g["isgucu_maliyeti"], g["toplam_gider"])
        return {"deger": d, "ondalik": 1, "birim": "% toplam gider içinde",
                "ifade": f"({_s(g['isgucu_maliyeti'])} ÷ {_s(g['toplam_gider'])}) × 100",
                "ayrinti": [["Çalışan başına işgücü maliyeti (TL)",
                             round(g["isgucu_maliyeti"] / g["calisan"])],
                            ["İşgücü dışı gider (TL)",
                             round(g["toplam_gider"] - g["isgucu_maliyeti"])],
                            ["Standardın andığı aralık", "%25 – %60"]]}

    if metrik == "tze_donusum":
        d = tze_donusum(g["deger_kisi"], g["kisi"], g["tze"])
        return {"deger": d, "ondalik": 0, "birim": "TL / TZE",
                "ifade": f"{_s(g['deger_kisi'])} × {_s(g['kisi'])} ÷ {_s(g['tze'])}",
                "ayrinti": [["Kişi başına değer (TL)", round(g["deger_kisi"])],
                            ["TZE / kişi oranı", round(g["tze"] / g["kisi"], 2)],
                            ["İki payda arasındaki fark (TL)", round(d - g["deger_kisi"])]]}

    if metrik == "stk_fon":
        d = fon_kullanim_orani(g["kullanilan_fon"], g["yillik_butce"])
        return {"deger": d, "ondalik": 1, "birim": "% kullanılan fon",
                "ifade": f"({_s(g['kullanilan_fon'])} ÷ {_s(g['yillik_butce'])}) × 100",
                "ayrinti": [["Kullanılmayan fon (TL)",
                             round(g["yillik_butce"] - g["kullanilan_fon"])],
                            ["Çalışan başına kullanılan fon (TL)",
                             round(g["kullanilan_fon"] / g["calisan"])],
                            ["Çalışan başına yıllık bütçe (TL)",
                             round(g["yillik_butce"] / g["calisan"])]]}

    if metrik == "stk_idari":
        d = idari_saha_orani(g["idari_kisi"], g["saha_kisi"])
        return {"deger": d, "ondalik": 1, "birim": "% idari / saha (kadro)",
                "ifade": f"({_s(g['idari_kisi'])} ÷ {_s(g['saha_kisi'])}) × 100",
                "ayrinti": [["Ücret maliyetinde idari / saha (%)",
                             round(idari_saha_orani(g["idari_ucret"], g["saha_ucret"]), 1)],
                            ["Toplam kadro (kişi)", g["idari_kisi"] + g["saha_kisi"]],
                            ["Saha çalışanlarının payı (%)",
                             round(100 * g["saha_kisi"] /
                                   (g["idari_kisi"] + g["saha_kisi"]), 1)]]}

    if metrik == "stk_egitim":
        d = egitim_gunu_orani(g["egitim_gun"], g["yararlanilan_gun"])
        return {"deger": d, "ondalik": 1, "birim": "% eğitim günü",
                "ifade": f"({_s(g['egitim_gun'])} ÷ {_s(g['yararlanilan_gun'])}) × 100",
                "ayrinti": [["Çalışan başına eğitim günü",
                             round(g["egitim_gun"] / g["calisan"], 1)],
                            ["Eğitim dışı gün",
                             round(g["yararlanilan_gun"] - g["egitim_gun"])],
                            ["Çalışan başına yararlanılan gün",
                             round(g["yararlanilan_gun"] / g["calisan"], 1)]]}

    if metrik == "stk_proje":
        d = calisan_basina_proje(g["proje"], g["calisan"])
        kisi_basi = g["etkilenen_kisi"] / g["proje"]
        return {"deger": d, "ondalik": 2, "birim": "proje / çalışan",
                "ifade": f"{_s(g['proje'])} ÷ {_s(g['calisan'])}",
                "ayrinti": [["Proje başına etkilenen kişi", round(kisi_basi)],
                            ["Çalışan başına etkilenen kişi",
                             round(g["etkilenen_kisi"] / g["calisan"])],
                            ["Etki bandı", etki_bandi(kisi_basi)],
                            ["Toplam etkilenen kişi", round(g["etkilenen_kisi"])]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _tl(x: float) -> str:
    return f"{x:,.0f}".replace(",", ".")


def _demo() -> None:
    cizgi = "-" * 72
    print("ISO/TS 30432 — doğrulama çıktısı")
    print(cizgi)

    s = ornek_seri()
    print("Dönem serisi (kâr amaçlı kurum)")
    print(f"{'Dönem':<8}{'Gelir':>12}{'Gider':>12}{'İşgücü':>12}"
          f"{'Kişi':>6}{'EBIT/kişi':>12}{'Getiri %':>10}")
    for d in s.donemler:
        print(f"{d.ad:<8}{_tl(d.gelir):>12}{_tl(d.gider):>12}{_tl(d.isgucu):>12}"
              f"{d.kisi:>6.0f}{_tl(d.ebit_kisi):>12}{100 * d.roi:>10.1f}")
    print(cizgi)
    for k, v in s.ozet().items():
        print(f"{k:<26}: {v}")
    print(cizgi)

    print("Çalışan başına oranlar (son dönem)")
    print(f"Çalışan başına gelir     : {_tl(gelir_calisan(4_500_000, 5))} TL")
    print(f"Çalışan başına kâr       : {_tl(kar_calisan(750_000, 5))} TL")
    print(f"Çalışan başına EBIT      : {_tl(ebit_calisan(4_500_000, 3_750_000, 5))} TL")
    print(f"TZE başına EBIT          : "
          f"{_tl(tze_donusum(ebit_calisan(4_500_000, 3_750_000, 5), 5, 4.6))} TL")
    print(f"EBIT marjı               : {ebit_marji(750_000, 4_500_000):.1f} %")
    print(cizgi)

    print("İnsan sermayesi getirisi")
    print(f"TCOW                     : {_tl(tcow(1_150_000, 250_000, 100_000))} TL")
    print(f"HC RoI                   : {100 * hc_roi(4_500_000, 3_750_000, 1_500_000):.1f} %")
    print(f"İşgücü maliyeti payı     : {isgucu_maliyet_payi(1_500_000, 3_750_000):.1f} %")
    print(cizgi)

    print("STK metrikleri")
    print(f"Kullanılan fon oranı     : {fon_kullanim_orani(8_200_000, 10_000_000):.1f} %")
    print(f"İdari / saha (kadro)     : {idari_saha_orani(12, 48):.1f} %")
    print(f"Eğitim günü oranı        : {egitim_gunu_orani(540, 12_000):.1f} %")
    print(f"Çalışan başına proje     : {calisan_basina_proje(45, 60):.2f}")
    print(f"Etki bandı (750 kişi)    : {etki_bandi(750)}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("hc_roi", gelir=4_500_000, toplam_gider=3_750_000,
                  isgucu_maliyeti=1_500_000))
    print(cizgi)

    print("Rapor denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in metrik_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
