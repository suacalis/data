#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iso30409_metrikler.py
=====================
ISO 30409:2016 (Human resource management — Workforce planning) rehberindeki
işgücü planlaması ölçümlerinin Python karşılığı.

Standart bir metrik şartnamesi değil, süreç rehberidir: dört faz tanımlar
(başlangıç, veri analizi, risk yönetimi, uygulama) ve her fazda hangi
soruların sorulacağını, hangi verinin toplanacağını (Tablo 4) anlatır.
Formül ve eşik vermez. Bu modüldeki formüller, standardın andığı veri
başlıklarının (arz–talep açığı, boş kadro, hareketlilik, devir, emeklilik
maruziyeti, koşullu işgücü, senaryo, risk) yaygın uygulama tanımlarıdır ve
kurumunuzun kendi tanımıyla uyarlanmalıdır. Modül dört bölümden oluşur:

    1) Talep ve arz   — arz–talep açığı, doluluk, boş kadro, yetkinlik açığı
    2) Hareketlilik   — net hareketlilik, devir, emeklilik, teklif–başlama farkı
    3) Yapı ve risk   — koşullu işgücü, yönetici oranı, senaryo, risk puanı
    4) Yardımcı yapılar — iş ailesi tablosu, plan denetimi, dağıtıcı

Kullanım:
    from iso30409_metrikler import arz_talep_acigi, doluluk_orani
    arz_talep_acigi(480, 445)   ->  35
    doluluk_orani(445, 480)     ->  92.70833...

Doğrudan çalıştırıldığında (python3 iso30409_metrikler.py) tüm fonksiyonlar
örnek verilerle çalıştırılır ve sonuçlar tablo hâlinde yazdırılır.

Not: Terimler ve süreç yapısı ISO 30409:2016'ya dayanır. Kod, açıklamalar ve
örnek değerler özgün olarak yazılmıştır; standardın kendisi telif korumalıdır.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

__all__ = [
    "GecersizGirdi",
    # talep ve arz
    "arz_talep_acigi", "doluluk_orani", "bos_kadro_orani", "yetkinlik_acigi_orani",
    # hareketlilik
    "net_hareketlilik", "devir_orani", "emeklilik_maruziyeti", "yedekleme_karsilama",
    "teklif_baslama_orani", "gereken_teklif",
    # yapı ve risk
    "kosullu_isgucu_orani", "yonetici_basina_calisan", "senaryo_talebi",
    "risk_puani", "OLASILIK", "ETKI",
    # yardımcı
    "Aile", "PlanTablosu", "ornek_tablo", "plan_denetimi",
    "hesapla", "METRIK_LISTESI",
]


class GecersizGirdi(ValueError):
    """Girdiler tutarsız: payda sıfır, parça bütünden büyük vb."""


def _bol(pay: float, payda: float, ad: str = "payda") -> float:
    if payda <= 0:
        raise GecersizGirdi(f"{ad} sıfırdan büyük olmalı")
    return pay / payda


def _oran(parca: float, butun: float, ad: str = "parça") -> float:
    """Yüzde olarak parça / bütün; parça bütünden büyük olamaz."""
    if butun <= 0:
        raise GecersizGirdi("bütün sıfırdan büyük olmalı")
    if parca < 0 or parca > butun:
        raise GecersizGirdi(f"{ad} 0 ile bütün arasında olmalı")
    return 100 * parca / butun


# ---------------------------------------------------------------------------
# 1) Talep ve arz
# ---------------------------------------------------------------------------

def arz_talep_acigi(talep: float, arz: float) -> float:
    """Arz–talep açığı = talep − arz (tam zaman eşdeğeri, FTE).

    Pozitif değer eksik arzı, negatif değer fazla arzı gösterir. Standart,
    açığın kurum geneli yanında iş ailesi ve yetkinlik bazında da
    hesaplanmasını ister; toplu düzey farkları gizler (madde 6.3.13).
    """
    if talep <= 0 or arz < 0:
        raise GecersizGirdi("talep sıfırdan büyük, arz negatif olmamalı")
    return talep - arz


def doluluk_orani(arz: float, talep: float) -> float:
    """Talebin ne kadarının arzla karşılandığı (%) = arz / talep."""
    return 100 * _bol(arz, talep, "talep")


def bos_kadro_orani(finanse_bos: float, finanse_pozisyon: float) -> float:
    """Finanse edilmiş pozisyonlar içinde boş kalanların oranı (%)."""
    return _oran(finanse_bos, finanse_pozisyon, "boş kadro")


def yetkinlik_acigi_orani(yetkin: float, grup: float) -> float:
    """Bir iş ailesinde yeni yetkinliğe hazır olmayanların oranı (%).

    Arz iş ailesi bazında sabit kalsa da yetkinlik bazında değişebilir
    (madde 6.3.20): kişi sayısı yeterli, gereken yetkinlik eksik olabilir.
    """
    return 100 - _oran(yetkin, grup, "yetkin")


# ---------------------------------------------------------------------------
# 2) Hareketlilik ve eğilim
# ---------------------------------------------------------------------------

def net_hareketlilik(ayrilan: float, giren: float) -> float:
    """Net hareketlilik = çıkış − giriş (Tablo 1: exits-minus entries)."""
    if ayrilan < 0 or giren < 0:
        raise GecersizGirdi("giriş ve çıkış negatif olamaz")
    return ayrilan - giren


def devir_orani(ayrilan: float, donem_basi: float, giren: float) -> float:
    """Devir oranı (%) = çıkış / ortalama kadro × 100.

    Ortalama kadro, dönem başı ile dönem sonu kadronun ortalamasıdır.
    Gönüllü ve istemsiz ayrılışlar ayrı raporlanmalıdır (Tablo 4).
    """
    sonu = donem_basi + giren - ayrilan
    if donem_basi <= 0 or sonu < 0 or ayrilan < 0 or giren < 0:
        raise GecersizGirdi("kadro verileri tutarsız")
    return 100 * ayrilan / ((donem_basi + sonu) / 2)


def emeklilik_maruziyeti(yaklasan: float, grup: float) -> float:
    """Planlama döneminde emekli olması beklenenlerin gruba oranı (%).

    Standart, "yüksek nitelikli uzmanların %46'sı emekli olacak" türünden
    bir göstergeyi eğilim raporlaması örneği olarak verir (madde 6.3.23).
    """
    return _oran(yaklasan, grup, "yaklaşan ayrılış")


def yedekleme_karsilama(hazir: float, yaklasan: float) -> float:
    """Beklenen ayrılışların kaçı için hazır yedek var (%)."""
    return _oran(hazir, yaklasan, "hazır yedek")


def teklif_baslama_orani(baslayan: float, teklif: float) -> float:
    """Verilen tekliflerden fiilen işe başlayanların oranı (%)."""
    return _oran(baslayan, teklif, "başlayan")


def gereken_teklif(gereken: float, baslayan: float, teklif: float) -> int:
    """Gereken sayıda kişinin başlaması için verilmesi gereken teklif sayısı.

    Standart, teklif ile fiili başlama arasındaki farkın eşdeğer bir yüzde
    tamponuyla karşılanmasını önerir (madde 6.3.20 n).
    """
    oran = teklif_baslama_orani(baslayan, teklif)
    if oran <= 0 or gereken < 0:
        raise GecersizGirdi("başlama oranı sıfırdan büyük olmalı")
    return math.ceil(gereken * teklif / baslayan)


# ---------------------------------------------------------------------------
# 3) Yapı ve risk
# ---------------------------------------------------------------------------

def kosullu_isgucu_orani(kadrolu: float, yuklenici: float, gecici: float) -> float:
    """Koşullu (yüklenici, danışman, geçici) işgücünün toplam işgücüne oranı (%)."""
    if min(kadrolu, yuklenici, gecici) < 0:
        raise GecersizGirdi("işgücü bileşenleri negatif olamaz")
    return 100 * _bol(yuklenici + gecici, kadrolu + yuklenici + gecici, "toplam işgücü")


def yonetici_basina_calisan(calisan: float, yonetici: float) -> float:
    """Yönetici başına düşen çalışan sayısı (madde 6.3.20 d)."""
    return _bol(calisan, yonetici, "yönetici sayısı")


def senaryo_talebi(mevcut: float, yillik_pct: float, yil: float) -> float:
    """Yıllık yüzde değişimle yıl sonu talebi = mevcut × (1 + pct/100)^yıl.

    Standart, geleceği en az üç senaryoyla sunmayı ister: değişim yok,
    büyüme ve düşüş (madde 6.3.27).
    """
    if mevcut <= 0 or yil < 0 or yillik_pct <= -100:
        raise GecersizGirdi("senaryo girdileri geçersiz")
    return mevcut * (1 + yillik_pct / 100) ** yil


OLASILIK = {1: "Nadir", 2: "Düşük ihtimal", 3: "Orta", 4: "Muhtemel", 5: "Neredeyse kesin"}
ETKI = {1: "Önemsiz", 2: "Hafif", 3: "Orta", 4: "Büyük", 5: "Felaket"}


def risk_puani(olasilik: int, etki: int) -> int:
    """Risk puanı = olasılık (1–5) × etki (1–5).

    Standart, "önemsiz–hafif–orta–büyük–felaket" etki ve "nadir–düşük
    ihtimal–orta–muhtemel–neredeyse kesin" olasılık ölçeklerinden ya da
    daha basit bir yüksek–orta–düşük değerlendirmesinden söz eder (6.4.2.3).
    """
    if olasilik != int(olasilik) or etki != int(etki) or \
       not (1 <= olasilik <= 5 and 1 <= etki <= 5):
        raise GecersizGirdi("olasılık ve etki 1 ile 5 arasında tam sayı olmalı")
    return int(olasilik) * int(etki)


# ---------------------------------------------------------------------------
# 4) Yardımcı yapılar
# ---------------------------------------------------------------------------

@dataclass
class Aile:
    """Tek bir iş ailesinin talep ve arz kaydı (FTE)."""
    ad: str
    talep: float = 0     # onaylı talep
    onaysiz: float = 0   # onaysız ama dönem içinde onaylanması beklenen talep
    arz: float = 0
    kritik: bool = False

    @property
    def acik(self) -> float:
        return self.talep - self.arz


@dataclass
class PlanTablosu:
    """İş ailesi bazında talep–arz tablosu."""
    aileler: list = field(default_factory=list)

    def ekle(self, ad, talep, onaysiz, arz, kritik=False):
        self.aileler.append(Aile(ad, talep, onaysiz, arz, kritik))
        return self

    def ozet(self, senaryo_pct: float = 0) -> dict:
        talep = sum(a.talep for a in self.aileler)
        arz = sum(a.arz for a in self.aileler)
        onaysiz = sum(a.onaysiz for a in self.aileler)
        eksik = sum(a.acik for a in self.aileler if a.acik > 0)
        fazla = -sum(a.acik for a in self.aileler if a.acik < 0)
        kritik = [a for a in self.aileler if a.kritik]
        en_buyuk = max(self.aileler, key=lambda a: a.acik)
        return {
            "aile_sayisi": len(self.aileler),
            "talep": talep, "arz": arz, "onaysiz": onaysiz,
            "net_acik": arz_talep_acigi(talep, arz),
            "doluluk": round(doluluk_orani(arz, talep), 1),
            "brut_eksik": eksik, "brut_fazla": fazla,
            "onaysiz_dahil_acik": talep + onaysiz - arz,
            "senaryo_acigi": round(talep * (1 + senaryo_pct / 100) - arz, 1),
            "kritik_acik": sum(a.acik for a in kritik),
            "en_buyuk_acik": (en_buyuk.ad, en_buyuk.acik),
        }


def ornek_tablo() -> PlanTablosu:
    """Altı iş ailesi için örnek talep–arz tablosu (uydurma veri)."""
    t = PlanTablosu()
    for satir in [
        ("Yazılım geliştirme",   120, 10, 104, True),
        ("Satış ve danışmanlık",  90,  6,  92, False),
        ("Proje yönetimi",        40,  4,  31, True),
        ("Operasyon ve teslimat", 150, 0, 138, False),
        ("İdari işler ve tesis",  50,  0,  52, False),
        ("İK ve finans",          30,  2,  28, False),
    ]:
        t.ekle(*satir)
    return t


def plan_denetimi(ekip_ve_gerekce: bool = False,
                  strateji_hizasi: bool = False,
                  iletisim_plani: bool = False,
                  bolumlendirme: bool = False,
                  veri_bosluklari: bool = False,
                  uc_senaryo: bool = False,
                  aciklar_hesaplandi: bool = False,
                  risk_matrisi: bool = False,
                  eylem_plani: bool = False,
                  izleme_mekanizmasi: bool = False) -> list:
    """Bir işgücü planının, standardın faz kontrol listesine göre eksiklerini sıralar.

    Maddeler ISO 30409 Tablo 1 ve 6–8. maddelerden türetilmiştir; bir uygunluk
    sınaması değil, hazırlık kontrol listesidir.
    """
    kontroller = [
        (ekip_ve_gerekce, "Faz 1a: İşgücü planlama lideri ve ekibi ile gerekçe (iş gerekçesi) belirlenmemiş."),
        (strateji_hizasi, "Faz 1b: Stratejik ve iş planlarının işgücü sonuçları belgelenmemiş."),
        (iletisim_plani, "Faz 1c: Paydaşları dahil edecek iletişim planı yok."),
        (bolumlendirme, "Faz 1d: İşgücü bölümlendirilmemiş; planlama kritik iş gruplarına odaklanamaz."),
        (veri_bosluklari, "Faz 1f: Mevcut sistemlerde bulunmayan veri (nicel ve nitel) boşlukları raporlanmamış."),
        (uc_senaryo, "Faz 1g: Gelecek en az üç senaryoyla (değişim yok, büyüme, düşüş) sunulmamış."),
        (aciklar_hesaplandi, "Faz 2a: Arz–talep açıkları sayısallaştırılmamış."),
        (risk_matrisi, "Faz 2b: Arz riski, olasılık ve etki ölçekleriyle değerlendirilmemiş."),
        (eylem_plani, "Faz 3: Konu, görev, sorumlu, süre, gösterge ve yatırımı içeren eylem planı yok."),
        (izleme_mekanizmasi, "Faz 4: İşgücü planlama sonuçlarını izleme ve ölçme mekanizması kurulmamış."),
    ]
    return [metin for tamam, metin in kontroller if not tamam]


# ---------------------------------------------------------------------------
# 5) Dağıtıcı: hesaplayıcı arayüzünün kullandığı tek giriş noktası
# ---------------------------------------------------------------------------

METRIK_LISTESI = [
    "arz_acigi", "bos_kadro", "hareketlilik", "emeklilik", "gecici_oran",
    "yonetici_orani", "yetkinlik_acigi", "teklif_kabul", "senaryo", "risk",
]


def _g(x) -> str:
    """Sayıyı, bilimsel gösterim kullanmadan en kısa biçimde yazar."""
    return f"{x:.12g}"


def hesapla(metrik: str, **g) -> dict:
    """Metrik kimliği ve girdilerle hesabı yapar; sözlük döndürür.

    Dönen anahtarlar: deger, ifade (formülün yerine konmuş hâli), ondalik,
    birim, ayrinti (etiket–değer çiftleri).
    """
    if metrik == "arz_acigi":
        d = arz_talep_acigi(g["talep_fte"], g["arz_fte"])
        if g["onaysiz_talep"] < 0:
            raise GecersizGirdi("onaysız talep negatif olamaz")
        return {"deger": d, "ondalik": 1, "birim": "FTE (talep − arz)",
                "ifade": f"{_g(g['talep_fte'])} − {_g(g['arz_fte'])}",
                "ayrinti": [["Doluluk oranı (%)", round(doluluk_orani(g["arz_fte"], g["talep_fte"]), 1)],
                            ["Onaysız talep dahil açık (FTE)", g["talep_fte"] + g["onaysiz_talep"] - g["arz_fte"]],
                            ["Açığın talebe oranı (%)", round(100 * d / g["talep_fte"], 1)]]}

    if metrik == "bos_kadro":
        d = bos_kadro_orani(g["finanse_bos"], g["finanse_pozisyon"])
        if g["bekleme_gun"] < 0:
            raise GecersizGirdi("bekleme günü negatif olamaz")
        gun = g["finanse_bos"] * g["bekleme_gun"]
        return {"deger": d, "ondalik": 1, "birim": "% boş kadro",
                "ifade": f"({_g(g['finanse_bos'])} ÷ {_g(g['finanse_pozisyon'])}) × 100",
                "ayrinti": [["Dolu finanse pozisyon", g["finanse_pozisyon"] - g["finanse_bos"]],
                            ["Boş kadroların toplam bekleme günü", gun],
                            ["Boş kalan işgücü (FTE-yıl)", round(gun / 365, 1)]]}

    if metrik == "hareketlilik":
        d = net_hareketlilik(g["ayrilan"], g["giren"])
        devir = devir_orani(g["ayrilan"], g["donem_basi"], g["giren"])
        sonu = g["donem_basi"] + g["giren"] - g["ayrilan"]
        return {"deger": d, "ondalik": 0, "birim": "kişi (çıkış − giriş)",
                "ifade": f"{_g(g['ayrilan'])} − {_g(g['giren'])}",
                "ayrinti": [["Dönem sonu kadro", sonu],
                            ["Net hareketlilik oranı (dönem başına göre %)", round(100 * d / g["donem_basi"], 1)],
                            ["Devir oranı (ortalama kadroya göre %)", round(devir, 1)]]}

    if metrik == "emeklilik":
        d = emeklilik_maruziyeti(g["yaklasan"], g["grup"])
        hazir = yedekleme_karsilama(g["hazir_yedek"], g["yaklasan"]) if g["yaklasan"] > 0 else 0
        return {"deger": d, "ondalik": 1, "birim": "% ayrılış maruziyeti",
                "ifade": f"({_g(g['yaklasan'])} ÷ {_g(g['grup'])}) × 100",
                "ayrinti": [["Beklenen kayıp sonrası kalan", g["grup"] - g["yaklasan"]],
                            ["Yedekleme karşılama oranı (%)", round(hazir, 1)],
                            ["YedeÄi hazır olmayan", g["yaklasan"] - g["hazir_yedek"]]]}

    if metrik == "gecici_oran":
        d = kosullu_isgucu_orani(g["kadrolu"], g["yuklenici"], g["gecici"])
        toplam = g["kadrolu"] + g["yuklenici"] + g["gecici"]
        return {"deger": d, "ondalik": 1, "birim": "% koşullu işgücü",
                "ifade": f"(({_g(g['yuklenici'])} + {_g(g['gecici'])}) ÷ "
                         f"({_g(g['kadrolu'])} + {_g(g['yuklenici'])} + {_g(g['gecici'])})) × 100",
                "ayrinti": [["Toplam işgücü (FTE)", toplam],
                            ["Yüklenici ve danışman payı (%)", round(100 * g["yuklenici"] / toplam, 1)],
                            ["Geçici ve gündelik payı (%)", round(100 * g["gecici"] / toplam, 1)]]}

    if metrik == "yonetici_orani":
        d = yonetici_basina_calisan(g["calisan"], g["yonetici"])
        if g["calisan"] < 0:
            raise GecersizGirdi("çalışan sayısı negatif olamaz")
        return {"deger": d, "ondalik": 1, "birim": "çalışan / yönetici",
                "ifade": f"{_g(g['calisan'])} ÷ {_g(g['yonetici'])}",
                "ayrinti": [["Yönetici payı (%)", round(100 * g["yonetici"] / (g["calisan"] + g["yonetici"]), 1)],
                            ["Toplam kadro", g["calisan"] + g["yonetici"]]]}

    if metrik == "yetkinlik_acigi":
        d = yetkinlik_acigi_orani(g["yetkin"], g["grup_fte"])
        if g["egitim_ay"] <= 0:
            raise GecersizGirdi("eğitim süresi sıfırdan büyük olmalı")
        gerekli = g["grup_fte"] - g["yetkin"]
        return {"deger": d, "ondalik": 1, "birim": "% yeni yetkinlik gerektiriyor",
                "ifade": f"100 − ({_g(g['yetkin'])} ÷ {_g(g['grup_fte'])}) × 100",
                "ayrinti": [["Yeniden beceri gerektiren kişi", gerekli],
                            ["Hazır yetkin kişi", g["yetkin"]],
                            ["Aylık eğitilmesi gereken kişi", round(gerekli / g["egitim_ay"], 1)]]}

    if metrik == "teklif_kabul":
        d = teklif_baslama_orani(g["baslayan"], g["teklif"])
        gerek = gereken_teklif(g["gereken"], g["baslayan"], g["teklif"])
        return {"deger": d, "ondalik": 1, "birim": "% teklif–başlama",
                "ifade": f"({_g(g['baslayan'])} ÷ {_g(g['teklif'])}) × 100",
                "ayrinti": [["Başlamayan teklif", g["teklif"] - g["baslayan"]],
                            ["Gereken başlama için verilmesi gereken teklif", gerek],
                            ["Teklif tamponu", gerek - g["gereken"]]]}

    if metrik == "senaryo":
        b = senaryo_talebi(g["mevcut_talep"], g["buyume_pct"], g["yil"])
        dus = senaryo_talebi(g["mevcut_talep"], -g["dusus_pct"], g["yil"])
        return {"deger": b, "ondalik": 1, "birim": "FTE (büyüme senaryosu)",
                "ifade": f"{_g(g['mevcut_talep'])} × (1 + {_g(g['buyume_pct'])} ÷ 100)^{_g(g['yil'])}",
                "ayrinti": [["Değişim yok senaryosu (FTE)", g["mevcut_talep"]],
                            ["Düşüş senaryosu (FTE)", round(dus, 1)],
                            ["Büyüme–düşüş aralığı (FTE)", round(b - dus, 1)]]}

    if metrik == "risk":
        d = risk_puani(g["olasilik"], g["etki"])
        if not (1 <= g["istah_esigi"] <= 25):
            raise GecersizGirdi("risk iştahı eşiği 1 ile 25 arasında olmalı")
        return {"deger": d, "ondalik": 0, "birim": "puan (1–25)",
                "ifade": f"{_g(g['olasilik'])} × {_g(g['etki'])}",
                "ayrinti": [["Olasılık düzeyi", OLASILIK[int(g["olasilik"])]],
                            ["Etki düzeyi", ETKI[int(g["etki"])]],
                            ["Risk iştahı eşiği aşıldı mı", "Evet" if d > g["istah_esigi"] else "Hayır"]]}

    raise ValueError(f"Bilinmeyen metrik: {metrik}")


# ---------------------------------------------------------------------------
# 6) Doğrulama çıktısı
# ---------------------------------------------------------------------------

def _demo() -> None:
    cizgi = "-" * 64
    print("ISO 30409 — doğrulama çıktısı")
    print(cizgi)

    t = ornek_tablo()
    print("İş ailesi bazında talep ve arz (FTE; uydurma örnek veri)")
    print(f"{'İş ailesi':<24}{'Talep':>7}{'Onaysız':>9}{'Arz':>6}{'Açık':>7}{'Kritik':>8}")
    for a in t.aileler:
        print(f"{a.ad:<24}{a.talep:>7}{a.onaysiz:>9}{a.arz:>6}{a.acik:>7}{'evet' if a.kritik else '—':>8}")
    print(cizgi)
    for anahtar, deger in t.ozet(senaryo_pct=5).items():
        print(f"{anahtar:<20}: {deger}")
    print(cizgi)

    print(f"Boş kadro oranı          : {bos_kadro_orani(40, 480):.1f} %")
    print(f"Net hareketlilik         : {net_hareketlilik(62, 48)} kişi,"
          f" devir {devir_orani(62, 440, 48):.1f} %")
    print(f"Emeklilik maruziyeti     : {emeklilik_maruziyeti(23, 50):.1f} %")
    print(f"Koşullu işgücü           : {kosullu_isgucu_orani(432, 60, 36):.1f} %")
    print(f"Yetkinlik açığı          : {yetkinlik_acigi_orani(4, 40):.1f} %")
    print(f"Gereken teklif           : {gereken_teklif(40, 51, 60)} (başlama {teklif_baslama_orani(51, 60):.1f} %)")
    print(f"Büyüme senaryosu         : {senaryo_talebi(480, 3.5, 3):.1f} FTE")
    print(f"Risk puanı (5 × 4)       : {risk_puani(5, 4)}")
    print(cizgi)

    print("Dağıtıcı örneği:")
    print(hesapla("arz_acigi", talep_fte=480, arz_fte=445, onaysiz_talep=22))
    print(cizgi)

    print("Plan denetimi (hiçbir ön koşulu sağlamayan bir kurum için):")
    for u in plan_denetimi():
        print(" !", u)


if __name__ == "__main__":
    _demo()
